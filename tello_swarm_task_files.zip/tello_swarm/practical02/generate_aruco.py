import cv2
import os

# ==========================================
# PRACTICAL 02
# Generate ArUco Markers for Tello Swarm
# ==========================================

OUTPUT_FOLDER = "markers"
MARKER_SIZE = 500

os.makedirs(OUTPUT_FOLDER, exist_ok=True)

# Dictionary: 4x4, maximum 50 IDs
aruco_dict = cv2.aruco.getPredefinedDictionary(
    cv2.aruco.DICT_4X4_50
)

marker_ids = [1, 2, 3]

for marker_id in marker_ids:

    marker = cv2.aruco.generateImageMarker(
        aruco_dict,
        marker_id,
        MARKER_SIZE
    )

    filename = f"{OUTPUT_FOLDER}/aruco_id_{marker_id}.png"

    cv2.imwrite(filename, marker)

    print(f"Generated: {filename}")

print()
print("ArUco markers generated successfully.")
