#!/usr/bin/env python3
"""STEP 11 offline axis-lock replay.
Reads an existing Step-10 CSV only; sends no Tello/RC commands.
"""
import argparse, csv, math

DEFAULT_LOG = "logs/p04b1_step10_brake_settle_20261005_183710.csv"

def load_rows(path):
    with open(path, newline="") as f:
        return list(csv.DictReader(f))

def first_trigger(rows, trigger_m):
    for row in rows:
        ey = abs(float(row["error_y_m"]))
        if ey >= trigger_m:
            return row
    return None

def linear_slope(rows, t0=0.52, t1=2.07):
    pts=[r for r in rows if t0 <= float(r["time_s"]) <= t1]
    t=[float(r["time_s"]) for r in pts]
    y=[float(r["error_y_m"]) for r in pts]
    mt=sum(t)/len(t); my=sum(y)/len(y)
    return sum((a-mt)*(b-my) for a,b in zip(t,y))/sum((a-mt)**2 for a in t)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--log", default=DEFAULT_LOG)
    ap.add_argument("--trigger-cm", type=float, default=2.5)
    args=ap.parse_args()
    rows=load_rows(args.log)
    hit=first_trigger(rows,args.trigger_cm/100.0)
    max_y=max(abs(float(r["error_y_m"])) for r in rows)
    final=rows[-1]
    print("STEP 11 OFFLINE AXIS-LOCK REPLAY")
    print("Source rows       :",len(rows))
    print(f"Step-10 max |Y|  : {max_y*100:.2f} cm")
    print(f"Y drift slope     : {linear_slope(rows)*100:.2f} cm/s")
    print(f"Candidate trigger : {args.trigger_cm:.2f} cm")
    if hit:
        print(f"Trigger time      : {float(hit['time_s']):.2f} s")
        print(f"X error @ trigger : {float(hit['error_x_m'])*100:+.2f} cm")
        print(f"Y error @ trigger : {float(hit['error_y_m'])*100:+.2f} cm")
    print(f"Step-10 final X   : {float(final['error_x_m'])*100:+.2f} cm")
    print(f"Step-10 final Y   : {float(final['error_y_m'])*100:+.2f} cm")
    print("MODE              : OFFLINE ONLY / NO FLIGHT COMMANDS")

if __name__ == "__main__":
    main()
