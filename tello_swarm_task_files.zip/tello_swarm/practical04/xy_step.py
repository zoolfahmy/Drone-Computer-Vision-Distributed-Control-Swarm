# Task 3: one step of the XY controller, by calculation only
import math
import numpy as np

M = np.load("logs/p04b1_matrix_v2_20260929_170729.npy")
M_INV = np.linalg.inv(M)

CALIBRATION_RC = 6
XY_DEADBAND_M = 0.05
KP_XY = 0.35
MAX_DESIRED_VEL_MPS = 0.08
MAX_XY_RC = 10

target_x, target_y = 1.00, 1.00
x, y = 0.90, 1.10

ex, ey = target_x - x, target_y - y
dist = math.hypot(ex, ey)
print("error (m):", round(ex, 3), round(ey, 3), "distance:", round(dist, 3))

if dist <= XY_DEADBAND_M:
    print("inside the deadband: RC 0, 0")
else:
    vx, vy = KP_XY * ex, KP_XY * ey
    speed = math.hypot(vx, vy)
    if speed > MAX_DESIRED_VEL_MPS:
        vx, vy = vx * MAX_DESIRED_VEL_MPS / speed, vy * MAX_DESIRED_VEL_MPS / speed
    print("desired velocity (m/s):", round(vx, 4), round(vy, 4))

    fb_ref, lr_ref = M_INV @ np.array([vx, vy])
    rc_fb = round(fb_ref * CALIBRATION_RC)
    rc_lr = round(lr_ref * CALIBRATION_RC)
    print("RC before the limit: FB", rc_fb, "LR", rc_lr)

    rc_fb = max(-MAX_XY_RC, min(MAX_XY_RC, rc_fb))
    rc_lr = max(-MAX_XY_RC, min(MAX_XY_RC, rc_lr))
    print("RC sent            : FB", rc_fb, "LR", rc_lr)
