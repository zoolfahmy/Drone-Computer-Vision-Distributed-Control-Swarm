#!/usr/bin/env python3
"""
STEP 11 HOLD  -  continuous closed-loop position hold that cancels a steady drift.
==================================================================================

Course arena, 7 Oct 2026: on the glossy tile floor every Tello hover drifted
towards -Y (its nose direction) at ~3-5 cm/s.  Step 10's pulse/brake/coast
scheduler cannot hold against a constant drift, so Step 11 uses a continuous
10 Hz PID in arena coordinates whose integral term learns the counter-stick.

Conventions measured on 7 Oct (map_axes*.py):
    drone nose pointing to -Y (away from the camera, towards ID40-ID41 middle)
    LR+  -> +X        FB+  -> -Y
Parallax: camera lens 2.24 m above the floor; a marker at height h is seen
displaced from the camera nadir by k = D/(D-h).  Positions are corrected with
    P = nadir + (p - nadir) / k,   h ~ ToF.

    python3 step11_hold.py --sim                       # simulated drone with drift
    python3 step11_hold.py --confirm HOLD-RC18         # real flight, hold only
    python3 step11_hold.py --wp 10,0 --confirm WP-RC18 # origin -> WP1 (+10 cm X) -> land

Flight: lock origin on the ground -> take off -> stabilise 6 s + steady ToF (XY held)
        -> HOLD 15 s (PID)
        [--wp: HOLD 3 s -> each waypoint until accepted (<5 cm, <4 cm/s, 1 s) -> hold 2 s]
        -> descend to 35 cm with XY hold -> RC 0, 0.5 s -> land.

Automatic stops (RC 0 then land): marker lost > 1.0 s, corrected distance from
the origin > 30 cm (45 cm while stabilising after takeoff), arena margin, ToF outside 30-160 cm, heading more than 25 deg
from the expected nose direction, Ctrl+C / SIGTERM, any error.
"""
import argparse
import csv
import json
import logging
import math
import signal
import socket
import sys
import threading
import time
from datetime import datetime
from pathlib import Path

import numpy as np

from vision_client import POSE_PORT, VisionClient
from swarm_link import SwarmLink
from fly_step10 import FakeTello, vision_is_fresh

# ---------------- geometry ----------------
CAMERA_HEIGHT_M = 2.24
NADIR_XY = (1.067, 1.067)        # ~arena centre (takeoff at centre showed no offset)
ARENA_W = ARENA_H = 2.1336
ARENA_MARGIN_M = 0.20            # applied to the TRUE (parallax-corrected) position
# Apparent (uncorrected) position limits = where the camera still sees the marker.
# Calibration image (7 Oct): ~1 m of floor visible beyond ID40/ID43 and ID41/ID42
# in X, only ~0.2 m beyond the far (y=0) and near (y=2.13) edges in Y.
RAW_X_LIMITS_M = (-0.20, 2.33)
RAW_Y_LIMITS_M = (0.03, 2.10)

# ---------------- flight ----------------
MIN_BATTERY = 50
MAX_TEMP_C = 62                  # takeoff unanswered at 71-74 C (19:16) and at 66 C (19:58); OK at <=62 C
STABILIZE_S = 6.0                # 3 s was too short: still climbing 64->92 cm and lurched (7 Oct)
TOF_STEADY_SPREAD_CM = 6         # origin locks only once ToF stays within this ...
TOF_STEADY_WINDOW_S = 1.0        # ... for this long
TOF_STEADY_TIMEOUT_S = 4.0       # extra wait allowed after STABILIZE_S
ORIGIN_S = 0.5
GROUND_MARKER_H_M = 0.093        # marker height with the drone on the floor
HOLD_S = 15.0
# Guided descent: keep XY hold while descending, then 'land' from low height.
# Plain 'land' from ~85 cm let the forward drift carry the drone into a hard,
# skidding touchdown (7 Oct).
DESCEND_RC = -25                 # -15 only gave ~5 cm/s and timed out at 64 cm (7 Oct)
DESCEND_TO_CM = 35
DESCEND_TIMEOUT_S = 10.0

# Waypoint mode (--wp): offsets from the locked origin, arena frame, cm.
WP_TOL_M = 0.05                  # accepted when error < 5 cm (hover wander alone is ~3-6 cm) ...
WP_SPEED_TOL_MPS = 0.04          # ... and speed < 4 cm/s (hover speed noise ~2.2 cm/s median) ...
WP_SETTLE_S = 1.0                # ... continuously for 1 s
WP_TIMEOUT_S = 12.0              # per waypoint; on timeout the mission ends (descend + land)
WP_MAX_OFFSET_M = 0.25
WP_RAMP_MPS = 0.04               # reference moves to a new waypoint at 4 cm/s
FINAL_HOLD_S = 2.0
PRE_LAND_PAUSE_S = 0.5
CONTROL_DT = 0.10

# ---------------- controller (arena frame, metres) ----------------
RC_MAX = 18                      # 12 saturated with the integral at its limit under -Y drift (7 Oct 19:11)
KP = 60.0                        # RC per m        (10 cm error -> 6)
KI = 40.0                        # RC per m*s
KD = 80.0                        # RC per m/s      (5 cm/s -> 4)
I_LIMIT_RC = 14.0                # max integral contribution (10 was reached at 19:11)
I_TAU_S = 6.0                    # integral leak time constant, 0 = no leak (sim study 7 Oct: DOB + 6 s leak best)
# Disturbance observer.  Plant gain from 7 Oct 19:11: FB -12 saturated gave
# ~4-5 cm/s against ~4 cm/s drift -> ~0.7 cm/s per RC.  0 disables the DOB.
DOB_GAIN_MPS_PER_RC = 0.006      # 0.6 cm/s per RC; sim: no worse than no-DOB even if the real gain is 0.4
DOB_FRAC = 0.7                   # cancel only part of the estimate (gain is uncertain)
DOB_PLANT_TAU_S = 0.35
DOB_FILTER_TAU_S = 0.8
DOB_MAX_MPS = 0.15
# No integral zone: a 5 cm zone froze the integral while a +X drift held the
# drone 6-10 cm off WP1 (7 Oct 19:01).  Windup on a waypoint change is avoided
# by ramping the reference instead (WP_RAMP_MPS).
VEL_ALPHA = 0.35                 # EMA on frame-to-frame velocity
DEADBAND_M = 0.01

# ---------------- safety ----------------
MAX_DISTANCE_M = 0.30
MAX_DISTANCE_STABILIZE_M = 0.45   # the takeoff itself threw the drone up to 29 cm (7 Oct 19:58)
VISION_LAND_S = 1.0
TOF_MIN_CM, TOF_MAX_CM = 30, 160
TOF_H_MIN_CM, TOF_H_MAX_CM = 30, 140   # ToF accepted for the parallax height
TOF_H_WINDOW = 10                      # median over ~1 s at 10 Hz
HEADING_TOL_DEG = 25.0

# ---------------- swarm (--swarm) ----------------
SWARM_WAIT_S = 180.0             # max wait on the ground for GO
SWARM_FIRST_CONTACT_S = 10.0     # coordinator must be heard within this
SWARM_LINK_TIMEOUT_S = 1.5       # coordinator silent this long in flight -> land
SWARM_STATUS_DT = 0.2
SEPARATION_M = 0.40              # another drone closer than this -> land

BASE_DIR = Path(__file__).resolve().parent
LOG_DIR = BASE_DIR / "logs"
TOKEN = f"HOLD-RC{RC_MAX}"
WP_TOKEN = f"WP-RC{RC_MAX}"


class Abort(Exception):
    pass


def on_sigterm(signum, frame):
    raise KeyboardInterrupt


def in_camera_area(x_raw, y_raw):
    """Apparent (uncorrected) position still where the camera sees it well."""
    return (RAW_X_LIMITS_M[0] <= x_raw <= RAW_X_LIMITS_M[1]
            and RAW_Y_LIMITS_M[0] <= y_raw <= RAW_Y_LIMITS_M[1])


def arena_safe(x, y):
    return (ARENA_MARGIN_M <= x <= ARENA_W - ARENA_MARGIN_M
            and ARENA_MARGIN_M <= y <= ARENA_H - ARENA_MARGIN_M)


def correct_parallax(x, y, h_m):
    k = CAMERA_HEIGHT_M / (CAMERA_HEIGHT_M - h_m)
    return (NADIR_XY[0] + (x - NADIR_XY[0]) / k,
            NADIR_XY[1] + (y - NADIR_XY[1]) / k)


def arena_to_rc(ux, uy):
    """Arena-frame command -> (LR, FB) for nose -Y:  LR+ = +X,  FB+ = -Y."""
    return ux, -uy


def wrap_deg(a):
    return (a + 180.0) % 360.0 - 180.0


class PID2:
    """PID in arena coordinates, plus an optional disturbance observer (DOB).

    The DOB compares the measured velocity with the velocity the last commands
    should have produced (first-order model, DOB_GAIN m/s per RC) and cancels
    the difference, i.e. the current drift, within ~1 s.  The integral alone
    needs several seconds and lagged a drift that reversed mid-flight
    (7 Oct 19:59)."""

    def __init__(self, ki=KI, i_tau=I_TAU_S, dob_gain=DOB_GAIN_MPS_PER_RC, dob_frac=DOB_FRAC):
        self.ix = self.iy = 0.0
        self.ki = ki
        self.i_tau = i_tau
        self.dob_gain = dob_gain
        self.dob_frac = dob_frac
        self.u_prev = (0.0, 0.0)
        self.v_model = [0.0, 0.0]
        self.d = [0.0, 0.0]               # estimated drift velocity, m/s

    def update(self, ex, ey, vx, vy, dt):
        if abs(ex) < DEADBAND_M:
            ex = 0.0
        if abs(ey) < DEADBAND_M:
            ey = 0.0
        # A leak lets the integral follow a drift that changes direction within
        # one flight (FB -14 -> +11 on 7 Oct 19:59) instead of lagging behind it.
        keep = 1.0 - dt / self.i_tau if self.i_tau > 0 else 1.0
        self.ix = float(np.clip(self.ix * keep + self.ki * ex * dt, -I_LIMIT_RC, I_LIMIT_RC))
        self.iy = float(np.clip(self.iy * keep + self.ki * ey * dt, -I_LIMIT_RC, I_LIMIT_RC))
        ux = KP * ex + self.ix - KD * vx
        uy = KP * ey + self.iy - KD * vy
        if self.dob_gain > 0:
            a = min(1.0, dt / DOB_PLANT_TAU_S)
            b = min(1.0, dt / DOB_FILTER_TAU_S)
            for i, (u, v) in enumerate(zip(self.u_prev, (vx, vy))):
                self.v_model[i] += a * (self.dob_gain * u - self.v_model[i])
                self.d[i] += b * ((v - self.v_model[i]) - self.d[i])
                self.d[i] = float(np.clip(self.d[i], -DOB_MAX_MPS, DOB_MAX_MPS))
            ux -= self.dob_frac * self.d[0] / self.dob_gain
            uy -= self.dob_frac * self.d[1] / self.dob_gain
        ux = float(np.clip(ux, -RC_MAX, RC_MAX))
        uy = float(np.clip(uy, -RC_MAX, RC_MAX))
        self.u_prev = (ux, uy)
        return ux, uy

    def skip(self):
        """No command was sent this cycle (vision gap)."""
        self.u_prev = (0.0, 0.0)


# ---------------- simulation ----------------
class SimDrone(FakeTello):
    """Pretend Tello that moves: first-order response to RC plus a constant
    forward (-Y) drift; publishes its own pose (no camera needed)."""
    GAIN_MPS_PER_RC = 0.006         # ~RC10 -> 6 cm/s (V4.1 matrix magnitude)
    TAU_S = 0.35
    DRIFT = (0.0, -0.04)            # m/s, measured 7 Oct (overridden by --sim-drift)
    LURCH_MPS = 0.0                 # random lurch speed (--sim-lurch)
    DRIFT_PERIOD_S = 0.0            # >0: drift reverses as cos(2*pi*t/period) (--sim-drift-period)
    NOISE_M = 0.003

    def __init__(self):
        super().__init__()
        self.x, self.y = 1.067, 1.067
        self.vx = self.vy = 0.0
        self.cmd = (0.0, 0.0)
        self.z_cm = 80.0
        self.ud = 0
        self.t = time.perf_counter()
        self.rng = np.random.default_rng(1)

    def takeoff(self):
        super().takeoff()
        self.t = time.perf_counter()        # no drift integrated for the time on the ground

    def send_rc_control(self, lr, fb, ud, yaw):
        super().send_rc_control(lr, fb, ud, yaw)
        self.cmd = (lr, fb)
        self.ud = ud

    def get_distance_tof(self):
        return int(self.z_cm) if self.is_flying else 10

    def step(self):
        now = time.perf_counter()
        dt = now - self.t
        self.t = now
        if not self.is_flying:
            return
        lr, fb = self.cmd
        if not hasattr(self, "t_fly"):
            self.t_fly = now
        scale = math.cos(2 * math.pi * (now - self.t_fly) / self.DRIFT_PERIOD_S) \
            if self.DRIFT_PERIOD_S > 0 else 1.0
        tvx = self.GAIN_MPS_PER_RC * lr + self.DRIFT[0] * scale
        tvy = -self.GAIN_MPS_PER_RC * fb + self.DRIFT[1] * scale
        if self.LURCH_MPS:
            # a ~1 s lurch in a random direction roughly every 6 s
            if not hasattr(self, "lurch_until"):
                self.lurch_until, self.lurch_v = 0.0, (0.0, 0.0)
            if now > self.lurch_until + 5.0 and self.rng.random() < dt / 1.0:
                ang = self.rng.uniform(0, 2 * math.pi)
                self.lurch_v = (self.LURCH_MPS * math.cos(ang), self.LURCH_MPS * math.sin(ang))
                self.lurch_until = now + 1.0
            if now < self.lurch_until:
                tvx += self.lurch_v[0]
                tvy += self.lurch_v[1]
        a = min(1.0, dt / self.TAU_S)
        self.vx += a * (tvx - self.vx)
        self.vy += a * (tvy - self.vy)
        self.x += self.vx * dt
        self.y += self.vy * dt
        self.z_cm = max(10.0, self.z_cm + self.ud * 1.0 * dt)   # ~RC1 -> 1 cm/s


class SimVision:
    def __init__(self, drone):
        self.drone = drone
        self.seq = 0

    def stop(self):
        pass

    def get_state(self, marker):
        d = self.drone
        d.step()
        self.seq += 1
        now = time.perf_counter()
        h = (d.get_distance_tof() if d.is_flying else 9.3) / 100.0
        k = CAMERA_HEIGHT_M / (CAMERA_HEIGHT_M - h)
        n = d.rng.normal(0, d.NOISE_M, 2)
        return {"detected": True,
                "x": NADIR_XY[0] + (d.x - NADIR_XY[0]) * k + n[0],
                "y": NADIR_XY[1] + (d.y - NADIR_XY[1]) * k + n[1],
                "angle": 0.0, "source": "SIM", "frame_read_timestamp": now,
                "frame_sequence": self.seq, "last_detection_timestamp": now,
                "fps": 30.0}


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--marker", type=int, default=1)
    ap.add_argument("--tello-ip", default="192.168.10.1")
    ap.add_argument("--port", type=int, default=POSE_PORT)
    ap.add_argument("--hold", type=float, default=None,
                    help=f"hold seconds at the origin (default {HOLD_S:g}; 3 with --wp; max 30)")
    ap.add_argument("--wp", default="",
                    help='waypoints as "dx,dy;dx,dy" in cm from the origin, e.g. "10,0" or "10,0;10,10"')
    ap.add_argument("--sim", action="store_true", help="simulated drifting drone, nothing flies")
    ap.add_argument("--sim-drift", default="0,-4", help="sim drift vx,vy in cm/s")
    ap.add_argument("--sim-lurch", type=float, default=0.0, help="sim lurch speed cm/s")
    ap.add_argument("--sim-drift-period", type=float, default=0.0,
                    help="sim: drift reverses with this period in s (0 = constant)")
    ap.add_argument("--ki", type=float, default=KI, help="integral gain (tuning)")
    ap.add_argument("--i-tau", type=float, default=I_TAU_S, help="integral leak time constant s (0 = none)")
    ap.add_argument("--kp", type=float, default=None, help="proportional gain (tuning)")
    ap.add_argument("--kd", type=float, default=None, help="derivative gain (tuning)")
    ap.add_argument("--dob-gain", type=float, default=DOB_GAIN_MPS_PER_RC * 100,
                    help="DOB plant gain in cm/s per RC (0 = DOB off)")
    ap.add_argument("--dob-frac", type=float, default=DOB_FRAC)
    ap.add_argument("--sim-gain", type=float, default=None,
                    help="sim plant gain cm/s per RC (to test a wrong DOB gain)")
    ap.add_argument("--sim-start", default=None, help="sim start position x,y in m")
    ap.add_argument("--swarm", action="store_true",
                    help="swarm agent: wait for GO from swarm_coordinator.py, report status, "
                         "land on LAND_ALL / coordinator loss / another drone too close")
    ap.add_argument("--confirm", default="", help=f"arming token: {TOKEN}")
    args = ap.parse_args()
    waypoints = []
    for i, part in enumerate(p for p in args.wp.split(";") if p.strip()):
        dx, dy = (float(v) / 100.0 for v in part.split(","))
        if math.hypot(dx, dy) > WP_MAX_OFFSET_M:
            raise SystemExit(f"WP{i+1} offset > {WP_MAX_OFFSET_M*100:.0f} cm")
        waypoints.append((f"WP{i+1}", dx, dy))
    global KP, KD
    if args.kp is not None:
        KP = args.kp
    if args.kd is not None:
        KD = args.kd
    if args.hold is None:
        args.hold = 3.0 if waypoints else HOLD_S
    token = WP_TOKEN if waypoints else TOKEN
    if not args.sim and args.confirm != token:
        raise SystemExit(f"Not armed. Real flight needs: --confirm {token}")
    if not 0 < args.hold <= 30:
        raise SystemExit("--hold must be 0..30 s")

    signal.signal(signal.SIGTERM, on_sigterm)
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    stem = LOG_DIR / (f"step11_hold_{datetime.now().strftime('%Y%m%d_%H%M%S')}_id{args.marker}"
                      f"{'_swarm' if args.swarm else ''}"
                      f"{'_SIM' if args.sim else ''}")

    print("=" * 64)
    print(f" STEP 11 HOLD  RC +/-{RC_MAX}  Kp={KP:g} Ki={args.ki:g} Kd={KD:g} "
          f"Itau={args.i_tau:g}s DOB={args.dob_gain:g}cm/s/RC x{args.dob_frac:g}  marker ID{args.marker}"
          + ("   *** SIM ***" if args.sim else ""))
    print("=" * 64)

    if args.sim:
        tello = SimDrone()
        if args.sim_start:
            tello.x, tello.y = (float(v) for v in args.sim_start.split(","))
        tello.DRIFT = tuple(float(v) / 100.0 for v in args.sim_drift.split(","))
        tello.LURCH_MPS = args.sim_lurch / 100.0
        tello.DRIFT_PERIOD_S = args.sim_drift_period
        if args.sim_gain is not None:
            tello.GAIN_MPS_PER_RC = args.sim_gain / 100.0
        vision = SimVision(tello)
    else:
        vision = VisionClient(port=args.port, video=False).start()
        from djitellopy import Tello
        Tello.LOGGER.setLevel(logging.ERROR)
        tello = Tello(host=args.tello_ip)

    rows = []
    airborne = False
    reason = "COMPLETE"
    t_start = time.perf_counter()
    heading_ref = None
    wp_results = []
    link = SwarmLink().start() if args.swarm else None
    sw = {"state": "STARTING", "fault": "", "x": None, "y": None, "last_tx": 0.0,
          "run": None, "battery": None}

    def send_status(force=False):
        if link is None:
            return
        now = time.perf_counter()
        if not force and now - sw["last_tx"] < SWARM_STATUS_DT:
            return
        sw["last_tx"] = now
        link.send({"type": "status", "marker": args.marker, "state": sw["state"],
                   "fault": sw["fault"], "x": sw["x"], "y": sw["y"], "airborne": airborne,
                   "battery": sw["battery"], "run": sw["run"], "host": socket.gethostname()})

    def heartbeat():
        # Status keeps flowing while the main thread blocks in takeoff()/land()
        # (5-8 s); otherwise the coordinator sees silence and lands everyone.
        while link is not None and sw.get("hb", True):
            send_status(force=True)
            time.sleep(SWARM_STATUS_DT)

    if link is not None:
        threading.Thread(target=heartbeat, daemon=True).start()

    def swarm_checks(P):
        """In the air: coordinator alive and not LAND_ALL; no drone too close."""
        if link is None:
            return
        cmd, age = link.command()
        if age > SWARM_LINK_TIMEOUT_S:
            raise Abort(f"COORDINATOR_LOST ({age:.1f} s)")
        if cmd and cmd.get("cmd") == "LAND_ALL":
            raise Abort(f"LAND_ALL from coordinator ({cmd.get('why', '')})")
        if P is None:
            return
        others = []
        for m, peer in link.peers(args.marker).items():
            if peer.get("x") is not None and peer.get("airborne"):
                others.append((f"ID{m} status", peer["x"], peer["y"]))
        if hasattr(vision, "markers"):
            h = 0.8
            for m, mk in vision.markers().items():
                if m != args.marker:
                    others.append((f"ID{m} camera",) + correct_parallax(mk["x"], mk["y"], h))
        for name, ox, oy in others:
            d = math.hypot(P[0] - ox, P[1] - oy)
            if d < SEPARATION_M:
                raise Abort(f"SEPARATION {d*100:.0f} cm to {name}")

    def read_tof():
        try:
            if args.sim:
                return tello.get_distance_tof()
            return int(tello.get_current_state().get("tof", -1))
        except Exception:
            return None

    tof_hist = []

    def observe(phase):
        """Fresh corrected pose or None; enforces vision/ToF/heading safety."""
        now = time.perf_counter()
        st = vision.get_state(args.marker)
        tof = read_tof()
        if airborne and now - st["last_detection_timestamp"] > VISION_LAND_S:
            raise Abort("VISION_LOST")
        if airborne and phase not in ("STABILIZE", "DESCEND") and tof is not None and tof > 0 \
                and not TOF_MIN_CM <= tof <= TOF_MAX_CM:
            raise Abort(f"TOF_OUT_OF_RANGE {tof} cm")
        if not vision_is_fresh(st):
            if airborne:
                swarm_checks(None)
            send_status()
            return st, None, tof
        # Height for the parallax correction: median of the last ~1 s of ToF,
        # clamped.  Drone 2's ToF jumped 35 <-> 71 cm within a second (7 Oct
        # 20:55); used raw, each jump moved the corrected position and gave
        # false velocity spikes.
        if tof is not None and TOF_H_MIN_CM <= tof <= TOF_H_MAX_CM:
            tof_hist.append(tof)
            del tof_hist[:-TOF_H_WINDOW]
        h = (float(np.median(tof_hist)) if tof_hist else 80.0) / 100.0
        P = correct_parallax(st["x"], st["y"], h)
        sw["x"], sw["y"], sw["state"] = P[0], P[1], phase
        if airborne:
            swarm_checks(P)
        send_status()
        if heading_ref is not None and abs(wrap_deg(st["angle"] - heading_ref)) > HEADING_TOL_DEG:
            raise Abort(f"HEADING {st['angle']:+.1f} deg vs ref {heading_ref:+.1f}")
        return st, P, tof

    try:
        time.sleep(0.2 if args.sim else 1.5)
        st = vision.get_state(args.marker)
        if not vision_is_fresh(st):
            raise Abort(f"No fresh ID{args.marker} from camera_host before takeoff")
        if not arena_safe(st["x"], st["y"]):
            raise Abort("Drone inside the arena margin before takeoff")
        print(f"Vision OK  ID{args.marker} X={st['x']:.3f} Y={st['y']:.3f} angle={st['angle']:+.1f}")
        tello.connect()
        battery = int(tello.get_battery())
        sw["battery"] = battery
        print(f"Battery    {battery}%")
        if battery < MIN_BATTERY:
            raise Abort("BATTERY_LOW")
        if not args.sim:
            temp = int(tello.get_current_state().get("temph", 0))
            print(f"Temp       {temp} C (max {MAX_TEMP_C})")
            if temp > MAX_TEMP_C:
                raise Abort(f"TOO_HOT {temp} C: power the drone off to cool, then fly soon after power-on")

        # Origin = the takeoff point, measured on the ground before takeoff.
        # Uncontrolled 6 s stabilisation let the drone wander up to ~55 cm
        # (7 Oct 19:22), so XY is now held on this point from takeoff onwards.
        pts, angs = [], []
        end = time.perf_counter() + ORIGIN_S
        while time.perf_counter() < end:
            st = vision.get_state(args.marker)
            if vision_is_fresh(st):
                pts.append(correct_parallax(st["x"], st["y"], GROUND_MARKER_H_M))
                angs.append(st["angle"])
            time.sleep(0.03)
        if len(pts) < 5:
            raise Abort("Origin: too few fresh frames before takeoff")
        origin = tuple(np.median(np.array(pts), axis=0))
        heading_ref = float(np.median(angs))
        print(f"Origin     X={origin[0]:.3f} Y={origin[1]:.3f} (takeoff point, corrected)  "
              f"heading {heading_ref:+.1f}")

        pid = PID2(args.ki, args.i_tau, args.dob_gain / 100.0, args.dob_frac)
        est = {"prev": None, "vx": 0.0, "vy": 0.0, "seq": -1, "last_print": 0.0,
               "target": origin}
        for name, dx, dy in waypoints:
            if not arena_safe(origin[0] + dx, origin[1] + dy):
                raise Abort(f"{name} would be inside the arena margin")
        hold_start = time.perf_counter()       # log time base (reset at takeoff)

        def tick(phase, rc_z):
            """One 10 Hz control step towards est["target"] (XY PID, given
            vertical RC); returns (ToF, error distance or None, speed)."""
            now = time.perf_counter()
            st, P, tof = observe(phase)
            prev, vx, vy = est["prev"], est["vx"], est["vy"]
            last_seq = est["seq"]
            lr = fb = 0
            ex = ey = None
            if P is not None:
                if st["frame_sequence"] != last_seq:
                    if prev is not None and st["frame_read_timestamp"] > prev[2]:
                        dt_f = st["frame_read_timestamp"] - prev[2]
                        vx += VEL_ALPHA * ((P[0] - prev[0]) / dt_f - vx)
                        vy += VEL_ALPHA * ((P[1] - prev[1]) / dt_f - vy)
                    prev = (P[0], P[1], st["frame_read_timestamp"])
                    last_seq = st["frame_sequence"]
                tx, ty = est["target"]
                ex, ey = tx - P[0], ty - P[1]
                dist = math.hypot(ex, ey)
                if dist > (MAX_DISTANCE_STABILIZE_M if phase == "STABILIZE" else MAX_DISTANCE_M):
                    raise Abort(f"DISTANCE {dist*100:.1f} cm")
                # True position for the 20 cm margin: the apparent one is magnified
                # ~1.5x from the camera nadir at flight height, which tripped the
                # margin 30-40 cm early for drones placed off-centre (swarm).
                if not arena_safe(P[0], P[1]) or not in_camera_area(st["x"], st["y"]):
                    raise Abort(f"ARENA_MARGIN true=({P[0]:.2f},{P[1]:.2f}) "
                                f"seen=({st['x']:.2f},{st['y']:.2f})")
                ux, uy = pid.update(ex, ey, vx, vy, CONTROL_DT)
                lr, fb = (int(round(v)) for v in arena_to_rc(ux, uy))
            else:
                pid.skip()
            est.update(prev=prev, vx=vx, vy=vy, seq=last_seq)
            tello.send_rc_control(lr, fb, rc_z, 0)
            rows.append({
                "t": now - t_start, "t_hold": now - hold_start, "phase": phase,
                "x_raw": st["x"], "y_raw": st["y"],
                "x": P[0] if P else None, "y": P[1] if P else None,
                "ex_cm": ex * 100 if ex is not None else None,
                "ey_cm": ey * 100 if ey is not None else None,
                "vx_cm_s": vx * 100, "vy_cm_s": vy * 100,
                "i_x": pid.ix, "i_y": pid.iy, "rc_lr": lr, "rc_fb": fb,
                "dob_x_cm_s": pid.d[0] * 100, "dob_y_cm_s": pid.d[1] * 100,
                "rc_z": rc_z, "angle": st["angle"], "tof_cm": tof,
                "target_x": est["target"][0], "target_y": est["target"][1],
            })
            if now - est["last_print"] >= 1.0 and ex is not None:
                est["last_print"] = now
                print(f"  {phase:7s} t={now-hold_start:4.1f}s  EX={ex*100:+5.1f} EY={ey*100:+5.1f} cm  "
                      f"V=({vx*100:+4.1f},{vy*100:+4.1f}) cm/s  LR={lr:+3d} FB={fb:+3d}  "
                      f"I=({pid.ix:+4.1f},{pid.iy:+4.1f})  ToF={tof}")
            return tof, (math.hypot(ex, ey) if ex is not None else None), math.hypot(vx, vy)

        if link is not None:
            print("SWARM      READY - waiting for GO from swarm_coordinator.py ...")
            sw.update(state="READY", x=origin[0], y=origin[1])
            w0 = time.perf_counter()
            last_temp = w0
            while True:
                send_status()
                cmd, age = link.command()
                waited = time.perf_counter() - w0
                if cmd is None and waited > SWARM_FIRST_CONTACT_S:
                    raise Abort("NO_COORDINATOR (none heard in "
                                f"{SWARM_FIRST_CONTACT_S:.0f} s; start swarm_coordinator.py)")
                if cmd is not None and age > SWARM_LINK_TIMEOUT_S * 2:
                    raise Abort("COORDINATOR_LOST before GO")
                if cmd and cmd.get("cmd") == "LAND_ALL":
                    raise Abort(f"LAND_ALL before takeoff ({cmd.get('why', '')})")
                if cmd and cmd.get("cmd") == "GO":
                    sw["run"] = cmd.get("run")
                    print(f"SWARM      GO received (run {sw['run']})")
                    break
                if waited > SWARM_WAIT_S:
                    raise Abort("No GO within the wait limit")
                if not args.sim and time.perf_counter() - last_temp > 5.0:
                    last_temp = time.perf_counter()
                    temp = int(tello.get_current_state().get("temph", 0))
                    if temp > MAX_TEMP_C:
                        raise Abort(f"TOO_HOT {temp} C while waiting for GO")
                st = vision.get_state(args.marker)
                if vision_is_fresh(st) and math.hypot(
                        *(np.subtract(correct_parallax(st["x"], st["y"], GROUND_MARKER_H_M),
                                      origin))) > 0.05:
                    raise Abort("Drone moved on the ground while waiting for GO")
                time.sleep(0.1)

        print("Taking off...")
        sw["state"] = "TAKEOFF"
        send_status(force=True)
        airborne = True
        tello.takeoff()
        tello.send_rc_control(0, 0, 0, 0)
        hold_start = time.perf_counter()

        print(f"Stabilising {STABILIZE_S:.0f} s with XY hold on the takeoff point...")
        tofs = []
        nxt = hold_start
        while True:
            tof, _, _ = tick("STABILIZE", 0)
            now = time.perf_counter()
            if tof and tof > 0:
                tofs.append((now, tof))
            tofs = [(t, v) for t, v in tofs if now - t <= TOF_STEADY_WINDOW_S]
            if now - hold_start >= STABILIZE_S and tofs \
                    and now - tofs[0][0] >= TOF_STEADY_WINDOW_S * 0.8:
                vals = [v for _, v in tofs]
                if max(vals) - min(vals) <= TOF_STEADY_SPREAD_CM:
                    print(f"ToF steady {min(vals)}-{max(vals)} cm after {now - hold_start:.1f} s")
                    break
            if now - hold_start > STABILIZE_S + TOF_STEADY_TIMEOUT_S:
                raise Abort("ToF never steady after takeoff")
            nxt += CONTROL_DT
            time.sleep(max(0.0, nxt - time.perf_counter()))

        hold_t0 = time.perf_counter()
        while time.perf_counter() - hold_t0 < args.hold:
            tick("HOLD", 0)
            nxt += CONTROL_DT
            time.sleep(max(0.0, nxt - time.perf_counter()))

        for name, dx, dy in waypoints:
            print(f"{name}: target X={origin[0] + dx:.3f} Y={origin[1] + dy:.3f} "
                  f"(origin {dx*100:+.0f},{dy*100:+.0f} cm)")
            wp_start = time.perf_counter()
            ramp_from = est["target"]
            goal = (origin[0] + dx, origin[1] + dy)
            ramp_len = math.hypot(goal[0] - ramp_from[0], goal[1] - ramp_from[1])
            inside_since = None
            record = {"name": name, "offset_cm": [dx * 100, dy * 100], "accepted": False}
            wp_results.append(record)
            while True:
                frac = min(1.0, (time.perf_counter() - wp_start) * WP_RAMP_MPS / ramp_len) \
                    if ramp_len > 0 else 1.0
                est["target"] = (ramp_from[0] + frac * (goal[0] - ramp_from[0]),
                                 ramp_from[1] + frac * (goal[1] - ramp_from[1]))
                _, err, speed = tick(name, 0)
                now = time.perf_counter()
                if frac >= 1.0 and err is not None and err < WP_TOL_M and speed < WP_SPEED_TOL_MPS:
                    inside_since = inside_since or now
                    if now - inside_since >= WP_SETTLE_S:
                        record.update(accepted=True, time_s=round(now - wp_start, 2),
                                      error_cm=round(err * 100, 2))
                        print(f"{name} ACCEPTED after {now - wp_start:.1f} s "
                              f"(error {err*100:.1f} cm)")
                        break
                else:
                    inside_since = None
                if now - wp_start > WP_TIMEOUT_S:
                    record.update(time_s=round(now - wp_start, 2),
                                  error_cm=round(err * 100, 2) if err is not None else None)
                    print(f"{name} TIMEOUT after {WP_TIMEOUT_S:.0f} s")
                    break
                nxt += CONTROL_DT
                time.sleep(max(0.0, nxt - time.perf_counter()))
            if not record["accepted"]:
                break

        if waypoints:
            f_end = time.perf_counter() + FINAL_HOLD_S
            while time.perf_counter() < f_end:
                tick("FINAL", 0)
                nxt += CONTROL_DT
                time.sleep(max(0.0, nxt - time.perf_counter()))

        print(f"Descending to {DESCEND_TO_CM} cm with XY hold...")
        d_start = time.perf_counter()
        while True:
            tof, _, _ = tick("DESCEND", DESCEND_RC)
            if tof is not None and 0 < tof <= DESCEND_TO_CM:
                print(f"  reached ToF {tof} cm")
                break
            if time.perf_counter() - d_start > DESCEND_TIMEOUT_S:
                print("  descent timeout; landing from here")
                break
            nxt += CONTROL_DT
            time.sleep(max(0.0, nxt - time.perf_counter()))

    except Abort as exc:
        reason = f"ABORT: {exc}"
    except KeyboardInterrupt:
        reason = "ABORT: user stop"
    except Exception as exc:
        reason = f"ERROR: {type(exc).__name__}: {exc}"
    finally:
        try:
            tello.send_rc_control(0, 0, 0, 0)
        except Exception as exc:
            print("[WARN] stop RC:", exc)
        if link is not None:
            sw.update(state="LANDING" if airborne else "ENDED",
                      fault="" if reason == "COMPLETE" else reason)
            send_status(force=True)
        if airborne:
            time.sleep(PRE_LAND_PAUSE_S)
            print("Landing...")
            try:
                tello.land()
            except Exception as exc:
                print(f"[NOTE] land not confirmed ({exc}); sending again")
                try:
                    tello.send_command_without_return("land")
                except Exception:
                    pass
        try:
            tello.end()
        except Exception:
            pass
        vision.stop()
        if link is not None:
            sw.update(state="LANDED" if reason == "COMPLETE" else "ABORTED", x=None, y=None)
            airborne = False
            time.sleep(1.6)                  # heartbeat thread reports the final state
            sw["hb"] = False
            time.sleep(0.3)
            link.stop()

    print(f"Result     {reason}")
    summary = {"result": reason, "sim": args.sim, "waypoints": wp_results,
               "mission": ("COMPLETE" if waypoints and reason == "COMPLETE"
                           and all(w["accepted"] for w in wp_results)
                           and len(wp_results) == len(waypoints)
                           else ("INCOMPLETE" if waypoints else "HOLD_ONLY")),
               "gains": {"KP": KP, "KI": args.ki, "KD": KD, "RC_MAX": RC_MAX,
                         "I_TAU_S": args.i_tau, "DOB_GAIN_CM_S_PER_RC": args.dob_gain,
                         "DOB_FRAC": args.dob_frac}}
    if rows:
        with open(str(stem) + ".csv", "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            w.writeheader()
            w.writerows(rows)
        good = [r for r in rows if r["ex_cm"] is not None and r["phase"] != "STABILIZE"]
        t_first = good[0]["t_hold"] if good else 0.0
        late = [r for r in good if r["t_hold"] - t_first >= min(5.0, args.hold / 2)]
        if good:
            err = np.hypot([r["ex_cm"] for r in good], [r["ey_cm"] for r in good])
            summary["hold"] = {
                "samples": len(good),
                "max_error_cm": round(float(err.max()), 2),
                "final_error_cm": round(float(err[-1]), 2),
            }
            if late:
                el = np.hypot([r["ex_cm"] for r in late], [r["ey_cm"] for r in late])
                summary["hold"]["after_settle_mean_cm"] = round(float(el.mean()), 2)
                summary["hold"]["after_settle_max_cm"] = round(float(el.max()), 2)
                summary["hold"]["learned_bias_rc"] = [
                    round(float(np.mean([r["rc_lr"] for r in late])), 1),
                    round(float(np.mean([r["rc_fb"] for r in late])), 1)]
        print(f"CSV        {stem}.csv")
    with open(str(stem) + ".json", "w") as f:
        json.dump(summary, f, indent=2)
    print(json.dumps(summary, indent=2))
    return 0 if reason == "COMPLETE" else 1


if __name__ == "__main__":
    sys.exit(main())
