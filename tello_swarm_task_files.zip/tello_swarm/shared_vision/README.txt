SHARED VISION  -  one overhead camera, several flight Pis
==========================================================

Put this folder inside tello_swarm/ (next to practical02/ and practical04/).
Nothing to install: it uses the OpenCV, NumPy and djitellopy already in swarm_env.
None of the existing practical01-04 files are changed or needed by the flight Pis.


1. CAMERA PI  (the one Pi with the overhead camera)

       cd ~/tello_swarm && source swarm_env/bin/activate
       python3 shared_vision/camera_host.py

   It needs practical02/arena_homography.npy on this Pi.
   Watch it from any browser on the network:  http://<camera-pi-address>:8080/
   Only this program may use the camera: stop camera_monitor.py and the old
   flight scripts on this Pi first.


2. EACH FLIGHT PI  (Wi-Fi joined to its own TELLO-xxxx, Ethernet cable to the
                    same switch/router as the camera Pi)

       cd ~/tello_swarm && source swarm_env/bin/activate
       python3 shared_vision/fly_step10.py --marker 1        (2, 3, 4 on the others)

   The window opens with the overhead view and the status panel. Keys:

       A            arm / disarm
       T            take off and fly the Step 10 mission   (only while ARMED)
       L or SPACE   land now
       E            EMERGENCY: stop the motors at once (the drone drops)
       Q            quit (lands first if flying)

   Click the window before typing, or type in the terminal you started it from.
   No screen on that Pi?  It runs anyway: status and keys in the terminal.


3. CHECK THE LINK from any Pi

       python3 shared_vision/vision_client.py

   Prints the host address, frame rate, frame age and every marker it sees.


ONE PI ONLY  (camera and drone on the same Pi, as before)

   Terminal 1:  python3 shared_vision/camera_host.py
   Terminal 2:  python3 shared_vision/fly_step10.py


DRY RUN: "BE THE DRONE"  (Day 3 practical: real shared camera, pretend Tello)

       python3 shared_vision/fly_step10.py --sim --marker 1     (each group its own ID)

   Camera host running as usual, a printed marker on the arena floor at least
   40 cm from every border, no drone. A, then T; about 12 s later the badge
   shows MISSION and a red target appears 10 cm from the marker along X.
   What the message bar shows when the run ends:

       marker slid to the target and left still   Last state: VEL_SETTLE
       marker slid away from the target           ERROR_FAILSAFE (VEL_AXIS_DIVERGENCE)
       marker not moved (six pulses, ~4 s)        ERROR_FAILSAFE (VEL_PULSE_LIMIT)
       marker covered by a hand                   VISION_LAND

   No command leaves the Pi in --sim mode. Each run still writes a CSV log.


OBSERVE FLIGHT  (Day 2 practical, Task 3: shared-camera version of P03-C)

       python3 shared_vision/observe_flight.py --marker 1      (--sim for no drone)

   Same window and keys as fly_step10.py: A, then T. The drone takes off,
   hovers 10 s and lands; the marker position is logged from the shared
   camera. No XY control and no altitude control: the only RC command sent
   is the neutral stick. It lands by itself if the drone drifts into the
   20 cm arena margin. Log: logs/observe_flight_id<N>_<time>.csv, same
   columns as the P03-C log.


VERTICAL PROJECTION  (Day 2 practical, Task 4: shared-camera version of P04-B)

       python3 shared_vision/vertical_projection.py            (--marker N)

   No drone. Every group can run it at the same time on its own Pi while one
   marker is raised above P5. SPACE captures 20 samples at 0, 20, 40, 50, 60,
   70 cm; N skips; Q quits. Log: logs/vertical_projection_<time>.csv, same
   columns as the P04-B log.


THREE POSITIONS  (Day 4 practical, no drone)

       python3 shared_vision/multi_id_position.py

   Shows ID1, ID2, ID3 in metres and the distance between every pair, from the
   shared camera. P prints them, Q quits. It also runs from a copy placed in
   tello_swarm/practical05/, as the participant module describes.


BENCH TEST  (no camera, no drone, any computer)

       python3 shared_vision/camera_host.py --simulate
       python3 shared_vision/fly_step10.py --sim

   The simulated marker does not react to commands, so a simulated mission
   always ends with "ERROR_FAILSAFE (VEL_PULSE_LIMIT)" after six pulses.
   That is expected.


BEFORE CLASS

   * Every Pi (camera Pi + flight Pis) on ONE Ethernet switch or router, each
     with its own address. The laptops used for SSH go on the same switch.
     Wi-Fi of each flight Pi stays on its own TELLO-xxxx.
   * Only one program can open the camera. These older scripts open it
     themselves, so run them ON THE CAMERA PI with camera_host.py stopped:
     focus_tuner.py, arena_calibration_v4_final.py,
     validate_floor_5point_newcamera.py, p04b1_auto_mapping_v2.py,
     p04a4_vision_zhold_logger.py, p04b1_step10_brake_settle.py, and the
     two backups tello_flight_vision_raw_v2.py and
     p04b_vertical_projection_test.py.
     Start camera_host.py again afterwards.
   * One marker ID per drone in the camera's view. Two markers with the same
     ID confuse the tracking: give each group its own ID (1 to 4) and keep
     spare prints out of the picture.
   * After re-calibrating the arena, restart camera_host.py so that it loads
     the new practical02/arena_homography.npy.


FILES

   camera_host.py     camera, marker tracking, pose broadcast (UDP 9870), video (HTTP 8080)
   vision_client.py   receives poses + video on a flight Pi; also the link checker
   fly_step10.py      Step 10 flight with display and keyboard control
   observe_flight.py  take off, hover 10 s, log the position (Day 2, Task 3)
   vertical_projection.py   position error against marker height (Day 2, Task 4)
   multi_id_position.py     three marker positions and their distances (Day 4)
   aruco_id_4.png     marker for a fourth drone (same style as practical02/markers)
   Flight logs are written to shared_vision/logs/ (same columns as the Step 10 CSV).
