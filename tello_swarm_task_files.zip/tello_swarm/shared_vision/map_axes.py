#!/usr/bin/env python3
"""
MAP AXES  -  one short flight that measures which way ONE stick axis moves the
drone in the arena frame of the current camera homography.
==============================================================================

Needs camera_host.py running (any Pi on the network).  No keyboard, no window:
it is armed on the command line, so it can be started over SSH / remote control.

    python3 map_axes.py --axis fb --sim                      # dry run, no drone
    python3 map_axes.py --axis fb --confirm MAP-FB+6         # real flight
    python3 map_axes.py --axis lr --confirm MAP-LR+6         # second flight

One flight = one pulse:
    take off -> stabilise 5 s (RC 0) -> capture origin 1 s -> baseline 3 s (RC 0)
    -> ONE pulse  (axis = sign*RC, 0.40 s) -> observe 1.0 s (RC 0) -> land

Automatic stops (RC 0 then land): marker lost > 1.0 s, displacement from the
origin > 12 cm, arena margin 20 cm, ToF outside 30-160 cm, Ctrl+C / SIGTERM,
any error.  No altitude or position control: the Tello holds itself.

Writes logs/map_axes_<axis><sign>_<ts>.csv and a .json summary with the
response direction in arena degrees (0 = +X, 90 = +Y).
"""
import argparse
import csv
import json
import logging
import math
import signal
import sys
import time
from datetime import datetime
from pathlib import Path

import numpy as np

from vision_client import POSE_PORT, VisionClient
from fly_step10 import FakeTello, vision_is_fresh

MIN_BATTERY = 50
STABILIZE_S = 5.0
ORIGIN_S = 1.0
BASELINE_S = 3.0
PULSE_S = 0.40
OBSERVE_S = 1.0
LOOP_DT = 0.05                 # 20 Hz

MAX_RC = 6
MAX_DISPLACEMENT_M = 0.12
VISION_STOP_S = 0.5            # RC 0
VISION_LAND_S = 1.0            # land
ARENA_W = ARENA_H = 2.1336
ARENA_MARGIN_M = 0.20
TOF_MIN_CM, TOF_MAX_CM = 30, 160

BASE_DIR = Path(__file__).resolve().parent
LOG_DIR = BASE_DIR / "logs"


class Abort(Exception):
    pass


def on_sigterm(signum, frame):
    raise KeyboardInterrupt


def arena_safe(x, y):
    return (ARENA_MARGIN_M <= x <= ARENA_W - ARENA_MARGIN_M
            and ARENA_MARGIN_M <= y <= ARENA_H - ARENA_MARGIN_M)


def fit_line(t, v):
    """Least-squares v = a + b t; returns (a, b)."""
    t = np.asarray(t, float)
    v = np.asarray(v, float)
    b, a = np.polyfit(t, v, 1)
    return a, b


def analyse(rows, axis, sign, rc):
    """Response = motion after pulse start minus the baseline drift extrapolated."""
    base = [r for r in rows if r["phase"] == "BASELINE" and r["fresh"]]
    resp = [r for r in rows if r["phase"] in ("PULSE", "OBSERVE") and r["fresh"]]
    if len(base) < 20 or len(resp) < 10:
        return {"ok": False, "reason": f"too few samples (baseline {len(base)}, response {len(resp)})"}
    t0 = next(r["t"] for r in rows if r["phase"] == "PULSE")
    tb = [r["t"] - t0 for r in base]
    ax, bx = fit_line(tb, [r["x"] for r in base])
    ay, by = fit_line(tb, [r["y"] for r in base])
    tr = np.array([r["t"] - t0 for r in resp])
    dx = np.array([r["x"] for r in resp]) - (ax + bx * tr)
    dy = np.array([r["y"] for r in resp]) - (ay + by * tr)
    # Displacement at the last response samples (mean of last 5 = less noise).
    ex, ey = float(np.mean(dx[-5:])), float(np.mean(dy[-5:]))
    mag = math.hypot(ex, ey)
    resid = np.hypot(np.array([r["x"] for r in base]) - (ax + bx * np.array(tb)),
                     np.array([r["y"] for r in base]) - (ay + by * np.array(tb)))
    noise = float(np.sqrt(np.mean(resid ** 2)))
    angles = [r["angle"] for r in rows if r["fresh"] and r["angle"] is not None]
    return {
        "ok": True,
        "axis": axis, "command": f"{axis.upper()}{'+' if sign > 0 else '-'}{rc}",
        "baseline_velocity_cm_s": [round(bx * 100, 2), round(by * 100, 2)],
        "baseline_noise_rms_cm": round(noise * 100, 2),
        "response_cm": [round(ex * 100, 2), round(ey * 100, 2)],
        "response_magnitude_cm": round(mag * 100, 2),
        "response_direction_deg": round(math.degrees(math.atan2(ey, ex)), 1),
        "signal_to_noise": round(mag / noise, 1) if noise > 0 else None,
        "response_window_s": round(float(tr[-1]), 2),
        "marker_angle_median_deg": round(float(np.median(angles)), 1) if angles else None,
    }


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--axis", choices=["fb", "lr"], required=True)
    ap.add_argument("--sign", type=int, choices=[1, -1], default=1)
    ap.add_argument("--rc", type=int, default=6)
    ap.add_argument("--marker", type=int, default=1)
    ap.add_argument("--tello-ip", default="192.168.10.1")
    ap.add_argument("--port", type=int, default=POSE_PORT)
    ap.add_argument("--sim", action="store_true", help="pretend Tello, nothing flies")
    ap.add_argument("--confirm", default="", help="arming token, e.g. MAP-FB+6")
    args = ap.parse_args()

    if not 1 <= args.rc <= MAX_RC:
        raise SystemExit(f"--rc must be 1..{MAX_RC}")
    cmd = f"{args.axis.upper()}{'+' if args.sign > 0 else '-'}{args.rc}"
    token = f"MAP-{cmd}"
    if not args.sim and args.confirm != token:
        raise SystemExit(f"Not armed. Real flight needs: --confirm {token}")

    signal.signal(signal.SIGTERM, on_sigterm)
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    stem = LOG_DIR / (f"map_axes_{args.axis}{'p' if args.sign > 0 else 'm'}{args.rc}_"
                      f"{datetime.now().strftime('%Y%m%d_%H%M%S')}{'_SIM' if args.sim else ''}")

    pulse = (args.sign * args.rc, 0) if args.axis == "lr" else (0, args.sign * args.rc)
    print("=" * 64)
    print(f" MAP AXES  {cmd}  marker ID{args.marker}" + ("   *** SIM ***" if args.sim else ""))
    print("=" * 64)

    vision = VisionClient(port=args.port, video=False).start()
    if args.sim:
        tello = FakeTello()
    else:
        from djitellopy import Tello
        Tello.LOGGER.setLevel(logging.ERROR)
        tello = Tello(host=args.tello_ip)

    rows = []
    airborne = False
    t_start = time.perf_counter()
    reason = "COMPLETE"

    def sample(phase, rc_lr, rc_fb, origin=None):
        """One 20 Hz tick: safety checks, send RC, log."""
        now = time.perf_counter()
        st = vision.get_state(args.marker)
        fresh = vision_is_fresh(st)
        lost_for = now - st["last_detection_timestamp"]
        if not fresh:
            rc_lr = rc_fb = 0
        if airborne and lost_for > VISION_LAND_S:
            raise Abort(f"VISION_LOST {lost_for:.2f}s")
        tof = None
        try:
            tof = int(tello.get_current_state().get("tof", -1))
        except Exception:
            pass
        if airborne and phase != "STABILIZE" and tof is not None and tof > 0 \
                and not TOF_MIN_CM <= tof <= TOF_MAX_CM:
            raise Abort(f"TOF_OUT_OF_RANGE {tof} cm")
        if fresh and origin is not None:
            d = math.hypot(st["x"] - origin[0], st["y"] - origin[1])
            if d > MAX_DISPLACEMENT_M:
                raise Abort(f"DISPLACEMENT {d*100:.1f} cm")
        if fresh and airborne and phase != "STABILIZE" and not arena_safe(st["x"], st["y"]):
            raise Abort("ARENA_MARGIN")
        tello.send_rc_control(int(rc_lr), int(rc_fb), 0, 0)
        rows.append({
            "t": now - t_start, "phase": phase, "rc_lr": rc_lr, "rc_fb": rc_fb,
            "fresh": fresh, "x": st["x"], "y": st["y"], "angle": st["angle"],
            "frame_seq": st["frame_sequence"],
            "frame_age_s": now - st["frame_read_timestamp"], "tof_cm": tof,
        })
        return st, fresh

    def run_phase(phase, seconds, rc_lr=0, rc_fb=0, origin=None):
        end = time.perf_counter() + seconds
        nxt = time.perf_counter()
        while time.perf_counter() < end:
            sample(phase, rc_lr, rc_fb, origin)
            nxt += LOOP_DT
            time.sleep(max(0.0, nxt - time.perf_counter()))

    try:
        time.sleep(1.5)
        st = vision.get_state(args.marker)
        if not vision_is_fresh(st):
            raise Abort(f"No fresh ID{args.marker} from camera_host before takeoff")
        if not arena_safe(st["x"], st["y"]):
            raise Abort(f"Drone at ({st['x']:.2f},{st['y']:.2f}) is inside the 20 cm arena margin")
        print(f"Vision OK  ID{args.marker} at X={st['x']:.3f} Y={st['y']:.3f} "
              f"angle={st['angle']:+.1f}  fps={st['fps']:.1f}")

        tello.connect()
        battery = int(tello.get_battery())
        print(f"Battery    {battery}%")
        if battery < MIN_BATTERY:
            raise Abort("BATTERY_LOW")
        if not vision_is_fresh(vision.get_state(args.marker)):
            raise Abort("Vision lost before takeoff")

        print("Taking off...")
        airborne = True                      # every exit path from here lands
        tello.takeoff()
        tello.send_rc_control(0, 0, 0, 0)

        print(f"Stabilising {STABILIZE_S:.0f} s (RC 0)...")
        run_phase("STABILIZE", STABILIZE_S)

        xs, ys = [], []
        end = time.perf_counter() + ORIGIN_S
        while time.perf_counter() < end:
            st, fresh = sample("ORIGIN", 0, 0)
            if fresh:
                xs.append(st["x"]); ys.append(st["y"])
            time.sleep(LOOP_DT)
        if len(xs) < 10:
            raise Abort("Origin capture: too few fresh frames")
        origin = (float(np.median(xs)), float(np.median(ys)))
        print(f"Origin     X={origin[0]:.3f} Y={origin[1]:.3f}")
        if not arena_safe(*origin):
            raise Abort("Origin inside arena margin")

        print(f"Baseline   {BASELINE_S:.0f} s (RC 0)...")
        run_phase("BASELINE", BASELINE_S, origin=origin)
        print(f"PULSE      {cmd} for {PULSE_S:.2f} s")
        run_phase("PULSE", PULSE_S, *pulse, origin=origin)
        print(f"Observe    {OBSERVE_S:.1f} s (RC 0)")
        run_phase("OBSERVE", OBSERVE_S, origin=origin)

    except Abort as exc:
        reason = f"ABORT: {exc}"
    except KeyboardInterrupt:
        reason = "ABORT: user stop"
    except Exception as exc:
        reason = f"ERROR: {type(exc).__name__}: {exc}"
    finally:
        try:
            tello.send_rc_control(0, 0, 0, 0)
        except Exception as exc:
            print("[WARN] stop RC:", exc)
        if airborne:
            print("Landing...")
            try:
                tello.land()
            except Exception as exc:
                print(f"[NOTE] land not confirmed ({exc}); sending again")
                try:
                    tello.send_command_without_return("land")
                except Exception:
                    pass
        try:
            tello.end()
        except Exception:
            pass
        vision.stop()

    print(f"Result     {reason}")
    if rows:
        with open(str(stem) + ".csv", "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            w.writeheader()
            w.writerows(rows)
        print(f"CSV        {stem}.csv")
    summary = {"result": reason, "sim": args.sim, "command": cmd,
               "analysis": analyse(rows, args.axis, args.sign, args.rc)
               if any(r["phase"] == "PULSE" for r in rows) else None}
    with open(str(stem) + ".json", "w") as f:
        json.dump(summary, f, indent=2)
    print(json.dumps(summary, indent=2))
    return 0 if reason == "COMPLETE" else 1


if __name__ == "__main__":
    sys.exit(main())
