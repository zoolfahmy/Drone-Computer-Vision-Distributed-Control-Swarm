# Analyse a waypoint flight log
import csv

f = "logs/p04b1_step10_brake_settle_20261005_183710.csv"

rows = [r for r in csv.DictReader(open(f)) if r["error_x_m"]]

t = [float(r["time_s"]) for r in rows]
ex = [float(r["error_x_m"]) * 100 for r in rows]
ey = [float(r["error_y_m"]) * 100 for r in rows]

print("samples, duration (s) :", len(rows), round(t[-1], 2))
print("X error start, end (cm):", round(ex[0], 2), round(ex[-1], 2))
print("smallest |X error| (cm):", round(min(abs(v) for v in ex), 2))
print("largest  |Y error| (cm):", round(max(abs(v) for v in ey), 2))
print("final state           :", rows[-1]["xy_state"])
