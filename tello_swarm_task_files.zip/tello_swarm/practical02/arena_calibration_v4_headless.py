#!/usr/bin/env python3
"""
ARENA CALIBRATION V4 HEADLESS
=============================

Same geometry as arena_calibration_v4_final.py (EMEET C980 Pro, 1280x720 MJPG,
reference IDs 40-43, same explicit inner corners, 800x800 warp, 2.1336 m arena),
but with no window and no keyboard, so it can be run over SSH / remote control.

Two separate steps:

    python3 arena_calibration_v4_headless.py
        Captures frames, uses the median inner corner of each reference marker
        over all frames where 40-43 are all visible, and writes a CANDIDATE:
            logs/calib_candidate_<ts>.npy
            logs/calib_candidate_<ts>_camera.jpg   (annotated camera view)
            logs/calib_candidate_<ts>_bird.jpg     (bird-eye with 10 cm grid)
        The active homography is NOT touched.

    python3 arena_calibration_v4_headless.py --commit logs/calib_candidate_<ts>.npy
        Backs up the current arena_homography.npy and
        arena_homography_emeet_c980_1280x720.npy, then installs the candidate
        into both (same two files the V4 GUI script saves).

Only one program can open the camera: stop camera_host.py first.
"""
import argparse
import shutil
import sys
import time
from datetime import datetime
from pathlib import Path

import cv2
import numpy as np

BASE_DIR = Path(__file__).resolve().parent
LOG_DIR = BASE_DIR / "logs"
H_EMEET_FILE = BASE_DIR / "arena_homography_emeet_c980_1280x720.npy"
H_COMPAT_FILE = BASE_DIR / "arena_homography.npy"

CAMERA_ID = 0
FRAME_W, FRAME_H, CAMERA_FPS = 1280, 720, 30

ARENA_WIDTH_M = ARENA_HEIGHT_M = 2.1336
WARP_W = WARP_H = 800

REFERENCE_IDS = [40, 41, 42, 43]
DRONE_IDS = [1, 2, 3, 4]
INNER_CORNER_INDEX = {40: 2, 41: 0, 42: 1, 43: 0}

# Reject the capture if a reference corner jitters more than this (pixels, std).
MAX_CORNER_STD_PX = 1.5
MIN_GOOD_FRAMES = 20


def make_detector():
    parameters = cv2.aruco.DetectorParameters()
    parameters.cornerRefinementMethod = cv2.aruco.CORNER_REFINE_SUBPIX
    parameters.adaptiveThreshWinSizeMin = 3
    parameters.adaptiveThreshWinSizeMax = 53
    parameters.adaptiveThreshWinSizeStep = 4
    parameters.minMarkerPerimeterRate = 0.01
    parameters.maxMarkerPerimeterRate = 4.0
    parameters.polygonalApproxAccuracyRate = 0.05
    parameters.minCornerDistanceRate = 0.03
    parameters.minDistanceToBorder = 2
    dictionary = cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_50)
    return cv2.aruco.ArucoDetector(dictionary, parameters)


def open_camera():
    cap = cv2.VideoCapture(CAMERA_ID, cv2.CAP_V4L2)
    if not cap.isOpened():
        raise SystemExit("[ERROR] Camera cannot open (is camera_host.py running?).")
    cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*"MJPG"))
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, FRAME_W)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, FRAME_H)
    cap.set(cv2.CAP_PROP_FPS, CAMERA_FPS)
    cap.set(cv2.CAP_PROP_AUTOFOCUS, 0)
    time.sleep(2)
    w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    if (w, h) != (FRAME_W, FRAME_H):
        cap.release()
        raise SystemExit(f"[ERROR] Camera is {w}x{h}, not {FRAME_W}x{FRAME_H}. Do NOT calibrate.")
    return cap


def pixel_to_meter(px, py):
    return px / (WARP_W - 1) * ARENA_WIDTH_M, py / (WARP_H - 1) * ARENA_HEIGHT_M


def transform_point(H, x, y):
    p = cv2.perspectiveTransform(np.array([[[x, y]]], dtype=np.float32), H)
    return float(p[0][0][0]), float(p[0][0][1])


def draw_grid(bird):
    for i in range(0, 22):
        m = i * 0.10
        if m > ARENA_WIDTH_M:
            break
        px = int(round(m / ARENA_WIDTH_M * (WARP_W - 1)))
        py = int(round(m / ARENA_HEIGHT_M * (WARP_H - 1)))
        colour = (0, 200, 255) if i % 5 == 0 else (90, 90, 90)
        cv2.line(bird, (px, 0), (px, WARP_H - 1), colour, 1)
        cv2.line(bird, (0, py), (WARP_W - 1, py), colour, 1)
    cv2.arrowedLine(bird, (20, 20), (120, 20), (0, 0, 255), 3, tipLength=0.2)
    cv2.putText(bird, "+X", (125, 28), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
    cv2.arrowedLine(bird, (20, 20), (20, 120), (0, 255, 0), 3, tipLength=0.2)
    cv2.putText(bird, "+Y", (8, 145), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)


def capture(args):
    detector = make_detector()
    cap = open_camera()
    samples = {mid: [] for mid in REFERENCE_IDS}
    drones = {}
    seen = set()
    last_frame = None
    last_refs = {}
    frames = 0
    try:
        t_end = time.time() + args.seconds
        while time.time() < t_end:
            ok, frame = cap.read()
            if not ok:
                continue
            frames += 1
            corners, ids, _ = detector.detectMarkers(frame)
            refs = {}
            if ids is not None:
                for i, mid in enumerate(ids.flatten()):
                    mid = int(mid)
                    seen.add(mid)
                    pts = corners[i][0].astype(np.float32)
                    if mid in REFERENCE_IDS:
                        refs[mid] = pts
                    elif mid in DRONE_IDS:
                        drones.setdefault(mid, []).append(pts.mean(axis=0))
            if all(mid in refs for mid in REFERENCE_IDS):
                for mid in REFERENCE_IDS:
                    samples[mid].append(refs[mid][INNER_CORNER_INDEX[mid]])
                last_frame, last_refs = frame, refs
            elif last_frame is None:
                last_frame = frame
    finally:
        cap.release()

    good = len(samples[40])
    print(f"Frames read        : {frames}")
    print(f"IDs seen           : {sorted(seen)}")
    print(f"Frames with 40-43  : {good}")
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    stem = LOG_DIR / f"calib_candidate_{ts}"

    if good < MIN_GOOD_FRAMES:
        missing = [m for m in REFERENCE_IDS if m not in seen]
        if last_frame is not None:
            cv2.imwrite(str(stem) + "_FAILED_camera.jpg", last_frame)
            print(f"Camera snapshot    : {stem}_FAILED_camera.jpg")
        raise SystemExit(f"[FAIL] Need >= {MIN_GOOD_FRAMES} frames with all of 40-43. "
                         f"Never seen: {missing}")

    src = np.array([np.median(np.array(samples[m]), axis=0) for m in REFERENCE_IDS],
                   dtype=np.float32)
    jitter = {m: float(np.max(np.std(np.array(samples[m]), axis=0))) for m in REFERENCE_IDS}
    dst = np.array([[0, 0], [WARP_W - 1, 0], [WARP_W - 1, WARP_H - 1], [0, WARP_H - 1]],
                   dtype=np.float32)
    H = cv2.getPerspectiveTransform(src, dst)

    print()
    for m, p in zip(REFERENCE_IDS, src):
        print(f"ID{m} corner[{INNER_CORNER_INDEX[m]}] = ({p[0]:7.1f}, {p[1]:6.1f}) px"
              f"   jitter std = {jitter[m]:.2f} px")
    print("\nHomography:")
    print(H)

    # Annotated camera view
    cam = last_frame.copy()
    poly = src.astype(np.int32).reshape(-1, 1, 2)
    cv2.polylines(cam, [poly], True, (255, 0, 255), 2)
    for m, p in zip(REFERENCE_IDS, src):
        cv2.circle(cam, (int(p[0]), int(p[1])), 10, (255, 0, 255), -1)
        cv2.putText(cam, f"ID{m}", (int(p[0]) + 12, int(p[1]) - 10),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 0, 255), 2)
    cv2.imwrite(str(stem) + "_camera.jpg", cam)

    # Bird-eye with grid and drone markers
    bird = cv2.warpPerspective(last_frame, H, (WARP_W, WARP_H))
    draw_grid(bird)
    print()
    for mid, pts in sorted(drones.items()):
        c = np.median(np.array(pts), axis=0)
        bx, by = transform_point(H, c[0], c[1])
        x_m, y_m = pixel_to_meter(bx, by)
        print(f"Drone marker ID{mid}: X={x_m:.3f} m  Y={y_m:.3f} m")
        if 0 <= bx < WARP_W and 0 <= by < WARP_H:
            cv2.drawMarker(bird, (int(bx), int(by)), (0, 0, 255), cv2.MARKER_CROSS, 30, 3)
            cv2.putText(bird, f"ID{mid} X={x_m:.2f} Y={y_m:.2f}", (int(bx) + 12, int(by) - 12),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 255), 2)
    cv2.imwrite(str(stem) + "_bird.jpg", bird)
    np.save(str(stem) + ".npy", H)

    worst = max(jitter.values())
    print()
    print(f"Candidate          : {stem}.npy")
    print(f"Camera view        : {stem}_camera.jpg")
    print(f"Bird-eye view      : {stem}_bird.jpg")
    print(f"Worst corner jitter: {worst:.2f} px (limit {MAX_CORNER_STD_PX})")
    if worst > MAX_CORNER_STD_PX:
        print("[WARN] Corners unstable (camera moving / poor light). Do NOT commit; re-run.")
    print("Active homography  : UNCHANGED (use --commit after checking the images)")


def commit(path):
    cand = Path(path)
    if not cand.is_absolute():
        cand = (BASE_DIR / cand) if (BASE_DIR / cand).exists() else cand.resolve()
    H = np.load(cand)
    if H.shape != (3, 3) or not np.all(np.isfinite(H)):
        raise SystemExit("[ERROR] Candidate is not a valid 3x3 homography.")
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_dir = BASE_DIR / "homography_backups"
    backup_dir.mkdir(exist_ok=True)
    for f in (H_COMPAT_FILE, H_EMEET_FILE):
        if f.exists():
            dst = backup_dir / f"{f.stem}_before_{ts}.npy"
            shutil.copy2(f, dst)
            print(f"Backup : {dst}")
    np.save(H_EMEET_FILE, H)
    np.save(H_COMPAT_FILE, H)
    print(f"Installed {cand.name} ->")
    print(f"  {H_COMPAT_FILE}")
    print(f"  {H_EMEET_FILE}")
    print("Restart camera_host.py so it loads the new homography.")


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--seconds", type=float, default=4.0, help="capture duration")
    ap.add_argument("--commit", metavar="CANDIDATE_NPY",
                    help="install a reviewed candidate as the active homography")
    args = ap.parse_args()
    if args.commit:
        commit(args.commit)
    else:
        capture(args)


if __name__ == "__main__":
    sys.exit(main())
