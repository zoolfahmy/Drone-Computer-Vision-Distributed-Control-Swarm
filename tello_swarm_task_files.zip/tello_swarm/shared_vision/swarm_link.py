#!/usr/bin/env python3
"""
SWARM LINK  -  small UDP messages between the swarm coordinator and the
flight agents (step11_hold.py --swarm), on UDP port 9871.

Coordinator -> agents   {"type": "cmd", "cmd": "IDLE"|"GO"|"LAND_ALL", "run": id, "t": ...}
                        sent 5x per second; it doubles as the coordinator heartbeat.
Agent -> coordinator    {"type": "status", "marker": n, "state": ..., "x": ..., "y": ...,
                         "fault": "...", "host": ..., "t": ...}  5x per second.

Messages go to every IPv4 broadcast address of this Pi and to 127.0.0.1, so
one Pi can run the coordinator and an agent together.  Every socket binds the
same port with SO_REUSEADDR/SO_REUSEPORT and receives the broadcasts.
"""
import json
import socket
import subprocess
import threading
import time

SWARM_PORT = 9871
PROTOCOL = "tello-swarm/1"


def broadcast_addresses():
    out = []
    try:
        text = subprocess.run(["ip", "-4", "-o", "addr", "show"], capture_output=True,
                              text=True, timeout=2).stdout
        for line in text.splitlines():
            parts = line.split()
            if "brd" in parts:
                dev = parts[1]
                if dev == "lo" or dev.startswith("wlan"):   # never broadcast into a Tello network
                    continue
                out.append(parts[parts.index("brd") + 1])
    except Exception:
        pass
    return out or ["255.255.255.255"]


class SwarmLink:
    def __init__(self, port=SWARM_PORT):
        self.port = port
        self._lock = threading.Lock()
        self._running = False
        self.cmd = None                 # latest coordinator command dict
        self.cmd_rx = 0.0               # perf_counter when it arrived
        self.status = {}                # marker -> (status dict, rx time)
        self.targets = ["127.0.0.1"] + broadcast_addresses()

    def start(self):
        rx = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        rx.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        if hasattr(socket, "SO_REUSEPORT"):
            rx.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEPORT, 1)
        rx.bind(("", self.port))
        rx.settimeout(0.3)
        tx = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        tx.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        self._rx, self._tx = rx, tx
        self._running = True
        threading.Thread(target=self._loop, daemon=True).start()
        return self

    def stop(self):
        self._running = False
        for s in (getattr(self, "_rx", None), getattr(self, "_tx", None)):
            try:
                s.close()
            except Exception:
                pass

    def _loop(self):
        while self._running:
            try:
                data, addr = self._rx.recvfrom(65536)
            except socket.timeout:
                continue
            except OSError:
                break
            try:
                msg = json.loads(data.decode())
            except Exception:
                continue
            if msg.get("p") != PROTOCOL:
                continue
            now = time.perf_counter()
            with self._lock:
                if msg.get("type") == "cmd":
                    self.cmd, self.cmd_rx = msg, now
                elif msg.get("type") == "status" and "marker" in msg:
                    msg["addr"] = addr[0]
                    self.status[int(msg["marker"])] = (msg, now)

    def send(self, msg):
        msg = dict(msg, p=PROTOCOL, t=time.time())
        data = json.dumps(msg).encode()
        for target in self.targets:
            try:
                self._tx.sendto(data, (target, self.port))
            except OSError:
                pass

    # ---- agent side ----
    def command(self):
        """(latest command dict or None, age in s)."""
        with self._lock:
            if self.cmd is None:
                return None, float("inf")
            return dict(self.cmd), time.perf_counter() - self.cmd_rx

    def peers(self, own_marker, max_age=0.5):
        """Fresh statuses of the other agents: {marker: status}."""
        now = time.perf_counter()
        with self._lock:
            return {m: s for m, (s, t) in self.status.items()
                    if m != own_marker and now - t <= max_age}

    # ---- coordinator side ----
    def statuses(self):
        """{marker: (status, age s)}."""
        now = time.perf_counter()
        with self._lock:
            return {m: (dict(s), now - t) for m, (s, t) in self.status.items()}
