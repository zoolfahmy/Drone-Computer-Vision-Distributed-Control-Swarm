# Task 1E: object detection by colour
# Objective: find one coloured object in the live picture and report
#            its centre in pixels, its size and its shape
import json
from pathlib import Path

import cv2
import numpy as np

RANGE_FILE = Path(__file__).resolve().parent / "hsv_range.json"
FONT = cv2.FONT_HERSHEY_SIMPLEX

MIN_AREA = 800                                   # pixels; smaller regions are ignored
HSV_RANGE = [100, 130, 120, 255, 60, 255]        # blue, used if no range was saved

if RANGE_FILE.exists():                          # the range you saved in Task 1B
    HSV_RANGE = json.loads(RANGE_FILE.read_text())


def colour_mask(hsv, values):
    """White where the pixel is inside the HSV range, black elsewhere."""
    h_min, h_max, s_min, s_max, v_min, v_max = values
    if h_min <= h_max:
        return cv2.inRange(hsv, (h_min, s_min, v_min), (h_max, s_max, v_max))
    upper_part = cv2.inRange(hsv, (h_min, s_min, v_min), (179, s_max, v_max))
    lower_part = cv2.inRange(hsv, (0, s_min, v_min), (h_max, s_max, v_max))
    return cv2.bitwise_or(upper_part, lower_part)


def shape_name(contour):
    """Name a shape from the number of corners of its simplified outline."""
    perimeter = cv2.arcLength(contour, True)
    corners = len(cv2.approxPolyDP(contour, 0.03 * perimeter, True))
    if corners == 3:
        return "triangle"
    if corners == 4:
        return "rectangle"
    if corners > 6:
        return "circle"
    return f"{corners} corners"


cap = cv2.VideoCapture(0)

if not cap.isOpened():
    print("ERROR: Camera /dev/video0 cannot be opened")
    exit()

cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)

print("Task 1E - Object detection by colour")
print("HSV range:", HSV_RANGE)
print("P = Print position   S = Save image   Q = Quit")

kernel = np.ones((5, 5), np.uint8)
detected = False
u = v = 0
area = 0.0
shape = ""

while True:

    ret, frame = cap.read()

    if not ret:
        print("ERROR: Cannot read camera frame")
        break

    # ---------- process ----------
    # 1. colour mask   2. clean   3. contours   4. keep the largest one
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    mask = colour_mask(hsv, HSV_RANGE)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)

    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    detected = False
    if contours:
        largest = max(contours, key=cv2.contourArea)
        area = cv2.contourArea(largest)

        if area >= MIN_AREA:
            detected = True

            # The centre of the object, from the moments of its contour
            m = cv2.moments(largest)
            u = int(m["m10"] / m["m00"])
            v = int(m["m01"] / m["m00"])

            x, y, w, h = cv2.boundingRect(largest)
            shape = shape_name(largest)

    # The position error seen by a controller: object centre - image centre
    centre_u = frame.shape[1] // 2
    centre_v = frame.shape[0] // 2

    # ---------- display ----------
    cv2.drawMarker(frame, (centre_u, centre_v), (255, 255, 255), cv2.MARKER_CROSS, 30, 2)

    if detected:
        cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 3)
        cv2.circle(frame, (u, v), 8, (0, 0, 255), -1)
        cv2.line(frame, (centre_u, centre_v), (u, v), (0, 255, 255), 2)
        cv2.putText(frame, f"{shape}  u:{u} v:{v}", (x, max(25, y - 12)),
                    FONT, 0.8, (0, 255, 0), 2)
        cv2.putText(frame, f"OBJECT FOUND   area {area:.0f} px   "
                           f"error du:{u - centre_u:+d} dv:{v - centre_v:+d}",
                    (20, 35), FONT, 0.8, (0, 255, 0), 2)
    else:
        cv2.putText(frame, "NO OBJECT", (20, 35), FONT, 0.9, (0, 0, 255), 2)

    size = (640, 360)
    view = np.hstack([cv2.resize(frame, size),
                      cv2.cvtColor(cv2.resize(mask, size), cv2.COLOR_GRAY2BGR)])
    cv2.imshow("Task 1E - Object detection", view)

    key = cv2.waitKey(1) & 0xFF

    if key == ord('q'):
        break

    elif key == ord('p'):
        if detected:
            print(f"Object: {shape}  centre u = {u}  v = {v}  area = {area:.0f} px  "
                  f"error du = {u - centre_u:+d}  dv = {v - centre_v:+d}")
        else:
            print("No object")

    elif key == ord('s'):
        cv2.imwrite("task1e_object.jpg", view)
        print("Saved: task1e_object.jpg")

cap.release()
cv2.destroyAllWindows()

print("Camera closed")
