import cv2

print("OpenCV Version:", cv2.__version__)
print("Opening USB Camera...")

cap = cv2.VideoCapture(0)

if not cap.isOpened():
    print("ERROR: Camera /dev/video0 cannot be opened")
    exit()

# Set resolution
cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)

width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
fps = cap.get(cv2.CAP_PROP_FPS)

print("Camera detected successfully")
print("Resolution:", width, "x", height)
print("FPS:", fps)
print("Press Q to exit")
print("Press S to save image")

image_count = 0

while True:

    ret, frame = cap.read()

    if not ret:
        print("ERROR: Cannot read camera frame")
        break

    # Information on screen
    cv2.putText(
        frame,
        f"USB Camera | {width}x{height}",
        (20, 35),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.8,
        (0, 255, 0),
        2
    )

    cv2.imshow("Practical 01 - Drone Vision Camera", frame)

    key = cv2.waitKey(1) & 0xFF

    # Q = Quit
    if key == ord('q'):
        break

    # S = Save image
    elif key == ord('s'):
        image_count += 1

        filename = f"capture_{image_count}.jpg"

        cv2.imwrite(filename, frame)

        print("Saved:", filename)

cap.release()
cv2.destroyAllWindows()

print("Camera closed")
