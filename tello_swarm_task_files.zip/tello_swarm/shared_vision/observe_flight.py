#!/usr/bin/env python3
"""
OBSERVE FLIGHT  -  the camera watches the drone hover (Practical Work 2, Task 3)
===============================================================================

Shared-camera version of practical03/tello_flight_vision_raw_v2.py (P03-C).
Run it on the Raspberry Pi of the drone; camera_host.py runs on the camera Pi.

    python3 shared_vision/observe_flight.py --marker 1
    python3 shared_vision/observe_flight.py --sim --marker 1     (no drone)

What it does: take off, hover for 10 seconds, land.  During the hover the
position of the drone's marker is logged from the shared camera.

    Monitoring only:  NO XY control,  NO altitude control,
                      NO height compensation of the position.

Keys (click the window, or type in the terminal the script was started from):

    A            arm / disarm
    T            take off and start the 10 second observation (only while ARMED)
    L or SPACE   land now
    E            EMERGENCY: stop the motors at once (the drone drops)
    Q            quit (lands first if flying); Ctrl+C does the same

The window, the keys, the arming checks and the landing code are those of
fly_step10.py.  The only RC command this script sends is the neutral stick
(0, 0, 0, 0).  The drone lands by itself if it drifts into the 20 cm margin
at the arena border.

The CSV log (shared_vision/logs/observe_flight_id<N>_<time>.csv) has the same
columns as the P03-C log, so analyse_drift.py reads it in the same way.
"""

import time
from datetime import datetime

import fly_step10 as fs

HOVER_TIME = 10.0            # seconds, as in P03-C
LOG_INTERVAL_S = 0.10        # a row at least this often, even with no new frame
KEEPALIVE_S = 1.0            # neutral stick, so the drone knows the Pi is there

PROGRAM_START = time.perf_counter()


class ObserveFlight(fs.Flight):

    def fly(self):
        tello = self.tello
        self.set_state("TAKEOFF")           # from now on L and E are flight stops
        self.armed = False                  # the arming is used up by this flight
        self.flight_log = []
        self.end_reason = ""
        self.trail.clear()
        self.telemetry = {}
        self.hover_time = 0.0
        fs.LOG_DIR.mkdir(parents=True, exist_ok=True)
        self.csv_file = fs.LOG_DIR / (
            f"observe_flight_id{self.marker}_"
            f"{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv")

        try:
            battery = int(tello.get_battery())
            self.battery = battery
            print(f"Battery = {battery}%", flush=True)
            if battery < fs.MIN_BATTERY:
                raise fs.FlightStop("Battery too low.")

            state = self.vision_state()
            if not fs.vision_is_fresh(state):
                raise fs.FlightStop(
                    f"Fresh ID{self.marker} observation required before takeoff.")
            print(f"ID{self.marker} position before take-off: "
                  f"X = {state['x']:.4f} m  Y = {state['y']:.4f} m", flush=True)

            self.check_stop()               # L or E pressed since T
            self.say("Taking off...")
            self.flush_replies()
            self.airborne = True            # from here on, every exit path lands
            tello.takeoff()
            tello.send_rc_control(0, 0, 0, 0)
            self.check_stop()

            self.set_state("OBSERVE")
            self.say(f"Observing for {HOVER_TIME:.0f} s. No XY control. "
                     "L or SPACE lands.")
            self.observe()

        except fs.FlightStop as stop:
            self.end_reason = str(stop)
            self.say(f"[STOP] {stop}")
        except Exception as exc:
            self.end_reason = str(exc)
            self.say(f"[ERROR] {exc}")
        finally:
            self.land_sequence()

    def observe(self):
        tello = self.tello
        start = time.perf_counter()
        last_sequence = -1
        last_row = 0.0
        last_keepalive = start
        last_print = -999.0
        height_cm = 0
        tof_cm = 0

        while True:
            now = time.perf_counter()
            self.hover_time = now - start
            if self.hover_time >= HOVER_TIME:
                break
            if self.land_event.is_set() or self.emergency_event.is_set():
                self.end_reason = "stopped from the keyboard"
                break

            if now - last_keepalive >= KEEPALIVE_S:
                last_keepalive = now
                tello.send_rc_control(0, 0, 0, 0)

            drone = self.read_drone_state() or {}
            try:
                height_cm = int(drone.get("h", height_cm))
                tof_cm = int(drone.get("tof", tof_cm))
            except (TypeError, ValueError):
                pass

            state = self.vision_state()
            new_frame = state["frame_sequence"] != last_sequence
            if not new_frame and now - last_row < LOG_INTERVAL_S:
                time.sleep(0.005)
                continue
            last_sequence = state["frame_sequence"]
            last_row = now

            # A row written without a new frame carries no new measurement.
            detected = new_frame and fs.vision_is_fresh(state)
            x = state["x"] if detected else None
            y = state["y"] if detected else None

            self.flight_log.append({
                "program_time_s": f"{now - PROGRAM_START:.4f}",
                "flight_time_s": f"{self.hover_time:.4f}",
                "detected": 1 if detected else 0,
                "raw_x_m": f"{x:.6f}" if detected else "",
                "raw_y_m": f"{y:.6f}" if detected else "",
                "height_cm": height_cm,
                "tof_cm": tof_cm,
                "battery_pct": self.battery if self.battery is not None else "",
            })

            if detected:
                self.trail.append((x, y))
                if not fs.arena_safe(x, y):
                    self.end_reason = "arena boundary margin exceeded"
                    self.say("[SAFETY] Arena boundary margin exceeded. Landing.")
                    break

            if now - last_print >= 1.0:
                last_print = now
                where = (f"X={x:.3f} Y={y:.3f}" if detected
                         else f"ID{self.marker} NOT SEEN")
                print(f"t={self.hover_time:4.1f}s | {where} | H={height_cm}cm "
                      f"ToF={tof_cm}cm | Bat={self.battery}%", flush=True)

        if self.hover_time >= HOVER_TIME:
            self.say("Observation complete. Landing.")

    # ---------------- what the shared window and messages show ----------------

    def status_lines(self):
        if self.state == "OBSERVE":
            return [("MODE", "observe, no XY control", fs.YELLOW),
                    ("TIME", f"{getattr(self, 'hover_time', 0.0):.1f} / "
                             f"{HOVER_TIME:.0f} s", fs.WHITE)]
        return []

    def result_text(self):
        rows = [r for r in self.flight_log if r["detected"] == 1]
        if not self.flight_log:
            return "No observation was made" + (
                f" ({self.end_reason})" if self.end_reason else "")
        text = f"{len(self.flight_log)} samples"
        if rows:
            xs = [float(r["raw_x_m"]) for r in rows]
            ys = [float(r["raw_y_m"]) for r in rows]
            text += (f", X range {(max(xs) - min(xs)) * 100:.1f} cm, "
                     f"Y range {(max(ys) - min(ys)) * 100:.1f} cm")
        if self.end_reason:
            text += f" ({self.end_reason})"
        return text

    def print_summary(self):
        log = self.flight_log
        rows = [r for r in log if r["detected"] == 1]
        print()
        print("=" * 72)
        print(f" OBSERVATION RESULT  -  marker ID{self.marker}")
        print("=" * 72)
        print(f"Samples           : {len(log)}  (marker seen in {len(rows)})")
        print(f"Flight time       : {float(log[-1]['flight_time_s']):.1f} s")
        if rows:
            xs = [float(r["raw_x_m"]) for r in rows]
            ys = [float(r["raw_y_m"]) for r in rows]
            print(f"X, Y at the start : {xs[0]:.3f}, {ys[0]:.3f} m")
            print(f"X, Y at the end   : {xs[-1]:.3f}, {ys[-1]:.3f} m")
            print(f"X range           : {(max(xs) - min(xs)) * 100:.1f} cm")
            print(f"Y range           : {(max(ys) - min(ys)) * 100:.1f} cm")
        print("CSV:")
        print(self.csv_file, flush=True)


if __name__ == "__main__":
    fs.main(flight_class=ObserveFlight,
            title="OBSERVE FLIGHT (P03-C, shared camera)",
            description="Take off, hover 10 s and log the marker position from "
                        "the shared camera. No XY control.")
