# Task 1A: colour spaces - BGR and HSV
# Objective: split a camera frame into its B, G, R channels and its
#            H, S, V channels, and read both values of one pixel
import cv2
import numpy as np

cap = cv2.VideoCapture(0)

if not cap.isOpened():
    print("ERROR: Camera /dev/video0 cannot be opened")
    exit()

cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)

print("Task 1A - BGR and HSV")
print("P = Print centre pixel   S = Save image   Q = Quit")

FONT = cv2.FONT_HERSHEY_SIMPLEX


def tile(image, label):
    """A small labelled copy of an image, for the overview window."""
    small = cv2.resize(image, (320, 180))
    if small.ndim == 2:                       # one channel -> show it as grey
        small = cv2.cvtColor(small, cv2.COLOR_GRAY2BGR)
    cv2.putText(small, label, (8, 24), FONT, 0.6, (0, 255, 255), 2)
    return small


while True:

    ret, frame = cap.read()

    if not ret:
        print("ERROR: Cannot read camera frame")
        break

    # ---------- process ----------
    # OpenCV stores colour in the order Blue, Green, Red
    b, g, r = cv2.split(frame)

    # HSV: Hue (which colour, 0-179), Saturation (how pure, 0-255),
    #      Value (how bright, 0-255)
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    h, s, v = cv2.split(hsv)

    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    # The pixel at the centre of the picture, in both colour spaces
    cy = frame.shape[0] // 2
    cx = frame.shape[1] // 2
    pixel_bgr = [int(value) for value in frame[cy, cx]]
    pixel_hsv = [int(value) for value in hsv[cy, cx]]

    # ---------- display ----------
    view = frame.copy()
    cv2.drawMarker(view, (cx, cy), (0, 255, 255), cv2.MARKER_CROSS, 60, 3)

    hue_bright = cv2.convertScaleAbs(h, alpha=255 / 179)   # only to make hue visible

    top = np.hstack([tile(view, "Original (BGR)"), tile(b, "Blue"),
                     tile(g, "Green"), tile(r, "Red")])
    bottom = np.hstack([tile(gray, "Grayscale"), tile(hue_bright, "Hue"),
                        tile(s, "Saturation"), tile(v, "Value")])
    info = np.zeros((44, top.shape[1], 3), np.uint8)
    cv2.putText(info, f"Centre pixel   BGR = {pixel_bgr}   HSV = {pixel_hsv}",
                (10, 30), FONT, 0.7, (0, 255, 0), 2)

    cv2.imshow("Task 1A - BGR and HSV", np.vstack([top, bottom, info]))

    key = cv2.waitKey(1) & 0xFF

    if key == ord('q'):
        break

    elif key == ord('p'):
        print("Centre pixel  BGR =", pixel_bgr, " HSV =", pixel_hsv)

    elif key == ord('s'):
        cv2.imwrite("task1a_bgr_hsv.jpg", np.vstack([top, bottom, info]))
        print("Saved: task1a_bgr_hsv.jpg")

cap.release()
cv2.destroyAllWindows()

print("Camera closed")
