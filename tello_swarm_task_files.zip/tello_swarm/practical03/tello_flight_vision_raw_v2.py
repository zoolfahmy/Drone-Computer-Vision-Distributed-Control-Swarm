import cv2
import numpy as np
import csv
import time
from datetime import datetime
from pathlib import Path
from djitellopy import Tello


# ============================================================
# P03-C2A V2
# TELLO RAW FLIGHT VISION TRACKING
#
# Raspberry Pi 5
# EMEET C980 Pro
# DJI Tello EDU
# ArUco ID1 = 7 cm
#
# IMPORTANT:
#   - Vision monitoring only
#   - NO PID
#   - NO XY autonomous movement
#   - NO altitude compensation
#
# KEYS:
#   T = Takeoff / Start flight
#   L = Land immediately
#   Q = Quit
#
# ============================================================


# ============================================================
# PATHS
# ============================================================

BASE_DIR = Path(__file__).resolve().parent

H_FILE = (
    BASE_DIR.parent
    / "practical02"
    / "arena_homography.npy"
)

LOG_DIR = BASE_DIR / "logs"
LOG_DIR.mkdir(parents=True, exist_ok=True)

timestamp = datetime.now().strftime(
    "%Y%m%d_%H%M%S"
)

CSV_FILE = (
    LOG_DIR
    / f"tello_flight_raw_v2_{timestamp}.csv"
)


# ============================================================
# CAMERA
# ============================================================

CAMERA_ID = 0

FRAME_W = 1280
FRAME_H = 720

CAMERA_FPS = 30

# 2x image scaling only for ArUco detection.
# Coordinates will be converted back to original resolution.

DETECT_SCALE = 2.0


# ============================================================
# ARENA
# ============================================================

ARENA_W = 2.1336
ARENA_H = 2.1336

WARP_W = 800
WARP_H = 800

CENTER_X = ARENA_W / 2.0
CENTER_Y = ARENA_H / 2.0


# ============================================================
# TELLO
# ============================================================

TELLO_MARKER_ID = 1

MIN_BATTERY = 40

HOVER_TIME = 10.0

TELEMETRY_INTERVAL = 1.0


# ============================================================
# LOAD HOMOGRAPHY
# ============================================================

if not H_FILE.exists():

    print()
    print("[ERROR] Homography file not found:")
    print(H_FILE)
    print()

    raise SystemExit


H = np.load(H_FILE)


print()
print("=" * 72)
print(" P03-C2A V2 - TELLO RAW FLIGHT VISION TRACKING")
print("=" * 72)
print()
print("Camera       : EMEET C980 Pro")
print("Resolution   : 1280x720 MJPG")
print("Tello marker : ArUco ID1 - 7 cm")
print(f"Detection    : {DETECT_SCALE:.1f}x scaling")
print(f"Arena        : {ARENA_W:.4f} x {ARENA_H:.4f} m")
print()
print("Homography:")
print(H_FILE)
print()
print("CSV:")
print(CSV_FILE)
print()


# ============================================================
# ARUCO DICTIONARY
# ============================================================

dictionary = cv2.aruco.getPredefinedDictionary(
    cv2.aruco.DICT_4X4_50
)


# ============================================================
# ARUCO PARAMETERS
# Optimized for smaller 7 cm marker
# ============================================================

parameters = cv2.aruco.DetectorParameters()

parameters.cornerRefinementMethod = (
    cv2.aruco.CORNER_REFINE_SUBPIX
)

parameters.adaptiveThreshWinSizeMin = 3
parameters.adaptiveThreshWinSizeMax = 53
parameters.adaptiveThreshWinSizeStep = 2

parameters.minMarkerPerimeterRate = 0.005
parameters.maxMarkerPerimeterRate = 4.0

parameters.polygonalApproxAccuracyRate = 0.05

parameters.minCornerDistanceRate = 0.01
parameters.minMarkerDistanceRate = 0.01

parameters.minDistanceToBorder = 2

parameters.cornerRefinementWinSize = 5
parameters.cornerRefinementMaxIterations = 50
parameters.cornerRefinementMinAccuracy = 0.01


detector = cv2.aruco.ArucoDetector(
    dictionary,
    parameters
)


# ============================================================
# FUNCTIONS
# ============================================================

def marker_center(points):

    cx = float(
        np.mean(points[:, 0])
    )

    cy = float(
        np.mean(points[:, 1])
    )

    return cx, cy


def transform_point(x, y):

    point = np.array(
        [[[x, y]]],
        dtype=np.float32
    )

    transformed = cv2.perspectiveTransform(
        point,
        H
    )

    bx = float(
        transformed[0][0][0]
    )

    by = float(
        transformed[0][0][1]
    )

    return bx, by


def pixel_to_meter(px, py):

    x_m = (
        px
        / (WARP_W - 1)
        * ARENA_W
    )

    y_m = (
        py
        / (WARP_H - 1)
        * ARENA_H
    )

    return x_m, y_m


def meter_to_pixel(x_m, y_m):

    px = int(
        x_m
        / ARENA_W
        * (WARP_W - 1)
    )

    py = int(
        y_m
        / ARENA_H
        * (WARP_H - 1)
    )

    return px, py


def draw_grid(frame):

    # --------------------------------------------
    # 0.25 m grid
    # --------------------------------------------

    step = 0.25

    x = 0.0

    while x <= ARENA_W:

        px, _ = meter_to_pixel(
            x,
            0
        )

        cv2.line(
            frame,
            (px, 0),
            (px, WARP_H - 1),
            (100, 100, 100),
            1
        )

        x += step


    y = 0.0

    while y <= ARENA_H:

        _, py = meter_to_pixel(
            0,
            y
        )

        cv2.line(
            frame,
            (0, py),
            (WARP_W - 1, py),
            (100, 100, 100),
            1
        )

        y += step


    # --------------------------------------------
    # Arena center
    # --------------------------------------------

    cx, cy = meter_to_pixel(
        CENTER_X,
        CENTER_Y
    )

    cv2.drawMarker(
        frame,
        (cx, cy),
        (255, 0, 0),
        cv2.MARKER_CROSS,
        35,
        3
    )

    cv2.putText(
        frame,
        (
            f"CENTER "
            f"({CENTER_X:.3f},"
            f"{CENTER_Y:.3f})"
        ),
        (cx + 15, cy - 15),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.55,
        (255, 0, 0),
        2
    )


def detect_tello_marker(frame):

    """
    Detect ArUco ID1 using enlarged detection image.

    Returns:
        detected
        original_points
        center_x
        center_y
    """

    # --------------------------------------------
    # Scale image 2x
    # --------------------------------------------

    detect_frame = cv2.resize(
        frame,
        None,
        fx=DETECT_SCALE,
        fy=DETECT_SCALE,
        interpolation=cv2.INTER_LINEAR
    )


    # --------------------------------------------
    # Grayscale
    # --------------------------------------------

    gray = cv2.cvtColor(
        detect_frame,
        cv2.COLOR_BGR2GRAY
    )


    # --------------------------------------------
    # Detect markers
    # --------------------------------------------

    corners, ids, rejected = (
        detector.detectMarkers(gray)
    )


    if ids is None:

        return (
            False,
            None,
            None,
            None
        )


    ids_flat = ids.flatten()


    for i, marker_id in enumerate(
        ids_flat
    ):

        if int(marker_id) != TELLO_MARKER_ID:
            continue


        # Coordinates currently correspond
        # to the enlarged image.

        points_scaled = (
            corners[i][0]
            .astype(np.float32)
        )


        # Convert coordinates back to
        # original 1280x720 frame.

        points_original = (
            points_scaled
            / DETECT_SCALE
        )


        cx, cy = marker_center(
            points_original
        )


        return (
            True,
            points_original,
            cx,
            cy
        )


    return (
        False,
        None,
        None,
        None
    )


# ============================================================
# CAMERA
# ============================================================

print("Opening EMEET C980 Pro...")


cap = cv2.VideoCapture(
    CAMERA_ID,
    cv2.CAP_V4L2
)


if not cap.isOpened():

    print()
    print("[ERROR] Cannot open camera.")
    print()

    raise SystemExit


# MJPG mode

fourcc = cv2.VideoWriter_fourcc(
    *"MJPG"
)

cap.set(
    cv2.CAP_PROP_FOURCC,
    fourcc
)

cap.set(
    cv2.CAP_PROP_FRAME_WIDTH,
    FRAME_W
)

cap.set(
    cv2.CAP_PROP_FRAME_HEIGHT,
    FRAME_H
)

cap.set(
    cv2.CAP_PROP_FPS,
    CAMERA_FPS
)


# Keep same focus condition used
# during EMEET homography calibration.

cap.set(
    cv2.CAP_PROP_AUTOFOCUS,
    0
)


time.sleep(2)


actual_w = int(
    cap.get(cv2.CAP_PROP_FRAME_WIDTH)
)

actual_h = int(
    cap.get(cv2.CAP_PROP_FRAME_HEIGHT)
)

actual_fps = cap.get(
    cv2.CAP_PROP_FPS
)


print()
print(
    f"Camera resolution : "
    f"{actual_w}x{actual_h}"
)

print(
    f"Camera FPS report : "
    f"{actual_fps:.1f}"
)

print()


# ============================================================
# TELLO CONNECTION
# ============================================================

print("Connecting to Tello...")


tello = Tello()

airborne = False
test_started = False
test_finished = False

csv_handle = None


try:

    # --------------------------------------------------------
    # Connect
    # --------------------------------------------------------

    tello.connect()


    battery = tello.get_battery()


    print()
    print(
        f"Tello battery: "
        f"{battery}%"
    )


    if battery < MIN_BATTERY:

        print()
        print(
            "[STOP] Battery too low."
        )

        print(
            f"Minimum required: "
            f"{MIN_BATTERY}%"
        )

        raise SystemExit


    print("[OK] Tello connected.")


    # ========================================================
    # CSV
    # ========================================================

    csv_handle = open(
        CSV_FILE,
        "w",
        newline=""
    )


    writer = csv.writer(
        csv_handle
    )


    writer.writerow([
        "program_time_s",
        "flight_time_s",
        "detected",
        "raw_x_m",
        "raw_y_m",
        "height_cm",
        "tof_cm",
        "battery_pct"
    ])


    csv_handle.flush()


    # ========================================================
    # VARIABLES
    # ========================================================

    program_start = time.time()

    flight_start = None

    last_telemetry_time = 0.0


    height_cm = 0
    tof_cm = 0
    battery_pct = battery


    print()
    print("=" * 72)
    print(" PRE-FLIGHT MODE")
    print("=" * 72)

    print()
    print(
        "Place Tello near arena centre."
    )

    print(
        "Make sure ArUco ID1 is visible."
    )

    print()
    print(
        "DO NOT PRESS T until "
        "ID1 DETECTED is shown."
    )

    print()
    print("T = TAKEOFF")
    print("L = LAND")
    print("Q = QUIT")
    print()


    # ========================================================
    # MAIN LOOP
    # ========================================================

    while True:

        ret, frame = cap.read()


        if not ret:

            continue


        display = frame.copy()


        # ====================================================
        # DETECT 7 CM ID1
        # ====================================================

        (
            detected,
            marker_points,
            marker_cx,
            marker_cy

        ) = detect_tello_marker(frame)


        raw_x = None
        raw_y = None


        if detected:

            # --------------------------------------------
            # Homography
            # --------------------------------------------

            bird_x, bird_y = transform_point(
                marker_cx,
                marker_cy
            )


            # --------------------------------------------
            # Convert to meters
            # --------------------------------------------

            raw_x, raw_y = pixel_to_meter(
                bird_x,
                bird_y
            )


            # --------------------------------------------
            # Draw marker boundary
            # --------------------------------------------

            cv2.polylines(
                display,
                [
                    marker_points.astype(
                        np.int32
                    )
                ],
                True,
                (0, 255, 0),
                3
            )


            # --------------------------------------------
            # Draw center
            # --------------------------------------------

            cv2.drawMarker(
                display,
                (
                    int(marker_cx),
                    int(marker_cy)
                ),
                (0, 0, 255),
                cv2.MARKER_CROSS,
                25,
                3
            )


            cv2.putText(
                display,
                "TELLO ID1 - 7cm",
                (
                    int(marker_cx) + 15,
                    int(marker_cy) - 15
                ),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.60,
                (0, 255, 0),
                2
            )


        # ====================================================
        # FLIGHT TIME
        # ====================================================

        flight_time = 0.0


        if (
            test_started
            and
            flight_start is not None
        ):

            flight_time = (
                time.time()
                -
                flight_start
            )


        # ====================================================
        # TELEMETRY
        # ====================================================

        if (
            airborne
            and
            (
                time.time()
                -
                last_telemetry_time
                >= TELEMETRY_INTERVAL
            )
        ):

            try:

                height_cm = tello.get_height()

            except Exception:

                pass


            try:

                tof_cm = (
                    tello.get_distance_tof()
                )

            except Exception:

                pass


            try:

                battery_pct = (
                    tello.get_battery()
                )

            except Exception:

                pass


            last_telemetry_time = (
                time.time()
            )


        # ====================================================
        # CSV LOGGING
        # ====================================================

        if airborne:

            writer.writerow([

                f"{time.time() - program_start:.4f}",

                f"{flight_time:.4f}",

                1 if detected else 0,

                (
                    f"{raw_x:.6f}"
                    if detected
                    else ""
                ),

                (
                    f"{raw_y:.6f}"
                    if detected
                    else ""
                ),

                height_cm,

                tof_cm,

                battery_pct
            ])


            csv_handle.flush()


        # ====================================================
        # ORIGINAL CAMERA DISPLAY
        # ====================================================

        cv2.putText(
            display,
            "P03-C2A V2 RAW FLIGHT TRACKING",
            (10, 35),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.75,
            (0, 255, 255),
            2
        )


        # --------------------------------------------
        # Detection status
        # --------------------------------------------

        if detected:

            cv2.putText(
                display,
                "ID1 7cm DETECTED",
                (10, 70),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.70,
                (0, 255, 0),
                2
            )


            cv2.putText(
                display,
                (
                    f"RAW X={raw_x:.3f}m "
                    f"Y={raw_y:.3f}m"
                ),
                (10, 105),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.65,
                (0, 255, 255),
                2
            )

        else:

            cv2.putText(
                display,
                "ID1 7cm NOT DETECTED",
                (10, 70),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.70,
                (0, 0, 255),
                2
            )


        # --------------------------------------------
        # Flight status
        # --------------------------------------------

        if not test_started:

            if detected:

                cv2.putText(
                    display,
                    "READY - PRESS T TO START",
                    (10, 145),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.70,
                    (0, 255, 0),
                    2
                )

            else:

                cv2.putText(
                    display,
                    "TAKEOFF BLOCKED",
                    (10, 145),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.70,
                    (0, 0, 255),
                    2
                )


        elif airborne:

            cv2.putText(
                display,
                (
                    f"FLIGHT "
                    f"{flight_time:.1f}/"
                    f"{HOVER_TIME:.0f}s"
                ),
                (10, 145),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.65,
                (255, 255, 0),
                2
            )


            cv2.putText(
                display,
                (
                    f"H={height_cm}cm "
                    f"ToF={tof_cm}cm "
                    f"Bat={battery_pct}%"
                ),
                (10, 180),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.60,
                (255, 255, 255),
                2
            )


        elif test_finished:

            cv2.putText(
                display,
                "TEST COMPLETE - TELLO LANDED",
                (10, 145),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.65,
                (0, 255, 0),
                2
            )


        # --------------------------------------------
        # Bottom instructions
        # --------------------------------------------

        cv2.putText(
            display,
            "T=TAKEOFF   L=LAND   Q=QUIT",
            (10, FRAME_H - 25),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.60,
            (255, 255, 255),
            2
        )


        # ====================================================
        # BIRD-EYE VIEW
        # ====================================================

        bird = cv2.warpPerspective(
            frame,
            H,
            (
                WARP_W,
                WARP_H
            )
        )


        draw_grid(
            bird
        )


        if detected:

            raw_px, raw_py = (
                meter_to_pixel(
                    raw_x,
                    raw_y
                )
            )


            if (
                0 <= raw_px < WARP_W
                and
                0 <= raw_py < WARP_H
            ):

                cv2.drawMarker(
                    bird,
                    (
                        raw_px,
                        raw_py
                    ),
                    (0, 0, 255),
                    cv2.MARKER_CROSS,
                    30,
                    3
                )


                cv2.putText(
                    bird,
                    "TELLO ID1",
                    (
                        raw_px + 15,
                        raw_py - 15
                    ),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.55,
                    (0, 255, 0),
                    2
                )


                cv2.putText(
                    bird,
                    (
                        f"RAW "
                        f"X={raw_x:.3f} "
                        f"Y={raw_y:.3f}"
                    ),
                    (
                        raw_px + 15,
                        raw_py + 15
                    ),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.50,
                    (0, 255, 255),
                    2
                )


        cv2.putText(
            bird,
            (
                "RAW HOMOGRAPHY - "
                "NO ALTITUDE COMPENSATION"
            ),
            (10, 30),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.60,
            (0, 255, 255),
            2
        )


        # ====================================================
        # WINDOWS
        # ====================================================

        cv2.imshow(
            "P03-C2A V2 - EMEET C980 Pro",
            display
        )


        cv2.imshow(
            "P03-C2A V2 - Raw Bird Eye",
            bird
        )


        # ====================================================
        # AUTO LAND
        # ====================================================

        if (
            airborne
            and
            test_started
            and
            flight_time >= HOVER_TIME
        ):

            print()
            print("=" * 72)
            print(" HOVER TEST COMPLETE")
            print("=" * 72)

            print()
            print("[AUTO] Landing...")


            tello.land()


            airborne = False
            test_finished = True


            print("[OK] Tello landed.")
            print()
            print("Press Q to close program.")
            print()


        # ====================================================
        # KEYBOARD
        # ====================================================

        key = cv2.waitKey(1) & 0xFF


        # ----------------------------------------------------
        # T = TAKEOFF
        # ----------------------------------------------------

        if key == ord("t"):

            if test_started:

                print()
                print(
                    "[INFO] Flight test "
                    "already started."
                )

                continue


            # Safety:
            # no marker = no takeoff

            if not detected:

                print()
                print("=" * 72)
                print(" TAKEOFF BLOCKED")
                print("=" * 72)

                print()
                print(
                    "ArUco ID1 7cm "
                    "is not detected."
                )

                print(
                    "Tello will NOT take off."
                )

                print()

                continue


            print()
            print("=" * 72)
            print(" PRE-FLIGHT CHECK PASSED")
            print("=" * 72)

            print()

            print(
                f"ID1 RAW position:"
            )

            print(
                f"X = {raw_x:.4f} m"
            )

            print(
                f"Y = {raw_y:.4f} m"
            )

            print()

            print(
                f"Battery = "
                f"{battery_pct}%"
            )

            print()
            print("TAKEOFF...")


            tello.takeoff()


            airborne = True
            test_started = True

            flight_start = time.time()

            last_telemetry_time = 0.0


            print("[OK] Tello airborne.")

            print(
                f"Monitoring for "
                f"{HOVER_TIME:.0f} seconds."
            )

            print()


        # ----------------------------------------------------
        # L = LAND
        # ----------------------------------------------------

        elif key == ord("l"):

            if airborne:

                print()
                print(
                    "[MANUAL] LAND command..."
                )


                tello.land()


                airborne = False
                test_finished = True


                print(
                    "[OK] Tello landed."
                )

                print()


        # ----------------------------------------------------
        # Q = QUIT
        # ----------------------------------------------------

        elif key == ord("q"):

            if airborne:

                print()
                print(
                    "[SAFETY] Landing "
                    "before exit..."
                )


                tello.land()


                airborne = False


            break


# ============================================================
# CTRL+C
# ============================================================

except KeyboardInterrupt:

    print()
    print(
        "[CTRL+C] Program interrupted."
    )


    if airborne:

        try:

            print(
                "[SAFETY] Landing..."
            )

            tello.land()

        except Exception:

            pass


# ============================================================
# ERROR
# ============================================================

except Exception as e:

    print()
    print("=" * 72)
    print(" ERROR")
    print("=" * 72)

    print()
    print(e)
    print()


    if airborne:

        try:

            print(
                "[SAFETY] Attempting landing..."
            )

            tello.land()

        except Exception:

            pass


# ============================================================
# CLEANUP
# ============================================================

finally:

    if csv_handle is not None:

        try:

            csv_handle.close()

        except Exception:

            pass


    cap.release()

    cv2.destroyAllWindows()


    try:

        tello.end()

    except Exception:

        pass


    print()
    print("=" * 72)
    print(" P03-C2A V2 FINISHED")
    print("=" * 72)

    print()
    print("CSV log:")
    print(CSV_FILE)
    print()
