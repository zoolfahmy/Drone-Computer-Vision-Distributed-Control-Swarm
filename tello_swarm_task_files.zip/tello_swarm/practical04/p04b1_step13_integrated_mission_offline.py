#!/usr/bin/env python3
"""Step 13 integrated mission state-machine, OFFLINE ONLY.
No Tello/DJI imports; validates sequencing and safety-state logic.
"""
from enum import Enum, auto
import math

class State(Enum):
    PREFLIGHT=auto(); LOCALIZE=auto(); CAPTURE_ORIGIN=auto()
    NAVIGATE=auto(); BRAKE=auto(); SETTLE=auto()
    NEXT_WP=auto(); MISSION_COMPLETE=auto(); LAND=auto(); DONE=auto()

WAYPOINTS=[("WP1",0.10,0.00),("WP2",0.10,0.10)]
TOL=0.05
SETTLE_REQUIRED=3

class Mission:
    def __init__(self):
        self.state=State.PREFLIGHT
        self.wp=0
        self.settle=0
        self.origin=(0.0,0.0)

    def target(self):
        return None if self.wp>=len(WAYPOINTS) else WAYPOINTS[self.wp]

    def update(self,x,y,vision_ok=True,preflight_ok=True):
        event=""
        if self.state==State.PREFLIGHT:
            self.state=State.LOCALIZE if preflight_ok else State.LAND
        elif self.state==State.LOCALIZE:
            self.state=State.CAPTURE_ORIGIN if vision_ok else State.LAND
        elif self.state==State.CAPTURE_ORIGIN:
            self.origin=(x,y); self.state=State.NAVIGATE
        elif self.state in (State.NAVIGATE,State.BRAKE,State.SETTLE):
            if not vision_ok:
                self.state=State.LAND; event="VISION_FAIL"
            else:
                name,tx,ty=self.target()
                d=math.hypot(tx-x,ty-y)
                if d<=TOL:
                    self.state=State.SETTLE; self.settle+=1
                    if self.settle>=SETTLE_REQUIRED:
                        event=f"{name}_ACCEPTED"; self.state=State.NEXT_WP
                elif d<=0.09:
                    self.state=State.BRAKE; self.settle=0
                else:
                    self.state=State.NAVIGATE; self.settle=0
        elif self.state==State.NEXT_WP:
            self.wp+=1; self.settle=0
            self.state=State.MISSION_COMPLETE if self.wp>=len(WAYPOINTS) else State.NAVIGATE
        elif self.state==State.MISSION_COMPLETE:
            self.state=State.LAND
        elif self.state==State.LAND:
            self.state=State.DONE
        return event

def path():
    pts=[(0,0)]*3
    pts += [(x,0) for x in (.02,.05,.075,.095,.10,.10,.10,.10)]
    pts += [(.10,y) for y in (.02,.05,.075,.095,.10,.10,.10,.10)]
    pts += [(.10,.10)]*4
    return pts

def main():
    m=Mission()
    print("STEP 13 OFFLINE INTEGRATED MISSION")
    print("Flow: PREFLIGHT -> LOCALIZE -> ORIGIN -> WP1 -> WP2 -> LAND")
    for i,(x,y) in enumerate(path()):
        before=m.state.name
        ev=m.update(x,y)
        tgt=m.target()
        target=tgt[0] if tgt else "NONE"
        print(f"{i:02d} {before:16s} -> {m.state.name:16s} "
              f"pos=({x:+.3f},{y:+.3f}) target={target:4s} {ev}")
        if m.state==State.DONE: break
    print("RESULT:","PASS" if m.state==State.DONE else "FAIL")
    print("MODE  : OFFLINE ONLY / NO FLIGHT COMMANDS")

if __name__=="__main__":
    main()
