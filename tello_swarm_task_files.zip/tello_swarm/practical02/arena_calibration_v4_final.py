import cv2
import numpy as np
import time
from pathlib import Path


# ============================================================
# PRACTICAL 02
# ARENA CALIBRATION V4 FINAL
#
# Camera : EMEET C980 Pro
# Format : MJPG
# Size   : 1280 x 720
# FPS    : 30
#
# Arena  : 84" x 84"
#        : 2.1336 m x 2.1336 m
#
# Reference layout:
#
#              FAR SIDE
#
#        ID40 -------- ID41
#          |            |
#          |   ARENA    |
#          |            |
#        ID43 -------- ID42
#
#             CAMERA
#
# Explicit inner-corner mapping obtained from
# V4 corner diagnostic.
#
# C = calculate / lock
# S = save
# R = reset in memory
# Q = quit
# ============================================================


# ============================================================
# PATHS
# ============================================================

BASE_DIR = Path(__file__).resolve().parent

H_EMEET_FILE = (
    BASE_DIR /
    "arena_homography_emeet_c980_1280x720.npy"
)

H_COMPAT_FILE = (
    BASE_DIR /
    "arena_homography.npy"
)


# ============================================================
# CAMERA
# ============================================================

CAMERA_ID = 0

FRAME_W = 1280
FRAME_H = 720

CAMERA_FPS = 30


# ============================================================
# ARENA
# ============================================================

ARENA_WIDTH_M = 2.1336
ARENA_HEIGHT_M = 2.1336

WARP_W = 800
WARP_H = 800


# ============================================================
# ARUCO
# ============================================================

ARUCO_DICT = cv2.aruco.DICT_4X4_50

REFERENCE_IDS = [
    40,
    41,
    42,
    43
]

DRONE_IDS = [
    1,
    2,
    3
]


# ============================================================
# EXPLICIT INNER CORNER
# ============================================================

INNER_CORNER_INDEX = {
    40: 2,
    41: 0,
    42: 1,
    43: 0
}


# ============================================================
# FUNCTIONS
# ============================================================

def marker_center(corners):

    cx = float(
        np.mean(corners[:, 0])
    )

    cy = float(
        np.mean(corners[:, 1])
    )

    return cx, cy


def pixel_to_meter(px, py):

    x_m = (
        px / (WARP_W - 1)
    ) * ARENA_WIDTH_M

    y_m = (
        py / (WARP_H - 1)
    ) * ARENA_HEIGHT_M

    return x_m, y_m


def transform_point(H, x, y):

    point = np.array(
        [[[float(x), float(y)]]],
        dtype=np.float32
    )

    transformed = cv2.perspectiveTransform(
        point,
        H
    )

    return (
        float(transformed[0][0][0]),
        float(transformed[0][0][1])
    )


def draw_grid(frame):

    # --------------------------------------------
    # 0.25 m grid
    # --------------------------------------------

    step = 0.25

    x = 0.0

    while x <= ARENA_WIDTH_M:

        px = int(
            x / ARENA_WIDTH_M
            * (WARP_W - 1)
        )

        cv2.line(
            frame,
            (px, 0),
            (px, WARP_H - 1),
            (100, 100, 100),
            1
        )

        x += step


    y = 0.0

    while y <= ARENA_HEIGHT_M:

        py = int(
            y / ARENA_HEIGHT_M
            * (WARP_H - 1)
        )

        cv2.line(
            frame,
            (0, py),
            (WARP_W - 1, py),
            (100, 100, 100),
            1
        )

        y += step


    # --------------------------------------------
    # Arena centre
    # --------------------------------------------

    center_x_m = ARENA_WIDTH_M / 2
    center_y_m = ARENA_HEIGHT_M / 2

    center_px = int(
        center_x_m
        / ARENA_WIDTH_M
        * (WARP_W - 1)
    )

    center_py = int(
        center_y_m
        / ARENA_HEIGHT_M
        * (WARP_H - 1)
    )


    cv2.drawMarker(
        frame,
        (center_px, center_py),
        (255, 0, 0),
        cv2.MARKER_CROSS,
        35,
        3
    )


    cv2.putText(
        frame,
        (
            f"CENTER "
            f"({center_x_m:.3f},"
            f"{center_y_m:.3f})"
        ),
        (
            center_px + 15,
            center_py - 15
        ),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.55,
        (255, 0, 0),
        2
    )


# ============================================================
# ARUCO DETECTOR
# ============================================================

dictionary = (
    cv2.aruco.getPredefinedDictionary(
        ARUCO_DICT
    )
)


parameters = (
    cv2.aruco.DetectorParameters()
)


parameters.cornerRefinementMethod = (
    cv2.aruco.CORNER_REFINE_SUBPIX
)

# Better distant-marker detection
parameters.adaptiveThreshWinSizeMin = 3
parameters.adaptiveThreshWinSizeMax = 53
parameters.adaptiveThreshWinSizeStep = 4

parameters.minMarkerPerimeterRate = 0.01
parameters.maxMarkerPerimeterRate = 4.0

parameters.polygonalApproxAccuracyRate = 0.05
parameters.minCornerDistanceRate = 0.03
parameters.minDistanceToBorder = 2


detector = cv2.aruco.ArucoDetector(
    dictionary,
    parameters
)


# ============================================================
# START CAMERA
# ============================================================

print()
print("=" * 70)
print(" ARENA CALIBRATION V4 FINAL")
print(" EMEET C980 PRO")
print("=" * 70)


cap = cv2.VideoCapture(
    CAMERA_ID,
    cv2.CAP_V4L2
)


if not cap.isOpened():

    print("[ERROR] Camera cannot open.")

    raise SystemExit


# ------------------------------------------------------------
# Force MJPG
# ------------------------------------------------------------

fourcc = cv2.VideoWriter_fourcc(
    *"MJPG"
)

cap.set(
    cv2.CAP_PROP_FOURCC,
    fourcc
)


# ------------------------------------------------------------
# Resolution
# ------------------------------------------------------------

cap.set(
    cv2.CAP_PROP_FRAME_WIDTH,
    FRAME_W
)

cap.set(
    cv2.CAP_PROP_FRAME_HEIGHT,
    FRAME_H
)


# ------------------------------------------------------------
# FPS
# ------------------------------------------------------------

cap.set(
    cv2.CAP_PROP_FPS,
    CAMERA_FPS
)


# ------------------------------------------------------------
# Fixed focus
# ------------------------------------------------------------

cap.set(
    cv2.CAP_PROP_AUTOFOCUS,
    0
)


time.sleep(2)


# ============================================================
# CHECK CAMERA SETTINGS
# ============================================================

actual_w = int(
    cap.get(cv2.CAP_PROP_FRAME_WIDTH)
)

actual_h = int(
    cap.get(cv2.CAP_PROP_FRAME_HEIGHT)
)

actual_fps = cap.get(
    cv2.CAP_PROP_FPS
)


fourcc_value = int(
    cap.get(cv2.CAP_PROP_FOURCC)
)


actual_fourcc = "".join([
    chr(
        (fourcc_value >> (8 * i))
        & 0xFF
    )
    for i in range(4)
])


print()
print("Camera settings:")
print(
    f"Resolution : {actual_w} x {actual_h}"
)
print(
    f"FPS        : {actual_fps:.1f}"
)
print(
    f"Format     : {actual_fourcc}"
)


if (
    actual_w != FRAME_W
    or
    actual_h != FRAME_H
):

    print()
    print(
        "[WARNING] Camera resolution "
        "is not 1280x720."
    )

    print(
        "Do NOT calibrate."
    )


# ============================================================
# IMPORTANT:
# DO NOT AUTO LOAD OLD HOMOGRAPHY
# ============================================================

H = None

calibration_locked = False


print()
print("=" * 70)
print(" EXPLICIT INNER CORNERS")
print("=" * 70)

for marker_id in REFERENCE_IDS:

    print(
        f"ID{marker_id} -> "
        f"corner "
        f"{INNER_CORNER_INDEX[marker_id]}"
    )


print()
print("=" * 70)
print(" CONTROLS")
print("=" * 70)

print("C = Calculate / lock NEW calibration")
print("S = Save calibration")
print("R = Reset calibration in memory")
print("Q = Quit")

print("=" * 70)
print()


# ============================================================
# FPS COUNTER
# ============================================================

fps_counter = 0
fps = 0.0

fps_start = time.time()


# ============================================================
# MAIN LOOP
# ============================================================

while True:

    ret, frame = cap.read()

    if not ret:
        continue


    display = frame.copy()


    # ========================================================
    # FPS
    # ========================================================

    fps_counter += 1


    if (
        time.time() - fps_start
        >= 1.0
    ):

        fps = (
            fps_counter
            /
            (time.time() - fps_start)
        )

        fps_counter = 0
        fps_start = time.time()


    # ========================================================
    # DETECT MARKERS
    # ========================================================

    corners, ids, rejected = (
        detector.detectMarkers(frame)
    )


    detected_ids = []

    reference_data = {}

    drone_data = {}


    if ids is not None:

        ids_flat = ids.flatten()


        for i, marker_id in enumerate(
            ids_flat
        ):

            marker_id = int(marker_id)

            detected_ids.append(
                marker_id
            )


            pts = corners[i][0].astype(
                np.float32
            )


            cx, cy = marker_center(
                pts
            )


            # --------------------------------------------
            # REFERENCE
            # --------------------------------------------

            if marker_id in REFERENCE_IDS:

                reference_data[
                    marker_id
                ] = pts


                cv2.polylines(
                    display,
                    [
                        pts.astype(
                            np.int32
                        )
                    ],
                    True,
                    (0, 255, 0),
                    3
                )


                cv2.putText(
                    display,
                    f"ID {marker_id}",
                    (
                        int(cx) - 25,
                        int(cy) - 25
                    ),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.65,
                    (0, 255, 0),
                    2
                )


                # ----------------------------------------
                # Explicit source corner
                # ----------------------------------------

                corner_index = (
                    INNER_CORNER_INDEX[
                        marker_id
                    ]
                )


                source_point = (
                    pts[corner_index]
                )


                sx = int(
                    source_point[0]
                )

                sy = int(
                    source_point[1]
                )


                cv2.circle(
                    display,
                    (sx, sy),
                    12,
                    (255, 0, 255),
                    -1
                )


                cv2.circle(
                    display,
                    (sx, sy),
                    14,
                    (255, 255, 255),
                    2
                )


                cv2.putText(
                    display,
                    (
                        f"SRC{marker_id}"
                        f"[{corner_index}]"
                    ),
                    (
                        sx + 12,
                        sy - 10
                    ),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.55,
                    (255, 0, 255),
                    2
                )


            # --------------------------------------------
            # DRONE
            # --------------------------------------------

            elif marker_id in DRONE_IDS:

                drone_data[
                    marker_id
                ] = pts


                cv2.polylines(
                    display,
                    [
                        pts.astype(
                            np.int32
                        )
                    ],
                    True,
                    (0, 255, 255),
                    3
                )


                cv2.drawMarker(
                    display,
                    (
                        int(cx),
                        int(cy)
                    ),
                    (0, 0, 255),
                    cv2.MARKER_CROSS,
                    20,
                    2
                )


                cv2.putText(
                    display,
                    f"ID {marker_id}",
                    (
                        int(cx) + 10,
                        int(cy) - 15
                    ),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.65,
                    (0, 255, 255),
                    2
                )


    # ========================================================
    # REFERENCE STATUS
    # ========================================================

    all_refs_visible = all(
        marker_id in reference_data
        for marker_id in REFERENCE_IDS
    )


    missing_refs = [
        marker_id
        for marker_id in REFERENCE_IDS
        if marker_id not in reference_data
    ]


    # ========================================================
    # DISPLAY STATUS
    # ========================================================

    if calibration_locked:

        status_text = (
            "CALIBRATION: LOCKED"
        )

        status_color = (
            0, 255, 0
        )

    else:

        status_text = (
            "CALIBRATION: NOT LOCKED"
        )

        status_color = (
            0, 0, 255
        )


    cv2.putText(
        display,
        status_text,
        (10, 35),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.8,
        status_color,
        2
    )


    cv2.putText(
        display,
        f"FPS: {fps:.1f}",
        (10, 70),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.6,
        (255, 255, 0),
        2
    )


    cv2.putText(
        display,
        (
            f"Camera: "
            f"{actual_w}x{actual_h} "
            f"{actual_fourcc}"
        ),
        (10, 100),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.55,
        (255, 255, 0),
        2
    )


    cv2.putText(
        display,
        (
            f"IDs: "
            f"{sorted(detected_ids)}"
        ),
        (10, 130),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.55,
        (255, 255, 0),
        2
    )


    if all_refs_visible:

        cv2.putText(
            display,
            (
                "SRC40-43 READY "
                "- PRESS C"
            ),
            (10, 165),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.65,
            (0, 255, 0),
            2
        )

    else:

        cv2.putText(
            display,
            (
                f"MISSING REF: "
                f"{missing_refs}"
            ),
            (10, 165),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.65,
            (0, 0, 255),
            2
        )


    # ========================================================
    # BIRD-EYE
    # ========================================================

    bird = None


    if (
        calibration_locked
        and
        H is not None
    ):

        bird = cv2.warpPerspective(
            frame,
            H,
            (WARP_W, WARP_H)
        )


        draw_grid(
            bird
        )


        # ----------------------------------------------------
        # Show drone marker coordinates
        # ----------------------------------------------------

        for marker_id, pts in (
            drone_data.items()
        ):

            cx, cy = marker_center(
                pts
            )


            bx, by = transform_point(
                H,
                cx,
                cy
            )


            x_m, y_m = pixel_to_meter(
                bx,
                by
            )


            if (
                0 <= bx < WARP_W
                and
                0 <= by < WARP_H
            ):

                cv2.drawMarker(
                    bird,
                    (
                        int(bx),
                        int(by)
                    ),
                    (0, 0, 255),
                    cv2.MARKER_CROSS,
                    30,
                    3
                )


                cv2.putText(
                    bird,
                    f"ID {marker_id}",
                    (
                        int(bx) + 12,
                        int(by) - 15
                    ),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.6,
                    (0, 255, 0),
                    2
                )


                cv2.putText(
                    bird,
                    (
                        f"X={x_m:.3f} "
                        f"Y={y_m:.3f}"
                    ),
                    (
                        int(bx) + 12,
                        int(by) + 12
                    ),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.55,
                    (0, 255, 255),
                    2
                )


    # ========================================================
    # WINDOWS
    # ========================================================

    cv2.imshow(
        "V4 FINAL - Original Camera",
        display
    )


    if bird is not None:

        cv2.imshow(
            "V4 FINAL - Arena Bird Eye",
            bird
        )


    # ========================================================
    # KEYBOARD
    # ========================================================

    key = cv2.waitKey(1) & 0xFF


    # --------------------------------------------------------
    # C = CALCULATE
    # --------------------------------------------------------

    if key == ord("c"):

        if not all_refs_visible:

            print()
            print(
                "[ERROR] Cannot calibrate."
            )

            print(
                f"Missing: {missing_refs}"
            )

            continue


        # ====================================================
        # EXPLICIT SOURCE POINTS
        # ====================================================

        src_points = np.array(
            [
                reference_data[40][
                    INNER_CORNER_INDEX[40]
                ],

                reference_data[41][
                    INNER_CORNER_INDEX[41]
                ],

                reference_data[42][
                    INNER_CORNER_INDEX[42]
                ],

                reference_data[43][
                    INNER_CORNER_INDEX[43]
                ]
            ],
            dtype=np.float32
        )


        # ====================================================
        # DESTINATION
        #
        # ID40 -> top-left
        # ID41 -> top-right
        # ID42 -> bottom-right
        # ID43 -> bottom-left
        # ====================================================

        dst_points = np.array(
            [
                [0, 0],

                [
                    WARP_W - 1,
                    0
                ],

                [
                    WARP_W - 1,
                    WARP_H - 1
                ],

                [
                    0,
                    WARP_H - 1
                ]
            ],
            dtype=np.float32
        )


        H = cv2.getPerspectiveTransform(
            src_points,
            dst_points
        )


        calibration_locked = True


        print()
        print("=" * 70)
        print(" NEW V4 CALIBRATION LOCKED")
        print("=" * 70)

        print()
        print("Source points:")

        print(
            "ID40:",
            src_points[0]
        )

        print(
            "ID41:",
            src_points[1]
        )

        print(
            "ID42:",
            src_points[2]
        )

        print(
            "ID43:",
            src_points[3]
        )


        print()
        print("Homography:")

        print(H)


        print()
        print(
            "CHECK BIRD-EYE BEFORE "
            "PRESSING S."
        )


    # --------------------------------------------------------
    # S = SAVE
    # --------------------------------------------------------

    elif key == ord("s"):

        if (
            H is None
            or
            not calibration_locked
        ):

            print()
            print(
                "[ERROR] No calibration "
                "to save."
            )

            continue


        np.save(
            H_EMEET_FILE,
            H
        )


        np.save(
            H_COMPAT_FILE,
            H
        )


        print()
        print("=" * 70)
        print(" V4 CALIBRATION SAVED")
        print("=" * 70)

        print()
        print("EMEET:")
        print(H_EMEET_FILE)

        print()
        print("Compatibility:")
        print(H_COMPAT_FILE)


    # --------------------------------------------------------
    # R = RESET
    # --------------------------------------------------------

    elif key == ord("r"):

        H = None

        calibration_locked = False


        print()
        print(
            "[RESET] Calibration cleared "
            "from memory."
        )


        try:

            cv2.destroyWindow(
                "V4 FINAL - Arena Bird Eye"
            )

        except Exception:

            pass


    # --------------------------------------------------------
    # Q = QUIT
    # --------------------------------------------------------

    elif key == ord("q"):

        break


# ============================================================
# CLOSE
# ============================================================

cap.release()

cv2.destroyAllWindows()


print()
print("=" * 70)
print(" V4 FINAL CLOSED")
print("=" * 70)
