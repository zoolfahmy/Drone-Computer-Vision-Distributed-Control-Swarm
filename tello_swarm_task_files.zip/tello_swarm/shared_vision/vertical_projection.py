#!/usr/bin/env python3
"""
VERTICAL PROJECTION TEST  -  shared camera  (Practical Work 2, Task 4)
=====================================================================

Shared-camera version of practical04/p04b_vertical_projection_test.py (P04-B).
Run it on any Raspberry Pi on the class network; camera_host.py runs on the
camera Pi.  This program opens no camera and connects to no Tello.

    python3 shared_vision/vertical_projection.py
    python3 shared_vision/vertical_projection.py --marker 2

PURPOSE
Measure the apparent X/Y position error caused ONLY by the height of the
marker, while the marker centre stays vertically above the floor point P5:

    P5 = (1.0668, 1.0668) m          heights 0, 20, 40, 50, 60, 70 cm
    20 samples at each height

IMPORTANT
The marker must NOT be moved sideways to make the displayed X/Y match P5.

Keys (click the window, or type in the terminal the script was started from):

    SPACE = capture current height
    N     = skip current height
    Q     = quit

The CSV log (shared_vision/logs/vertical_projection_<time>.csv) has the same
columns as the P04-B log.
"""

import argparse
import csv
import os
import time
from datetime import datetime
from pathlib import Path

import cv2
import numpy as np

from fly_step10 import TerminalKeys, window_key
from vision_client import POSE_PORT, VisionClient

# ============================================================
# P5 AND THE TEST HEIGHTS   (the P04-B values)
# ============================================================

TRUE_X = 1.0668
TRUE_Y = 1.0668

HEIGHTS_CM = [0, 20, 40, 50, 60, 70]

SAMPLES_PER_HEIGHT = 20
SAMPLE_INTERVAL = 0.10       # seconds between two samples
MAX_AGE_S = 0.50             # a position older than this is not used
CAPTURE_TIMEOUT_S = 8.0      # give up on a height if the marker disappears

BASE_DIR = Path(__file__).resolve().parent
LOG_DIR = BASE_DIR / "logs"
WINDOW = "P04-B - Vertical projection (shared camera)"
FONT = cv2.FONT_HERSHEY_SIMPLEX


def read_marker(vision, marker_id):
    """Latest measurement of the marker: (sequence, u, v, x, y), or None."""
    state = vision.get_state(marker_id)
    if not state["detected"]:
        return None
    if time.perf_counter() - state["frame_read_timestamp"] > MAX_AGE_S:
        return None
    marker = vision.markers().get(marker_id)
    if marker is None:
        return None
    return (state["frame_sequence"], float(marker["u"]), float(marker["v"]),
            float(state["x"]), float(state["y"]))


def draw(vision, marker_id, reading, height_cm, lines):
    image, age = vision.get_image()
    if image is None or age is None or age > 1.0:
        frame = np.zeros((720, 1280, 3), np.uint8)
        cv2.putText(frame, "No picture from the camera host (positions still work)",
                    (20, 690), FONT, 0.6, (0, 200, 255), 2)
    else:
        frame = image.copy()

    frame[0:150] = (frame[0:150] * 0.30).astype(np.uint8)    # darker band behind the text
    cv2.putText(frame, "P04-B VERTICAL PROJECTION TEST  (shared camera)",
                (10, 30), FONT, 0.75, (0, 255, 255), 2)
    cv2.putText(frame, f"P5 TRUE = ({TRUE_X:.4f}, {TRUE_Y:.4f}) m     "
                       f"marker ID{marker_id}", (10, 62), FONT, 0.6, (255, 255, 255), 2)
    if reading is None:
        cv2.putText(frame, f"ID{marker_id} NOT DETECTED", (10, 96), FONT, 0.7,
                    (0, 0, 255), 2)
    else:
        _, _, _, x, y = reading
        ex, ey = x - TRUE_X, y - TRUE_Y
        cv2.putText(frame, f"RAW X={x:.4f} Y={y:.4f} m   dX={ex * 100:+.2f} cm "
                           f"dY={ey * 100:+.2f} cm   2D={np.hypot(ex, ey) * 100:.2f} cm",
                    (10, 96), FONT, 0.6, (0, 255, 0), 2)
    for k, line in enumerate(lines):
        cv2.putText(frame, line, (10, 130 + 26 * k), FONT, 0.6, (255, 255, 0), 2)
    cv2.putText(frame, "SPACE=CAPTURE   N=SKIP   Q=QUIT",
                (10, frame.shape[0] - 20), FONT, 0.6, (255, 255, 255), 2)
    return frame


def main(argv=None):
    ap = argparse.ArgumentParser(
        description="Vertical projection test with the shared overhead camera.")
    ap.add_argument("--marker", type=int, default=1,
                    help="ArUco ID of the marker held above P5 (default 1)")
    ap.add_argument("--port", type=int, default=POSE_PORT)
    ap.add_argument("--no-display", action="store_true",
                    help="no window: prompts and keys in the terminal only")
    args = ap.parse_args(argv)
    marker_id = args.marker

    use_window = not args.no_display
    if use_window and not os.environ.get("DISPLAY"):
        print("[INFO] No screen found (DISPLAY is not set): running without a "
              "window. Keys are read from this terminal.")
        use_window = False

    try:
        vision = VisionClient(port=args.port, video=use_window).start()
    except RuntimeError as exc:
        raise SystemExit(f"[ERROR] {exc}")

    LOG_DIR.mkdir(parents=True, exist_ok=True)
    csv_file = LOG_DIR / (
        f"vertical_projection_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv")
    csv_handle = open(csv_file, "w", newline="")
    writer = csv.writer(csv_handle)
    writer.writerow(["timestamp", "physical_z_cm", "sample", "pixel_u", "pixel_v",
                     "true_x_m", "true_y_m", "raw_x_m", "raw_y_m",
                     "error_x_m", "error_y_m", "error_2d_m"])
    csv_handle.flush()

    print()
    print("=" * 72)
    print(" P04-B - VERTICAL PROJECTION TEST  (shared camera)")
    print("=" * 72)
    print()
    print("NO FLIGHT")
    print("NO TELLO CONNECTION")
    print()
    print(f"P5 TRUE = ({TRUE_X:.4f}, {TRUE_Y:.4f}) m")
    print(f"HEIGHTS = {HEIGHTS_CM} cm")
    print(f"SAMPLES/HEIGHT = {SAMPLES_PER_HEIGHT}")
    print()
    print("IMPORTANT:")
    print(f"Keep ID{marker_id} centre vertically above physical P5.")
    print(f"DO NOT move ID{marker_id} horizontally to correct displayed XY.")
    print()
    print("SPACE = capture current height")
    print("N     = skip current height")
    print("Q     = quit")
    print()

    keys = TerminalKeys()
    summary = []
    stopped = False

    def next_key(reading, height_cm, lines):
        """Show the picture (if any) and return one key press, or None."""
        key = keys.poll()
        if use_window:
            cv2.imshow(WINDOW, draw(vision, marker_id, reading, height_cm, lines))
            k = window_key(cv2.waitKeyEx(20))
            if k is not None and key is None:
                key = k
        else:
            time.sleep(0.02)
        return key.lower() if key else None

    try:
        if use_window:
            cv2.namedWindow(WINDOW, cv2.WINDOW_NORMAL | cv2.WINDOW_KEEPRATIO
                            | cv2.WINDOW_GUI_NORMAL)
            cv2.resizeWindow(WINDOW, 1280, 720)

        waited = time.perf_counter()
        while vision.link_age() > 1.0:
            if time.perf_counter() - waited > 5.0:
                print("  no pose packets  - is camera_host.py running, and is "
                      "this Pi on the same network (Ethernet switch)?")
                waited = time.perf_counter()
            if next_key(None, HEIGHTS_CM[0], ["Waiting for the camera host..."]) in ("q", "\x03"):
                raise KeyboardInterrupt
        print(f"Camera host: {vision.host_ip}")
        print()

        for height_cm in HEIGHTS_CM:
            print(f">>> Place ID{marker_id} at Z = {height_cm} cm above P5, "
                  "then press SPACE (N = skip, Q = quit).")
            captured = False

            while not captured:
                reading = read_marker(vision, marker_id)
                key = next_key(reading, height_cm,
                               [f"NEXT: Z = {height_cm} cm   -   press SPACE to capture"])

                if key == " ":
                    if reading is None:
                        print()
                        print(f"[BLOCKED] ID{marker_id} not detected.")
                        continue

                    print()
                    print("=" * 65)
                    print(f"PHYSICAL Z = {height_cm} cm")
                    print(f"Collecting {SAMPLES_PER_HEIGHT} samples...")
                    print("=" * 65)

                    us, vs, xs, ys, exs, eys, errors = [], [], [], [], [], [], []
                    rows = []
                    last_sequence = -1
                    last_sample_time = 0.0
                    started = time.perf_counter()
                    aborted = False

                    while len(errors) < SAMPLES_PER_HEIGHT:
                        now = time.perf_counter()
                        if now - started > CAPTURE_TIMEOUT_S:
                            aborted = True
                            break
                        reading = read_marker(vision, marker_id)
                        k = next_key(reading, height_cm,
                                     [f"CAPTURING Z = {height_cm} cm   "
                                      f"{len(errors)}/{SAMPLES_PER_HEIGHT}"])
                        if k in ("q", "\x03"):
                            raise KeyboardInterrupt
                        if (reading is None or reading[0] == last_sequence
                                or now - last_sample_time < SAMPLE_INTERVAL):
                            continue
                        last_sequence, u2, v2, x2, y2 = reading
                        last_sample_time = now

                        ex2 = x2 - TRUE_X
                        ey2 = y2 - TRUE_Y
                        e2d = float(np.sqrt(ex2 ** 2 + ey2 ** 2))
                        us.append(u2); vs.append(v2); xs.append(x2); ys.append(y2)
                        exs.append(ex2); eys.append(ey2); errors.append(e2d)
                        sample = len(errors)
                        rows.append([datetime.now().isoformat(), height_cm, sample,
                                     f"{u2:.3f}", f"{v2:.3f}",
                                     f"{TRUE_X:.6f}", f"{TRUE_Y:.6f}",
                                     f"{x2:.6f}", f"{y2:.6f}",
                                     f"{ex2:.6f}", f"{ey2:.6f}", f"{e2d:.6f}"])
                        print(f"{sample:02d}/{SAMPLES_PER_HEIGHT}"
                              f"  u={u2:7.2f}  v={v2:7.2f}"
                              f"  X={x2:.4f}  Y={y2:.4f}"
                              f"  Err={e2d * 100:.2f}cm")

                    if aborted:
                        print()
                        print(f"[BLOCKED] ID{marker_id} was lost during the capture. "
                              "Nothing was saved for this height. Press SPACE again.")
                        continue

                    writer.writerows(rows)
                    csv_handle.flush()

                    mean_error = float(np.mean(errors))
                    max_error = float(np.max(errors))
                    result = {
                        "z": height_cm,
                        "u": float(np.mean(us)), "v": float(np.mean(vs)),
                        "x": float(np.mean(xs)), "y": float(np.mean(ys)),
                        "ex": float(np.mean(exs)), "ey": float(np.mean(eys)),
                        "error": mean_error, "max_error": max_error,
                        "std_x": float(np.std(xs)), "std_y": float(np.std(ys)),
                    }
                    summary.append(result)

                    print()
                    print("-" * 65)
                    print(f"Z             : {height_cm} cm")
                    print(f"Mean pixel    : u={result['u']:.2f}, v={result['v']:.2f}")
                    print(f"Mean RAW XY   : {result['x']:.4f}, {result['y']:.4f} m")
                    print(f"Mean dX       : {result['ex'] * 100:+.2f} cm")
                    print(f"Mean dY       : {result['ey'] * 100:+.2f} cm")
                    print(f"Mean 2D error : {mean_error * 100:.2f} cm")
                    print(f"Max 2D error  : {max_error * 100:.2f} cm")
                    print(f"Std X/Y       : {result['std_x'] * 100:.3f} / "
                          f"{result['std_y'] * 100:.3f} cm")
                    print("-" * 65)
                    print()
                    captured = True

                elif key == "n":
                    print(f"[SKIP] Z={height_cm} cm")
                    captured = True

                elif key in ("q", "\x03"):
                    raise KeyboardInterrupt

        print()
        print("=" * 88)
        print(" VERTICAL PROJECTION SUMMARY")
        print("=" * 88)
        print(f"{'Z cm':>6}{'Pixel U':>11}{'Pixel V':>11}{'Raw X':>10}{'Raw Y':>10}"
              f"{'dX cm':>10}{'dY cm':>10}{'2D cm':>10}")
        print("-" * 88)
        for r in summary:
            print(f"{r['z']:>6.0f}{r['u']:>11.2f}{r['v']:>11.2f}"
                  f"{r['x']:>10.4f}{r['y']:>10.4f}"
                  f"{r['ex'] * 100:>10.2f}{r['ey'] * 100:>10.2f}"
                  f"{r['error'] * 100:>10.2f}")
        print()
        print("CSV:")
        print(csv_file)
        print()
        print("P04-B COMPLETE")

    except KeyboardInterrupt:
        stopped = True
        print()
        print("[STOP] Test stopped.")
        if summary:
            print("CSV:")
            print(csv_file)

    finally:
        csv_handle.close()
        keys.restore()
        vision.stop()
        if use_window:
            cv2.destroyAllWindows()
        print()
        print("Program finished.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
