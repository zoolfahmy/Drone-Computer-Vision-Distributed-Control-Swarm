import cv2
import time
from collections import deque

# ==========================================================
# PRACTICAL 02 - VERSION 2
# ArUco Multi-Drone Tracking
# Raw Position + Filtered Position + Error + FPS
# ==========================================================

CAMERA_ID = 0

FRAME_WIDTH = 1280
FRAME_HEIGHT = 720

# Camera centre / temporary target
TARGET_X = FRAME_WIDTH // 2
TARGET_Y = FRAME_HEIGHT // 2

# Moving average filter
FILTER_SIZE = 5

# ArUco IDs used for Tello swarm
VALID_IDS = [1, 2, 3]


# ==========================================================
# ArUco Setup
# ==========================================================

aruco_dict = cv2.aruco.getPredefinedDictionary(
    cv2.aruco.DICT_4X4_50
)

parameters = cv2.aruco.DetectorParameters()

detector = cv2.aruco.ArucoDetector(
    aruco_dict,
    parameters
)


# ==========================================================
# Position history for filtering
# ==========================================================

history = {}

for marker_id in VALID_IDS:

    history[marker_id] = {
        "x": deque(maxlen=FILTER_SIZE),
        "y": deque(maxlen=FILTER_SIZE)
    }


# ==========================================================
# Open Camera
# ==========================================================

cap = cv2.VideoCapture(CAMERA_ID)

if not cap.isOpened():

    print("ERROR: Camera cannot be opened")
    exit()


cap.set(
    cv2.CAP_PROP_FRAME_WIDTH,
    FRAME_WIDTH
)

cap.set(
    cv2.CAP_PROP_FRAME_HEIGHT,
    FRAME_HEIGHT
)


actual_width = int(
    cap.get(cv2.CAP_PROP_FRAME_WIDTH)
)

actual_height = int(
    cap.get(cv2.CAP_PROP_FRAME_HEIGHT)
)


print("============================================")
print(" PRACTICAL 02 - ARUCO SWARM TRACKING V2")
print("============================================")

print("Camera resolution:",
      actual_width,
      "x",
      actual_height)

print("Tracking IDs:",
      VALID_IDS)

print("Filter size:",
      FILTER_SIZE)

print()
print("Q = Quit")
print()


# ==========================================================
# FPS variables
# ==========================================================

previous_time = time.time()

fps_filtered = 0


# ==========================================================
# Main Loop
# ==========================================================

while True:

    ret, frame = cap.read()

    if not ret:

        print("ERROR: Cannot read camera frame")
        break


    # ------------------------------------------------------
    # FPS
    # ------------------------------------------------------

    current_time = time.time()

    delta_time = current_time - previous_time

    previous_time = current_time


    if delta_time > 0:

        fps = 1 / delta_time

        # Smooth FPS display
        fps_filtered = (
            0.9 * fps_filtered
            + 0.1 * fps
        )


    # ------------------------------------------------------
    # Convert image to grayscale
    # ------------------------------------------------------

    gray = cv2.cvtColor(
        frame,
        cv2.COLOR_BGR2GRAY
    )


    # ------------------------------------------------------
    # Detect ArUco markers
    # ------------------------------------------------------

    corners, ids, rejected = detector.detectMarkers(
        gray
    )


    # ------------------------------------------------------
    # Draw target point
    # ------------------------------------------------------

    cv2.drawMarker(
        frame,
        (TARGET_X, TARGET_Y),
        (255, 0, 0),
        cv2.MARKER_CROSS,
        35,
        3
    )

    cv2.putText(
        frame,
        "TARGET",
        (TARGET_X + 15,
         TARGET_Y - 15),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.6,
        (255, 0, 0),
        2
    )


    # ------------------------------------------------------
    # Marker processing
    # ------------------------------------------------------

    if ids is not None:

        cv2.aruco.drawDetectedMarkers(
            frame,
            corners,
            ids
        )


        for marker_corner, marker_id in zip(
            corners,
            ids.flatten()
        ):

            marker_id = int(marker_id)


            # Only process Tello IDs
            if marker_id not in VALID_IDS:
                continue


            points = marker_corner.reshape(
                (4, 2)
            )


            top_left = points[0]

            top_right = points[1]

            bottom_right = points[2]

            bottom_left = points[3]


            # ------------------------------------------------
            # RAW centre position
            # ------------------------------------------------

            raw_x = int(
                (
                    top_left[0]
                    + top_right[0]
                    + bottom_right[0]
                    + bottom_left[0]
                ) / 4
            )


            raw_y = int(
                (
                    top_left[1]
                    + top_right[1]
                    + bottom_right[1]
                    + bottom_left[1]
                ) / 4
            )


            # ------------------------------------------------
            # Store position
            # ------------------------------------------------

            history[marker_id]["x"].append(
                raw_x
            )

            history[marker_id]["y"].append(
                raw_y
            )


            # ------------------------------------------------
            # Moving Average Filter
            # ------------------------------------------------

            filtered_x = int(
                sum(
                    history[marker_id]["x"]
                )
                /
                len(
                    history[marker_id]["x"]
                )
            )


            filtered_y = int(
                sum(
                    history[marker_id]["y"]
                )
                /
                len(
                    history[marker_id]["y"]
                )
            )


            # ------------------------------------------------
            # Position error
            # ------------------------------------------------

            error_x = (
                filtered_x
                - TARGET_X
            )

            error_y = (
                filtered_y
                - TARGET_Y
            )


            # ------------------------------------------------
            # Draw RAW position
            # ------------------------------------------------

            cv2.circle(
                frame,
                (raw_x, raw_y),
                5,
                (0, 0, 255),
                -1
            )


            # ------------------------------------------------
            # Draw FILTERED position
            # ------------------------------------------------

            cv2.circle(
                frame,
                (
                    filtered_x,
                    filtered_y
                ),
                8,
                (0, 255, 0),
                2
            )


            # ------------------------------------------------
            # Draw line:
            # filtered position -> target
            # ------------------------------------------------

            cv2.line(
                frame,
                (
                    filtered_x,
                    filtered_y
                ),
                (
                    TARGET_X,
                    TARGET_Y
                ),
                (255, 255, 0),
                1
            )


            # ------------------------------------------------
            # Text
            # ------------------------------------------------

            text1 = (
                f"ID:{marker_id} "
                f"RAW({raw_x},{raw_y})"
            )


            text2 = (
                f"FILT({filtered_x},{filtered_y}) "
                f"ERR({error_x},{error_y})"
            )


            cv2.putText(
                frame,
                text1,
                (
                    filtered_x + 15,
                    filtered_y - 25
                ),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.55,
                (0, 255, 0),
                2
            )


            cv2.putText(
                frame,
                text2,
                (
                    filtered_x + 15,
                    filtered_y
                ),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.50,
                (0, 255, 255),
                2
            )


    # ------------------------------------------------------
    # FPS display
    # ------------------------------------------------------

    cv2.putText(
        frame,
        f"FPS: {fps_filtered:.1f}",
        (20, 35),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.8,
        (0, 255, 0),
        2
    )


    cv2.putText(
        frame,
        f"Target: ({TARGET_X},{TARGET_Y})",
        (20, 65),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.65,
        (255, 0, 0),
        2
    )


    # ------------------------------------------------------
    # Display
    # ------------------------------------------------------

    cv2.imshow(
        "Practical 02 - ArUco Swarm Tracking V2",
        frame
    )


    key = cv2.waitKey(1) & 0xFF


    if key == ord("q"):
        break


# ==========================================================
# Cleanup
# ==========================================================

cap.release()

cv2.destroyAllWindows()

print("Tracking stopped")
