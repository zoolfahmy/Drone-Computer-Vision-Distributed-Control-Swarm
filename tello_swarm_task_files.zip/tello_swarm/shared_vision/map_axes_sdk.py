#!/usr/bin/env python3
"""
MAP AXES SDK  -  measure the drone's body axes in the arena frame with the
Tello's own 20 cm move commands (forward/back/right/left).
==========================================================================

A 0.4 s RC6 pulse moves the drone ~5 cm, the same size as its natural hover
wander, so its direction cannot be trusted (map_axes.py, 7 Oct 2026).  The SDK
move commands travel 20 cm along the body axes (the same axes as the FB / LR
sticks), well above the wander, and each opposite pair cross-checks the other.

Needs camera_host.py running.  No keyboard; armed on the command line:

    python3 map_axes_sdk.py --sim                       # dry run, nothing flies
    python3 map_axes_sdk.py --confirm MAP-SDK-20        # real flight

Flight:  take off -> stabilise 5 s -> speed 10 cm/s -> hold 2 s
         -> forward 20 -> hold 2 s -> back 20 -> hold 2 s
         -> right 20   -> hold 2 s -> left 20 -> hold 2 s -> land

Automatic stops (land): marker lost > 1.0 s, displacement from the origin
> 35 cm, arena margin 20 cm, ToF outside 30-160 cm, a move answered with
anything but "ok", Ctrl+C / SIGTERM, any error.

Writes logs/map_axes_sdk_<ts>.csv and .json (direction in arena degrees,
0 = +X towards ID41, 90 = +Y towards the camera / ID43).
"""
import argparse
import csv
import json
import logging
import math
import signal
import sys
import threading
import time
from datetime import datetime
from pathlib import Path

import numpy as np

from vision_client import POSE_PORT, VisionClient
from fly_step10 import FakeTello, vision_is_fresh

MIN_BATTERY = 50
STABILIZE_S = 5.0
HOLD_S = 2.0
MOVE_CM = 20
MOVE_SPEED_CM_S = 10           # slowest SDK speed: fast moves blurred the marker (7 Oct)
MOVE_TIMEOUT_S = 8.0
SETTLE_WINDOW_S = 0.6          # position = median of the last 0.6 s of each hold
LOOP_DT = 0.05

# At flight height the floor homography magnifies motion (parallax): a 20 cm
# move plus hover wander read 36.7 cm on 7 Oct.  The arena margin still applies.
MAX_DISPLACEMENT_M = 0.50
VISION_LAND_S = 1.0
# During and after a 20 cm SDK move the drone stops by itself; the marker blurs
# out for ~1 s while it moves (7 Oct), so allow longer there.
VISION_LAND_MOVE_S = 2.0
ARENA_W = ARENA_H = 2.1336
ARENA_MARGIN_M = 0.20
TOF_MIN_CM, TOF_MAX_CM = 30, 160

MOVES = ["forward", "back", "right", "left"]
TOKEN = f"MAP-SDK-{MOVE_CM}"

BASE_DIR = Path(__file__).resolve().parent
LOG_DIR = BASE_DIR / "logs"


class Abort(Exception):
    pass


class SimTello(FakeTello):
    def send_command_with_return(self, command, timeout=7):
        time.sleep(1.5)
        return "ok"


def on_sigterm(signum, frame):
    raise KeyboardInterrupt


def arena_safe(x, y):
    return (ARENA_MARGIN_M <= x <= ARENA_W - ARENA_MARGIN_M
            and ARENA_MARGIN_M <= y <= ARENA_H - ARENA_MARGIN_M)


def hold_position(rows, label):
    pts = [r for r in rows if r["phase"] == label and r["fresh"]]
    if not pts:
        return None
    t_end = pts[-1]["t"]
    win = [r for r in pts if r["t"] >= t_end - SETTLE_WINDOW_S] or pts
    return (float(np.median([r["x"] for r in win])),
            float(np.median([r["y"] for r in win])),
            float(np.std([r["x"] for r in win])),
            float(np.std([r["y"] for r in win])))


def vec(d):
    return {"dx_cm": round(d[0] * 100, 1), "dy_cm": round(d[1] * 100, 1),
            "magnitude_cm": round(math.hypot(*d) * 100, 1),
            "direction_deg": round(math.degrees(math.atan2(d[1], d[0])), 1)}


def analyse(rows, moves):
    out = {"moves": {}}
    holds = {}
    for label in ["HOLD_0"] + [f"HOLD_{m}" for m in moves]:
        holds[label] = hold_position(rows, label)
    prev = "HOLD_0"
    deltas = {}
    for m in moves:
        a, b = holds.get(prev), holds.get(f"HOLD_{m}")
        if a is None or b is None:
            break
        d = (b[0] - a[0], b[1] - a[1])
        deltas[m] = d
        out["moves"][m] = vec(d)
        prev = f"HOLD_{m}"
    noise = [max(h[2], h[3]) for h in holds.values() if h is not None]
    out["hold_jitter_max_cm"] = round(max(noise) * 100, 2) if noise else None
    if "forward" in deltas and "back" in deltas:
        f = ((deltas["forward"][0] - deltas["back"][0]) / 2,
             (deltas["forward"][1] - deltas["back"][1]) / 2)
        out["FB_plus_axis"] = vec(f)
    if "right" in deltas and "left" in deltas:
        r = ((deltas["right"][0] - deltas["left"][0]) / 2,
             (deltas["right"][1] - deltas["left"][1]) / 2)
        out["LR_plus_axis"] = vec(r)
    if "FB_plus_axis" in out and "LR_plus_axis" in out:
        diff = out["LR_plus_axis"]["direction_deg"] - out["FB_plus_axis"]["direction_deg"]
        out["LR_minus_FB_deg"] = round((diff + 180) % 360 - 180, 1)
    angles = [r["angle"] for r in rows if r["fresh"] and r["angle"] is not None]
    out["marker_angle_median_deg"] = round(float(np.median(angles)), 1) if angles else None
    return out


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--marker", type=int, default=1)
    ap.add_argument("--tello-ip", default="192.168.10.1")
    ap.add_argument("--port", type=int, default=POSE_PORT)
    ap.add_argument("--sim", action="store_true", help="pretend Tello, nothing flies")
    ap.add_argument("--confirm", default="", help=f"arming token: {TOKEN}")
    ap.add_argument("--moves", default=",".join(MOVES),
                    help="comma list from forward,back,right,left (default all four)")
    args = ap.parse_args()
    moves = [m.strip() for m in args.moves.split(",") if m.strip()]
    if not moves or any(m not in MOVES for m in moves):
        raise SystemExit(f"--moves must be from {MOVES}")
    if not args.sim and args.confirm != TOKEN:
        raise SystemExit(f"Not armed. Real flight needs: --confirm {TOKEN}")

    signal.signal(signal.SIGTERM, on_sigterm)
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    stem = LOG_DIR / (f"map_axes_sdk_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
                      f"{'_SIM' if args.sim else ''}")

    print("=" * 64)
    print(f" MAP AXES SDK  {MOVE_CM} cm moves  marker ID{args.marker}"
          + ("   *** SIM ***" if args.sim else ""))
    print("=" * 64)

    vision = VisionClient(port=args.port, video=False).start()
    if args.sim:
        tello = SimTello()
    else:
        from djitellopy import Tello
        Tello.LOGGER.setLevel(logging.ERROR)
        tello = Tello(host=args.tello_ip)

    rows = []
    state = {"airborne": False, "origin": None}
    t_start = time.perf_counter()
    reason = "COMPLETE"

    def sample(phase, send_rc):
        now = time.perf_counter()
        st = vision.get_state(args.marker)
        fresh = vision_is_fresh(st)
        lost_for = now - st["last_detection_timestamp"]
        tof = None
        try:
            tof = int(tello.get_current_state().get("tof", -1))
        except Exception:
            pass
        if send_rc:
            tello.send_rc_control(0, 0, 0, 0)
        rows.append({
            "t": now - t_start, "phase": phase, "fresh": fresh,
            "x": st["x"], "y": st["y"], "angle": st["angle"],
            "frame_seq": st["frame_sequence"],
            "frame_age_s": now - st["frame_read_timestamp"], "tof_cm": tof,
        })
        moving = phase.startswith("MOVE_") or (phase.startswith("HOLD_") and phase != "HOLD_0")
        if state["airborne"] and lost_for > (VISION_LAND_MOVE_S if moving else VISION_LAND_S):
            raise Abort(f"VISION_LOST {lost_for:.2f}s")
        if state["airborne"] and phase != "STABILIZE" and tof is not None and tof > 0 \
                and not TOF_MIN_CM <= tof <= TOF_MAX_CM:
            raise Abort(f"TOF_OUT_OF_RANGE {tof} cm")
        origin = state["origin"]
        if fresh and origin is not None:
            d = math.hypot(st["x"] - origin[0], st["y"] - origin[1])
            if d > MAX_DISPLACEMENT_M:
                raise Abort(f"DISPLACEMENT {d*100:.1f} cm")
        if fresh and state["airborne"] and phase != "STABILIZE" \
                and not arena_safe(st["x"], st["y"]):
            raise Abort("ARENA_MARGIN")
        return st, fresh

    def hold(phase, seconds):
        end = time.perf_counter() + seconds
        nxt = time.perf_counter()
        while time.perf_counter() < end:
            sample(phase, send_rc=True)
            nxt += LOOP_DT
            time.sleep(max(0.0, nxt - time.perf_counter()))

    def move(direction):
        """SDK move in a worker thread; keep logging and safety checks meanwhile
        (no RC is sent while it runs: RC would cancel the move)."""
        result = {}

        def worker():
            try:
                result["reply"] = tello.send_command_with_return(
                    f"{direction} {MOVE_CM}", timeout=int(MOVE_TIMEOUT_S))
            except Exception as exc:
                result["reply"] = f"exception: {exc}"

        th = threading.Thread(target=worker, daemon=True)
        th.start()
        end = time.perf_counter() + MOVE_TIMEOUT_S + 1.0
        while th.is_alive():
            if time.perf_counter() > end:
                raise Abort(f"{direction}: no reply")
            sample(f"MOVE_{direction}", send_rc=False)
            time.sleep(LOOP_DT)
        reply = str(result.get("reply", "")).strip().lower()
        print(f"  {direction} {MOVE_CM}: {reply}")
        if reply != "ok":
            raise Abort(f"{direction}: reply '{reply}'")

    try:
        time.sleep(1.5)
        st = vision.get_state(args.marker)
        if not vision_is_fresh(st):
            raise Abort(f"No fresh ID{args.marker} from camera_host before takeoff")
        print(f"Vision OK  ID{args.marker} at X={st['x']:.3f} Y={st['y']:.3f} "
              f"angle={st['angle']:+.1f}  fps={st['fps']:.1f}")

        tello.connect()
        battery = int(tello.get_battery())
        print(f"Battery    {battery}%")
        if battery < MIN_BATTERY:
            raise Abort("BATTERY_LOW")
        if not vision_is_fresh(vision.get_state(args.marker)):
            raise Abort("Vision lost before takeoff")

        print("Taking off...")
        state["airborne"] = True               # every exit path from here lands
        tello.takeoff()
        tello.send_rc_control(0, 0, 0, 0)
        print(f"Stabilising {STABILIZE_S:.0f} s...")
        hold("STABILIZE", STABILIZE_S)

        reply = str(tello.send_command_with_return(f"speed {MOVE_SPEED_CM_S}")).strip().lower()
        print(f"  speed {MOVE_SPEED_CM_S}: {reply}")
        if reply != "ok":
            raise Abort(f"speed: reply '{reply}'")

        st, fresh = sample("HOLD_0", send_rc=True)
        if not fresh or not arena_safe(st["x"], st["y"]):
            raise Abort("Hover point not usable (vision or arena margin)")
        state["origin"] = (st["x"], st["y"])
        print(f"Origin     X={st['x']:.3f} Y={st['y']:.3f}")
        hold("HOLD_0", HOLD_S)

        for direction in moves:
            move(direction)
            hold(f"HOLD_{direction}", HOLD_S)

    except Abort as exc:
        reason = f"ABORT: {exc}"
    except KeyboardInterrupt:
        reason = "ABORT: user stop"
    except Exception as exc:
        reason = f"ERROR: {type(exc).__name__}: {exc}"
    finally:
        if state["airborne"]:
            print("Landing...")
            try:
                tello.get_own_udp_object()["responses"].clear()
            except Exception:
                pass
            try:
                tello.send_rc_control(0, 0, 0, 0)
                tello.land()
            except Exception as exc:
                print(f"[NOTE] land not confirmed ({exc}); sending again")
                try:
                    tello.send_command_without_return("land")
                except Exception:
                    pass
        try:
            tello.end()
        except Exception:
            pass
        vision.stop()

    print(f"Result     {reason}")
    if rows:
        with open(str(stem) + ".csv", "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            w.writeheader()
            w.writerows(rows)
        print(f"CSV        {stem}.csv")
    summary = {"result": reason, "sim": args.sim, "moves": moves,
               "analysis": analyse(rows, moves) if rows else None}
    with open(str(stem) + ".json", "w") as f:
        json.dump(summary, f, indent=2)
    print(json.dumps(summary, indent=2))
    return 0 if reason == "COMPLETE" else 1


if __name__ == "__main__":
    sys.exit(main())
