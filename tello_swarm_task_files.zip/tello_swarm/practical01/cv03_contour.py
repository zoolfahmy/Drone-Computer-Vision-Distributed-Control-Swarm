# Task 1C: contours
# Objective: find the outline of every region in the colour mask,
#            and measure the area and perimeter of each one
import json
from pathlib import Path

import cv2
import numpy as np

RANGE_FILE = Path(__file__).resolve().parent / "hsv_range.json"
FONT = cv2.FONT_HERSHEY_SIMPLEX

MIN_AREA = 500                                   # pixels; smaller regions are noise
HSV_RANGE = [100, 130, 120, 255, 60, 255]        # blue, used if no range was saved

if RANGE_FILE.exists():                          # the range you saved in Task 1B
    HSV_RANGE = json.loads(RANGE_FILE.read_text())


def colour_mask(hsv, values):
    """White where the pixel is inside the HSV range, black elsewhere."""
    h_min, h_max, s_min, s_max, v_min, v_max = values
    if h_min <= h_max:
        return cv2.inRange(hsv, (h_min, s_min, v_min), (h_max, s_max, v_max))
    upper_part = cv2.inRange(hsv, (h_min, s_min, v_min), (179, s_max, v_max))
    lower_part = cv2.inRange(hsv, (0, s_min, v_min), (h_max, s_max, v_max))
    return cv2.bitwise_or(upper_part, lower_part)


cap = cv2.VideoCapture(0)

if not cap.isOpened():
    print("ERROR: Camera /dev/video0 cannot be opened")
    exit()

cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)

print("Task 1C - Contours")
print("HSV range:", HSV_RANGE)
print("P = Print contours   Q = Quit")

kernel = np.ones((5, 5), np.uint8)

while True:

    ret, frame = cap.read()

    if not ret:
        print("ERROR: Cannot read camera frame")
        break

    # ---------- process ----------
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    mask = colour_mask(hsv, HSV_RANGE)

    # Clean the mask: remove small white dots, then fill small black holes
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)

    # A contour is the list of points along the border of one white region
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    found = []
    for contour in contours:
        area = cv2.contourArea(contour)
        if area >= MIN_AREA:
            perimeter = cv2.arcLength(contour, True)
            found.append((area, perimeter, contour))
    found.sort(key=lambda item: item[0], reverse=True)       # largest first

    # ---------- display ----------
    for number, (area, perimeter, contour) in enumerate(found, start=1):
        cv2.drawContours(frame, [contour], -1, (0, 255, 0), 3)
        x, y, w, h = cv2.boundingRect(contour)
        cv2.putText(frame, f"{number}: area {area:.0f}", (x, max(25, y - 10)),
                    FONT, 0.7, (0, 255, 0), 2)

    cv2.putText(frame, f"Contours: {len(found)}", (20, 35), FONT, 0.9, (0, 255, 255), 2)

    size = (640, 360)
    view = np.hstack([cv2.resize(frame, size),
                      cv2.cvtColor(cv2.resize(mask, size), cv2.COLOR_GRAY2BGR)])
    cv2.imshow("Task 1C - Contours", view)

    key = cv2.waitKey(1) & 0xFF

    if key == ord('q'):
        break

    elif key == ord('p'):
        print("Contours:", len(found))
        for number, (area, perimeter, contour) in enumerate(found, start=1):
            print(f"  {number}: area = {area:.0f} px   perimeter = {perimeter:.0f} px   "
                  f"points = {len(contour)}")

cap.release()
cv2.destroyAllWindows()

print("Camera closed")
