# Task 2: study a response matrix
import numpy as np

M = np.load("logs/p04b1_matrix_v2_20260929_170729.npy")
CALIBRATION_RC = 6          # the matrix was measured with RC +/-6

print("M =")
print(M)
print("det       :", round(float(np.linalg.det(M)), 8))
print("condition :", round(float(np.linalg.cond(M)), 4))

# Predict the arena velocity for one RC command
fb, lr = 6, -6
v = M @ np.array([fb / CALIBRATION_RC, lr / CALIBRATION_RC])
print("command FB", fb, "LR", lr)
print("predicted Vx, Vy (cm/s):", np.round(v * 100, 2))
