#!/usr/bin/env python3
"""
CAMERA HOST  -  shared overhead vision for the Tello arena
==========================================================

Run this on the ONE Raspberry Pi that has the overhead camera plugged in.
It is the only program that opens the camera.

    python3 camera_host.py                  # real camera
    python3 camera_host.py --simulate       # no camera: synthetic arena (bench test)
    python3 camera_host.py --show           # also open a local preview window

What it does, every frame:
  1. reads the EMEET camera (1280x720 MJPG, same settings as Step 10)
  2. tracks the drone markers (default IDs 1,2,3,4) with the same ROI tracker
     and ArUco parameters as p04b1_step10_brake_settle.py
  3. converts each marker to arena X,Y (metres) and angle with arena_homography.npy
  4. broadcasts ONE small UDP packet with all marker poses  (port 9870)
  5. serves the picture for people to watch            http://<this-pi>:8080/

The flight Pis never open the camera.  They run vision_client.py, which listens
for the pose packets.  Drones are steered from the poses; the video is only for
the display.

Only the Python standard library, NumPy and OpenCV are used - nothing to install.
"""

import argparse
import hashlib
import json
import math
import re
import socket
import subprocess
import threading
import time
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import cv2
import numpy as np


# ============================================================
# SETTINGS  (camera / arena / tracker values are the Step 10 values)
# ============================================================

CAMERA_ID = 0
FRAME_W = 1280
FRAME_H = 720
CAMERA_FPS = 30

ARENA_WIDTH_M = 2.1336
ARENA_HEIGHT_M = 2.1336
WARP_W = 800
WARP_H = 800

DRONE_IDS = [1, 2, 3, 4]          # one marker ID per drone
REFERENCE_IDS = [40, 41, 42, 43]  # arena corner markers (shown, not broadcast)

ROI_SIZE = 320
ROI_LOST_LIMIT = 3

POSE_PORT = 9870                  # UDP: marker poses
HTTP_PORT = 8080                  # HTTP: video for people / flight displays
STREAM_FPS = 15
STREAM_JPEG_QUALITY = 70

# Seconds between full-frame searches while at least one drone is being
# tracked.  The search runs in its own thread, so it never delays tracking.
SCOUT_PAUSE_S = 0.20

# Pose packets are never broadcast onto a Tello's own Wi-Fi network.
TELLO_NET_PREFIX = "192.168.10."

# Programs on this same Pi get the packets through the loopback *broadcast*
# address, so that several of them (a flight script and the link checker,
# say) each receive every packet.  Plain 127.0.0.1 would give each packet
# to only one of them.
LOCAL_TARGET = "127.255.255.255"

BASE_DIR = Path(__file__).resolve().parent
DEFAULT_H_FILE = BASE_DIR.parent / "practical02" / "arena_homography.npy"

PROTOCOL = "tello-arena-pose/1"


# ============================================================
# ARUCO  (identical parameters to Step 10)
# ============================================================

def make_detector():
    dictionary = cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_50)
    p = cv2.aruco.DetectorParameters()
    p.cornerRefinementMethod = cv2.aruco.CORNER_REFINE_SUBPIX
    p.adaptiveThreshWinSizeMin = 3
    p.adaptiveThreshWinSizeMax = 53
    p.adaptiveThreshWinSizeStep = 2
    p.minMarkerPerimeterRate = 0.005
    p.maxMarkerPerimeterRate = 4.0
    p.polygonalApproxAccuracyRate = 0.05
    p.minCornerDistanceRate = 0.01
    p.minMarkerDistanceRate = 0.01
    p.minDistanceToBorder = 2
    p.cornerRefinementWinSize = 5
    p.cornerRefinementMaxIterations = 50
    p.cornerRefinementMinAccuracy = 0.01
    return cv2.aruco.ArucoDetector(dictionary, p)


# ============================================================
# GEOMETRY  (identical maths to Step 10)
# ============================================================

def normalize_angle(angle):
    while angle > 180:
        angle -= 360
    while angle < -180:
        angle += 360
    return angle


def pixel_to_warp(H, u, v):
    point = np.array([[[u, v]]], dtype=np.float32)
    t = cv2.perspectiveTransform(point, H)
    return float(t[0][0][0]), float(t[0][0][1])


def pixel_to_xy(H, u, v):
    wx, wy = pixel_to_warp(H, u, v)
    return (wx / (WARP_W - 1) * ARENA_WIDTH_M,
            wy / (WARP_H - 1) * ARENA_HEIGHT_M)


def make_roi(center_x, center_y, frame_width, frame_height):
    half = ROI_SIZE // 2
    x1 = int(center_x - half)
    y1 = int(center_y - half)
    x2 = int(center_x + half)
    y2 = int(center_y + half)
    if x1 < 0:
        x2 -= x1
        x1 = 0
    if y1 < 0:
        y2 -= y1
        y1 = 0
    if x2 > frame_width:
        x1 -= x2 - frame_width
        x2 = frame_width
    if y2 > frame_height:
        y1 -= y2 - frame_height
        y2 = frame_height
    return max(0, x1), max(0, y1), x2, y2


def marker_pose(H, pts):
    """Corner points (4x2, camera pixels) -> u, v, arena x, y, angle."""
    u = float(np.mean(pts[:, 0]))
    v = float(np.mean(pts[:, 1]))
    x, y = pixel_to_xy(H, u, v)
    c0x, c0y = pixel_to_warp(H, pts[0][0], pts[0][1])
    c1x, c1y = pixel_to_warp(H, pts[1][0], pts[1][1])
    angle = normalize_angle(math.degrees(math.atan2(c1y - c0y, c1x - c0x)))
    return u, v, x, y, angle


# ============================================================
# MULTI-MARKER TRACKER
#
# Step 10 tracks one marker: search a 320x320 ROI around the last
# position, fall back to the full frame after 3 misses.  This is the
# same tracker, one ROI per drone.  The slow full-frame search runs in
# a separate "scout" thread and only tells the tracker where to look,
# so a drone that is already tracked is never slowed down by a search
# for one that is not there.
#
# Each tracked drone costs one ROI search per frame.  With all four in
# view, watch the fps this program prints; it should stay near 30.
# ============================================================

class MarkerTracker:

    def __init__(self, ids):
        self.ids = list(ids)
        self.detector = make_detector()
        self.track = {i: {"tracking": False, "center": None, "lost": 0}
                      for i in self.ids}
        self._seeds = {}
        self._lock = threading.Lock()

    def untracked(self):
        return [i for i in self.ids if not self.track[i]["tracking"]]

    def seed(self, marker_id, u, v):
        """Called by the scout thread: 'marker seen near (u, v)'."""
        with self._lock:
            self._seeds[marker_id] = (u, v)

    def update(self, gray):
        """Return {marker_id: 4x2 float32 corner points} for this frame."""
        h, w = gray.shape[:2]

        with self._lock:
            seeds, self._seeds = self._seeds, {}
        for marker_id, center in seeds.items():
            t = self.track[marker_id]
            if not t["tracking"]:
                t["tracking"] = True
                t["center"] = center
                t["lost"] = 0

        found = {}
        for marker_id in self.ids:
            t = self.track[marker_id]
            if not t["tracking"] or t["center"] is None:
                continue

            # ROI search, exactly as Step 10 does it for ID1.
            x1, y1, x2, y2 = make_roi(t["center"][0], t["center"][1], w, h)
            roi = np.ascontiguousarray(gray[y1:y2, x1:x2])
            corners, ids, _ = self.detector.detectMarkers(roi)
            pts = None
            if ids is not None:
                for i, seen_id in enumerate(ids.flatten()):
                    if int(seen_id) == marker_id:
                        pts = corners[i][0].astype(np.float32)
                        pts[:, 0] += x1
                        pts[:, 1] += y1
                        break

            if pts is not None:
                found[marker_id] = pts
                t["lost"] = 0
                t["center"] = (float(np.mean(pts[:, 0])),
                               float(np.mean(pts[:, 1])))
            else:
                t["lost"] += 1
                if t["lost"] >= ROI_LOST_LIMIT:
                    t["tracking"] = False
                    t["center"] = None

        return found


# ============================================================
# CAMERA SOURCES
# ============================================================

class RealCamera:
    """The overhead USB camera, opened exactly as Step 10 opens it."""

    simulated = False

    def __init__(self, camera_id):
        self.camera_id = camera_id
        self.cap = None
        self.open()

    def open(self):
        cap = cv2.VideoCapture(self.camera_id, cv2.CAP_V4L2)
        if not cap.isOpened():
            raise RuntimeError(
                f"Cannot open camera {self.camera_id}. Is it plugged in, and is "
                "another program (a flight script, camera_monitor.py) using it?")
        cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*"MJPG"))
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, FRAME_W)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, FRAME_H)
        cap.set(cv2.CAP_PROP_FPS, CAMERA_FPS)
        cap.set(cv2.CAP_PROP_AUTOFOCUS, 0)
        time.sleep(2)
        w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        if (w, h) != (FRAME_W, FRAME_H):
            cap.release()
            raise RuntimeError(
                f"Camera gives {w}x{h}; the homography needs {FRAME_W}x{FRAME_H}.")
        self.cap = cap

    def read(self):
        ok, frame = self.cap.read()
        return (ok and frame is not None), frame

    def reopen(self):
        try:
            self.cap.release()
        except Exception:
            pass
        self.open()

    def release(self):
        if self.cap is not None:
            self.cap.release()


SIM_HOME = {1: (1.30, 1.15), 2: (0.70, 0.70), 3: (1.45, 0.60), 4: (0.65, 1.50)}
SIM_MARKER_M = 0.14          # simulated marker edge length (metres)
SIM_ANGLE_DEG = 3.0


def sim_position(marker_id, t):
    """Arena X,Y (m) of a simulated marker at time t: a slow 3 cm wander."""
    hx, hy = SIM_HOME.get(marker_id, (1.0, 1.0))
    phase = marker_id * 1.7
    return (hx + 0.03 * math.sin(2 * math.pi * t / 14.0 + phase),
            hy + 0.03 * math.sin(2 * math.pi * t / 19.0 + 2 * phase))


class SimCamera:
    """Synthetic overhead view: arena floor, corner markers, drifting drone markers."""

    simulated = True
    PAD = 150                      # canvas border around the 800x800 arena (px)

    def __init__(self, H, ids):
        self.ids = list(ids)
        self.t0 = time.perf_counter()
        self.next_frame = self.t0
        shift = np.array([[1, 0, -self.PAD], [0, 1, -self.PAD], [0, 0, 1]], float)
        # canvas pixels -> warp pixels -> camera pixels
        self.M = np.linalg.inv(H) @ shift
        dictionary = cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_50)
        self.images = {i: cv2.aruco.generateImageMarker(dictionary, i, 120)
                       for i in self.ids + REFERENCE_IDS}
        size = WARP_W + 2 * self.PAD
        floor = np.full((size, size, 3), (96, 104, 108), np.uint8)
        a, b = self.PAD, self.PAD + WARP_W - 1
        cv2.rectangle(floor, (a, a), (b, b), (150, 160, 165), -1)
        cv2.rectangle(floor, (a, a), (b, b), (235, 235, 235), 3)
        for mid, (cx, cy) in zip(REFERENCE_IDS, [(a, a), (b, a), (b, b), (a, b)]):
            self._paste(floor, mid, cx, cy, 0.0)
        self.floor = floor

    def _paste(self, canvas, marker_id, cx, cy, angle_deg):
        px = SIM_MARKER_M / ARENA_WIDTH_M * (WARP_W - 1)      # marker edge in px
        img = cv2.copyMakeBorder(self.images[marker_id], 24, 24, 24, 24,
                                 cv2.BORDER_CONSTANT, value=255)
        scale = px / self.images[marker_id].shape[0]
        A = cv2.getRotationMatrix2D((img.shape[1] / 2, img.shape[0] / 2),
                                    -angle_deg, scale)
        A[0, 2] += cx - img.shape[1] / 2
        A[1, 2] += cy - img.shape[0] / 2
        cv2.warpAffine(cv2.cvtColor(img, cv2.COLOR_GRAY2BGR), A,
                       (canvas.shape[1], canvas.shape[0]), dst=canvas,
                       flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_TRANSPARENT)

    def read(self):
        delay = self.next_frame - time.perf_counter()
        if delay > 0:
            time.sleep(delay)
        self.next_frame = max(self.next_frame + 1.0 / CAMERA_FPS,
                              time.perf_counter() - 1.0)
        return True, self.render(time.perf_counter() - self.t0)

    def render(self, t):
        """The camera picture at simulation time t (seconds)."""
        canvas = self.floor.copy()
        for mid in self.ids:
            x, y = sim_position(mid, t)
            self._paste(canvas,
                        mid,
                        self.PAD + x / ARENA_WIDTH_M * (WARP_W - 1),
                        self.PAD + y / ARENA_HEIGHT_M * (WARP_H - 1),
                        SIM_ANGLE_DEG)
        frame = cv2.warpPerspective(canvas, self.M, (FRAME_W, FRAME_H),
                                    flags=cv2.INTER_LINEAR,
                                    borderMode=cv2.BORDER_CONSTANT,
                                    borderValue=(60, 62, 64))
        return frame

    def reopen(self):
        pass

    def release(self):
        pass


def default_sim_homography():
    """Used only by --simulate when no arena_homography.npy exists."""
    s = (WARP_W - 1) / 600.0
    return np.array([[s, 0, -340 * s], [0, s, -60 * s], [0, 0, 1]], float)


# ============================================================
# NETWORK TARGETS
# ============================================================

def broadcast_addresses(ip_addr_output):
    """Broadcast address of every LAN in `ip -4 -o addr show` output,
    skipping loopback and any Tello Wi-Fi network."""
    found = []
    for line in ip_addr_output.splitlines():
        m = re.search(
            r"inet (\d+\.\d+\.\d+\.\d+)/\d+(?: brd (\d+\.\d+\.\d+\.\d+))?", line)
        if not m or not m.group(2):
            continue
        ip, brd = m.group(1), m.group(2)
        if ip.startswith("127.") or ip.startswith(TELLO_NET_PREFIX):
            continue
        found.append(brd)
    return found


def discover_targets(extra):
    """Where to send pose packets: programs on this Pi, every LAN this Pi is on
    (as a broadcast, so flight Pis need no address set up), plus any
    --target addresses."""
    targets = [LOCAL_TARGET]
    try:
        out = subprocess.run(["ip", "-4", "-o", "addr", "show"],
                             capture_output=True, text=True, timeout=2).stdout
        targets += broadcast_addresses(out)
    except Exception:
        targets.append("255.255.255.255")
    targets += list(extra)
    return list(dict.fromkeys(targets))


def describe_targets(targets):
    names = ["this Pi" if t == LOCAL_TARGET else t for t in targets]
    if len(names) == 1:
        names.append("(no network found yet - flight Pis will not hear this)")
    return ", ".join(names)


# ============================================================
# HOST
# ============================================================

class CameraHost:

    def __init__(self, args):
        self.args = args
        self.ids = args.ids
        self.session = uuid.uuid4().hex[:8]
        self.running = True

        # ---- homography -------------------------------------------------
        h_file = Path(args.homography)
        if h_file.exists():
            self.H = np.load(h_file).astype(float)
            self.h_source = str(h_file)
        elif args.simulate:
            self.H = default_sim_homography()
            self.h_source = "built-in simulation homography"
        else:
            raise SystemExit(
                f"[ERROR] Homography file not found:\n  {h_file}\n"
                "Run practical02/arena_calibration_v4_final.py on this Pi first, "
                "or pass --homography PATH.")
        if self.H.shape != (3, 3) or not np.all(np.isfinite(self.H)):
            raise SystemExit("[ERROR] Homography file is not a valid 3x3 matrix.")
        self.h_hash = hashlib.sha256(np.ascontiguousarray(self.H).tobytes()
                                     ).hexdigest()[:12]

        # ---- camera -----------------------------------------------------
        if args.simulate:
            self.camera = SimCamera(self.H, self.ids)
        else:
            try:
                self.camera = RealCamera(args.camera)
            except RuntimeError as exc:
                raise SystemExit(f"[ERROR] {exc}")

        # ---- tracking ---------------------------------------------------
        self.tracker = MarkerTracker(self.ids)
        self.frame_lock = threading.Lock()
        self.latest_gray = None
        self.latest_seq = 0
        self.latest_frame = None
        self.latest_markers = {}
        self.latest_packet = {}
        self.others = {}             # reference / unknown markers (display only)
        self.seq = 0
        self.fps = 0.0

        # ---- network ----------------------------------------------------
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        self.targets = discover_targets(args.target)
        self.send_errors = 0

        # ---- video stream -----------------------------------------------
        self.stream_cond = threading.Condition()
        self.jpeg = None
        self.jpeg_seq = 0
        self.stream_clients = 0

    # ------------------------------------------------------------------
    def info(self):
        return {
            "frame_w": FRAME_W, "frame_h": FRAME_H,
            "warp_w": WARP_W, "warp_h": WARP_H,
            "arena_w": ARENA_WIDTH_M, "arena_h": ARENA_HEIGHT_M,
            "ids": self.ids,
            "H": [float(v) for v in self.H.flatten()],
            "h_hash": self.h_hash,
            "http_port": self.args.http_port,
        }

    # ------------------------------------------------------------------
    def keep_running(self, loop):
        """Run one of the loops below; if it ever fails, say so and restart it,
        so one bad frame cannot silently stop the pose packets."""
        while self.running:
            try:
                loop()
            except Exception as exc:
                print(f"[ERROR] {loop.__name__}: {exc!r} - restarting it", flush=True)
                time.sleep(0.5)

    # ------------------------------------------------------------------
    def capture_loop(self):
        frame_counter = 0
        fps_timer = time.perf_counter()
        last_info = 0.0
        failures = 0

        while self.running:
            ok, frame = self.camera.read()
            if not ok:
                failures += 1
                if failures == 30:
                    print("[WARN] Camera stopped giving frames. Reconnecting...")
                if failures >= 30:
                    time.sleep(1.0)
                    try:
                        self.camera.reopen()
                        failures = 0
                        print("[OK] Camera reconnected.")
                    except RuntimeError:
                        pass
                continue
            failures = 0

            t_read = time.perf_counter()
            self.seq += 1
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

            found = self.tracker.update(gray)

            markers = {}
            for marker_id, pts in found.items():
                u, v, x, y, angle = marker_pose(self.H, pts)
                markers[str(marker_id)] = {
                    "x": round(x, 6), "y": round(y, 6), "a": round(angle, 3),
                    "u": round(u, 2), "v": round(v, 2),
                    "p": [[round(float(px), 2), round(float(py), 2)]
                          for px, py in pts],
                    "s": "ROI",
                }

            frame_counter += 1
            now = time.perf_counter()
            if now - fps_timer >= 1.0:
                self.fps = frame_counter / (now - fps_timer)
                frame_counter = 0
                fps_timer = now

            packet = {
                "proto": PROTOCOL,
                "sid": self.session,
                "seq": self.seq,
                "fps": round(self.fps, 2),
                "sim": bool(self.camera.simulated),
                "m": markers,
            }
            if now - last_info >= 0.5:
                packet["info"] = self.info()
                last_info = now
            # Seconds this frame is already old when it leaves this Pi.
            packet["age"] = round(time.perf_counter() - t_read, 5)
            data = json.dumps(packet, separators=(",", ":")).encode()
            for target in self.targets:
                try:
                    self.sock.sendto(data, (target, self.args.port))
                except OSError:
                    self.send_errors += 1

            with self.frame_lock:
                self.latest_gray = gray
                self.latest_seq = self.seq
                self.latest_frame = frame
                self.latest_markers = markers
                self.latest_packet = packet

    # ------------------------------------------------------------------
    def scout_loop(self):
        """Full-frame search for drones that are not being tracked yet."""
        detector = make_detector()
        last_seq = -1
        while self.running:
            wanted = self.tracker.untracked()
            with self.frame_lock:
                gray, seq = self.latest_gray, self.latest_seq
            if gray is None or seq == last_seq or not wanted:
                time.sleep(0.01)
                continue
            last_seq = seq
            corners, ids, _ = detector.detectMarkers(gray)
            others = {}
            if ids is not None:
                for c, i in zip(corners, ids.flatten()):
                    i = int(i)
                    pts = c[0]
                    if i in wanted:
                        self.tracker.seed(i, float(np.mean(pts[:, 0])),
                                          float(np.mean(pts[:, 1])))
                    elif i not in self.ids:
                        others[i] = pts.astype(np.float32)
            self.others = others
            if len(wanted) < len(self.ids):
                time.sleep(SCOUT_PAUSE_S)

    # ------------------------------------------------------------------
    def targets_loop(self):
        """Networks come and go (cables, Wi-Fi) - re-check every few seconds."""
        while self.running:
            time.sleep(3.0)
            targets = discover_targets(self.args.target)
            if targets != self.targets:
                print("[NET] Now sending poses to:", describe_targets(targets))
                self.targets = targets

    # ------------------------------------------------------------------
    def annotated_frame(self):
        with self.frame_lock:
            frame = self.latest_frame
            markers = dict(self.latest_markers)
        if frame is None:
            return None
        img = frame.copy()
        for mid, pts in list(self.others.items()):
            cv2.polylines(img, [pts.astype(np.int32)], True, (200, 200, 200), 1)
            cv2.putText(img, f"REF {mid}", (int(pts[0][0]) + 6, int(pts[0][1]) - 6),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.45, (200, 200, 200), 1,
                        cv2.LINE_AA)
        for mid, m in markers.items():
            pts = np.array(m["p"], np.int32)
            cv2.polylines(img, [pts], True, (0, 255, 0), 2)
            cv2.circle(img, (int(m["u"]), int(m["v"])), 3, (0, 255, 0), -1)
            label = f"ID {mid}  {m['x']:.2f}, {m['y']:.2f} m"
            (tw, th), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 1)
            top = int(pts[:, 1].min()) - 10
            ox = max(2, min(FRAME_W - tw - 6, int(m["u"]) - tw // 2))
            oy = max(th + 6, top)
            cv2.rectangle(img, (ox - 4, oy - th - 5), (ox + tw + 4, oy + 5),
                          (25, 25, 25), -1)
            cv2.putText(img, label, (ox, oy), cv2.FONT_HERSHEY_SIMPLEX, 0.5,
                        (0, 255, 0), 1, cv2.LINE_AA)
        if self.camera.simulated:
            cv2.putText(img, "SIMULATED CAMERA", (FRAME_W - 290, 32),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 200, 255), 2,
                        cv2.LINE_AA)
        return img

    def encode(self):
        img = self.annotated_frame()
        if img is None:
            return None
        ok, buf = cv2.imencode(".jpg", img,
                               [cv2.IMWRITE_JPEG_QUALITY, self.args.stream_quality])
        return buf.tobytes() if ok else None

    def stream_loop(self):
        period = 1.0 / max(1.0, self.args.stream_fps)
        while self.running:
            t0 = time.perf_counter()
            if self.stream_clients > 0:
                data = self.encode()
                if data is not None:
                    with self.stream_cond:
                        self.jpeg = data
                        self.jpeg_seq += 1
                        self.stream_cond.notify_all()
            time.sleep(max(0.005, period - (time.perf_counter() - t0)))

    # ------------------------------------------------------------------
    def status(self):
        with self.frame_lock:
            packet = dict(self.latest_packet)
        packet.pop("info", None)
        packet["targets"] = self.targets
        packet["tracking"] = [i for i in self.ids
                              if self.tracker.track[i]["tracking"]]
        packet["stream_clients"] = self.stream_clients
        return packet


# ============================================================
# HTTP  (video for people and for the flight displays)
# ============================================================

PAGE = b"""<!doctype html><html><head><meta charset="utf-8">
<title>Tello Arena - Overhead Camera</title>
<style>body{margin:0;background:#111;color:#eee;font-family:sans-serif}
h2{margin:12px 16px 4px}p{margin:0 16px 10px;color:#9a9;font-family:monospace}
img{display:block;max-width:100%;height:auto}</style></head><body>
<h2>Tello Arena - Overhead Camera</h2><p id="s">connecting...</p>
<img src="/stream" alt="overhead camera">
<script>
async function tick(){try{const r=await fetch('/status');const j=await r.json();
const m=Object.keys(j.m||{}).map(k=>'ID'+k+' ('+j.m[k].x.toFixed(2)+', '+j.m[k].y.toFixed(2)+')');
document.getElementById('s').textContent=(j.sim?'SIMULATED | ':'')+(j.fps||0).toFixed(1)+
' fps | frame '+j.seq+' | '+(m.length?m.join('   '):'no drone markers in view');}
catch(e){document.getElementById('s').textContent='camera host not reachable';}}
setInterval(tick,500);tick();
</script></body></html>"""


def make_handler(host):

    class Handler(BaseHTTPRequestHandler):

        def log_message(self, *a):
            pass

        def _send(self, body, ctype):
            self.send_response(200)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self):
            path = self.path.split("?")[0]
            if path == "/":
                return self._send(PAGE, "text/html")
            if path == "/status":
                return self._send(json.dumps(host.status()).encode(),
                                  "application/json")
            if path == "/snapshot.jpg":
                data = host.encode()
                if data is None:
                    return self.send_error(503, "no frame yet")
                return self._send(data, "image/jpeg")
            if path != "/stream":
                return self.send_error(404)

            self.send_response(200)
            self.send_header("Content-Type",
                             "multipart/x-mixed-replace; boundary=frame")
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            host.stream_clients += 1
            last = -1
            try:
                while host.running:
                    with host.stream_cond:
                        host.stream_cond.wait_for(
                            lambda: host.jpeg_seq != last, timeout=2.0)
                        data, seq = host.jpeg, host.jpeg_seq
                    if data is None or seq == last:
                        continue
                    last = seq
                    self.wfile.write(b"--frame\r\nContent-Type: image/jpeg\r\n"
                                     b"Content-Length: " + str(len(data)).encode()
                                     + b"\r\n\r\n" + data + b"\r\n")
            except (BrokenPipeError, ConnectionResetError, OSError):
                pass
            finally:
                host.stream_clients -= 1

    return Handler


# ============================================================
# MAIN
# ============================================================

def parse_args(argv=None):
    ap = argparse.ArgumentParser(
        description="Overhead-camera host: tracks drone markers and shares "
                    "their arena positions with every flight Pi.")
    ap.add_argument("--camera", type=int, default=CAMERA_ID,
                    help="camera index (default 0)")
    ap.add_argument("--ids", default=",".join(map(str, DRONE_IDS)),
                    help="drone marker IDs to track (default 1,2,3,4)")
    ap.add_argument("--homography", default=str(DEFAULT_H_FILE),
                    help="arena homography file (default ../practical02/arena_homography.npy)")
    ap.add_argument("--port", type=int, default=POSE_PORT,
                    help="UDP port for pose packets (default 9870)")
    ap.add_argument("--http-port", type=int, default=HTTP_PORT,
                    help="HTTP port for the video page (default 8080)")
    ap.add_argument("--target", action="append", default=[],
                    help="extra IP to send poses to (repeatable); normally not needed")
    ap.add_argument("--stream-fps", type=float, default=STREAM_FPS)
    ap.add_argument("--stream-quality", type=int, default=STREAM_JPEG_QUALITY)
    ap.add_argument("--simulate", action="store_true",
                    help="no camera: generate a synthetic arena with moving markers")
    ap.add_argument("--show", action="store_true",
                    help="open a preview window on this Pi (Q closes the host)")
    args = ap.parse_args(argv)
    try:
        args.ids = [int(v) for v in str(args.ids).split(",") if v.strip() != ""]
    except ValueError:
        ap.error("--ids must look like 1,2,3,4")
    if not args.ids:
        ap.error("--ids needs at least one marker ID")
    return args


def main(argv=None):
    args = parse_args(argv)
    host = CameraHost(args)

    try:
        server = ThreadingHTTPServer(("0.0.0.0", args.http_port), make_handler(host))
    except OSError as exc:
        raise SystemExit(
            f"[ERROR] Cannot open HTTP port {args.http_port}: {exc}\n"
            "Is camera_monitor.py or another camera_host.py still running?")
    server.daemon_threads = True

    print("=" * 64)
    print(" CAMERA HOST" + ("   ***  SIMULATED CAMERA  ***" if args.simulate else ""))
    print("=" * 64)
    print(f"Homography   : {host.h_source}")
    print(f"Homography id: {host.h_hash}")
    print(f"Drone markers: {', '.join(map(str, host.ids))}")
    print(f"Pose packets : UDP port {args.port}  ->  {describe_targets(host.targets)}")
    print(f"Video page   : http://<this-pi-address>:{args.http_port}/")
    print("Stop         : Ctrl+C")
    print()

    threads = [
        threading.Thread(target=host.keep_running, args=(host.capture_loop,), daemon=True),
        threading.Thread(target=host.keep_running, args=(host.scout_loop,), daemon=True),
        threading.Thread(target=host.keep_running, args=(host.stream_loop,), daemon=True),
        threading.Thread(target=host.keep_running, args=(host.targets_loop,), daemon=True),
        threading.Thread(target=server.serve_forever, daemon=True),
    ]
    for t in threads:
        t.start()

    try:
        last_print = 0.0
        while True:
            if args.show:
                img = host.annotated_frame()
                if img is not None:
                    cv2.imshow("Camera host - overhead view", img)
                if cv2.waitKey(30) & 0xFF in (ord("q"), ord("Q"), 27):
                    break
            else:
                time.sleep(0.2)
            now = time.perf_counter()
            if now - last_print >= 5.0:
                last_print = now
                s = host.status()
                seen = ", ".join(f"ID{k} ({m['x']:.2f}, {m['y']:.2f})"
                                 for k, m in sorted(s.get("m", {}).items()))
                print(f"[{time.strftime('%H:%M:%S')}] {s.get('fps', 0):5.1f} fps | "
                      f"{seen or 'no drone markers in view'} | "
                      f"viewers {s['stream_clients']}")
    except KeyboardInterrupt:
        pass
    finally:
        host.running = False
        time.sleep(0.2)
        server.shutdown()
        host.camera.release()
        if args.show:
            cv2.destroyAllWindows()
        print("\nCamera host stopped.")


if __name__ == "__main__":
    main()
