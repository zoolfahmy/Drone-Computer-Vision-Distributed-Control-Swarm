# Task 7: XY drift range from a vision + Z-hold log
import csv

f = "logs/p04a4_vision_zhold_20260929_111703.csv"

rows = [r for r in csv.DictReader(open(f))
        if r["aruco_detected"] == "1" and r["raw_x_m"]]

x = [float(r["raw_x_m"]) * 100 for r in rows]
y = [float(r["raw_y_m"]) * 100 for r in rows]

print("flight time (s):", rows[-1]["flight_time_s"])
print("X range (cm)   :", round(max(x) - min(x), 1))
print("Y range (cm)   :", round(max(y) - min(y), 1))
