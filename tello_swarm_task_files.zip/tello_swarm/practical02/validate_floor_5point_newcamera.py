import cv2
import numpy as np
import csv
import time
from pathlib import Path
from datetime import datetime


# ============================================================
# FLOOR 5-POINT VALIDATION - NEW CAMERA POSITION
#
# Camera : EMEET C980
# Mode   : 1280x720 MJPG
# H      : arena_homography.npy
#
# Physical test points:
# P1 = (0.5000, 0.5000)
# P2 = (1.6300, 0.5000)
# P3 = (1.6300, 1.6300)
# P4 = (0.5000, 1.6300)
# P5 = (1.0668, 1.0668)
#
# SPACE = capture 20 samples
# N     = skip current point
# Q     = quit
# ============================================================


# ============================================================
# PATHS
# ============================================================

BASE_DIR = Path(__file__).resolve().parent

H_FILE = BASE_DIR / "arena_homography.npy"

LOG_DIR = BASE_DIR / "logs"
LOG_DIR.mkdir(parents=True, exist_ok=True)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

CSV_FILE = (
    LOG_DIR
    / f"floor_5point_newcamera_{timestamp}.csv"
)


# ============================================================
# CAMERA
# ============================================================

CAMERA_ID = 0

FRAME_W = 1280
FRAME_H = 720

DETECT_SCALE = 2.0


# ============================================================
# ARENA
# ============================================================

ARENA_WIDTH_M = 2.1336
ARENA_HEIGHT_M = 2.1336

WARP_W = 800
WARP_H = 800


# ============================================================
# MARKER
# ============================================================

MARKER_ID = 1

SAMPLES_PER_POINT = 20

SAMPLE_INTERVAL = 0.10


# ============================================================
# TEST POINTS
# ============================================================

TEST_POINTS = [

    ("P1", 0.5000, 0.5000),

    ("P2", 1.6300, 0.5000),

    ("P3", 1.6300, 1.6300),

    ("P4", 0.5000, 1.6300),

    ("P5", 1.0668, 1.0668),

]


# ============================================================
# LOAD HOMOGRAPHY
# ============================================================

if not H_FILE.exists():

    print()
    print("[ERROR] Homography not found:")
    print(H_FILE)

    raise SystemExit


H = np.load(H_FILE)

print()
print("Homography loaded:")
print(H_FILE)


# ============================================================
# ARUCO
# ============================================================

dictionary = cv2.aruco.getPredefinedDictionary(
    cv2.aruco.DICT_4X4_50
)

parameters = cv2.aruco.DetectorParameters()

parameters.cornerRefinementMethod = (
    cv2.aruco.CORNER_REFINE_SUBPIX
)

parameters.adaptiveThreshWinSizeMin = 3
parameters.adaptiveThreshWinSizeMax = 53
parameters.adaptiveThreshWinSizeStep = 2

parameters.minMarkerPerimeterRate = 0.005
parameters.maxMarkerPerimeterRate = 4.0

parameters.polygonalApproxAccuracyRate = 0.05

parameters.minCornerDistanceRate = 0.01
parameters.minMarkerDistanceRate = 0.01

parameters.minDistanceToBorder = 2

parameters.cornerRefinementWinSize = 5
parameters.cornerRefinementMaxIterations = 50
parameters.cornerRefinementMinAccuracy = 0.01

detector = cv2.aruco.ArucoDetector(
    dictionary,
    parameters
)


# ============================================================
# DETECTION
# ============================================================

def detect_marker(frame):

    enlarged = cv2.resize(
        frame,
        None,
        fx=DETECT_SCALE,
        fy=DETECT_SCALE,
        interpolation=cv2.INTER_LINEAR
    )

    gray = cv2.cvtColor(
        enlarged,
        cv2.COLOR_BGR2GRAY
    )

    corners, ids, _ = detector.detectMarkers(
        gray
    )

    if ids is None:

        return False, None, None, None, None


    for i, marker_id in enumerate(
        ids.flatten()
    ):

        if int(marker_id) != MARKER_ID:

            continue


        pts = (
            corners[i][0].astype(np.float32)
            /
            DETECT_SCALE
        )


        cx = float(
            np.mean(pts[:, 0])
        )

        cy = float(
            np.mean(pts[:, 1])
        )


        return (
            True,
            pts,
            cx,
            cy,
            int(marker_id)
        )


    return False, None, None, None, None


# ============================================================
# HOMOGRAPHY
# ============================================================

def pixel_to_xy(cx, cy):

    src = np.array(
        [[[cx, cy]]],
        dtype=np.float32
    )


    dst = cv2.perspectiveTransform(
        src,
        H
    )


    warp_x = float(
        dst[0][0][0]
    )

    warp_y = float(
        dst[0][0][1]
    )


    x_m = (
        warp_x
        /
        (WARP_W - 1)
        *
        ARENA_WIDTH_M
    )


    y_m = (
        warp_y
        /
        (WARP_H - 1)
        *
        ARENA_HEIGHT_M
    )


    return x_m, y_m


# ============================================================
# CAMERA
# ============================================================

cap = cv2.VideoCapture(
    CAMERA_ID,
    cv2.CAP_V4L2
)


if not cap.isOpened():

    print("[ERROR] Cannot open camera.")

    raise SystemExit


cap.set(
    cv2.CAP_PROP_FOURCC,
    cv2.VideoWriter_fourcc(*"MJPG")
)

cap.set(
    cv2.CAP_PROP_FRAME_WIDTH,
    FRAME_W
)

cap.set(
    cv2.CAP_PROP_FRAME_HEIGHT,
    FRAME_H
)

cap.set(
    cv2.CAP_PROP_FPS,
    30
)

# Same setting as calibration
cap.set(
    cv2.CAP_PROP_AUTOFOCUS,
    0
)


time.sleep(2)


print()
print("=" * 70)
print(" FLOOR 5-POINT VALIDATION - NEW CAMERA")
print("=" * 70)

print(
    f"Camera: "
    f"{int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))}"
    f"x"
    f"{int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))}"
)

print()

print(
    f"Samples per point: "
    f"{SAMPLES_PER_POINT}"
)

print()


# ============================================================
# CSV
# ============================================================

csv_handle = open(
    CSV_FILE,
    "w",
    newline=""
)

writer = csv.writer(
    csv_handle
)


writer.writerow([

    "timestamp",

    "point",

    "sample",

    "pixel_u",

    "pixel_v",

    "true_x_m",

    "true_y_m",

    "measured_x_m",

    "measured_y_m",

    "error_x_m",

    "error_y_m",

    "error_2d_m"

])


csv_handle.flush()


# ============================================================
# RESULTS
# ============================================================

summary = []


# ============================================================
# MAIN TEST
# ============================================================

try:

    for point_name, true_x, true_y in TEST_POINTS:

        captured = False


        while not captured:

            ret, frame = cap.read()


            if not ret:

                continue


            (
                detected,
                pts,
                cx,
                cy,
                marker_id

            ) = detect_marker(
                frame
            )


            display = frame.copy()


            cv2.putText(
                display,
                "FLOOR 5-POINT VALIDATION",
                (10, 30),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.70,
                (0, 255, 255),
                2
            )


            cv2.putText(
                display,
                (
                    f"{point_name}: "
                    f"TRUE X={true_x:.4f} "
                    f"Y={true_y:.4f}"
                ),
                (10, 65),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.65,
                (255, 255, 255),
                2
            )


            if detected:

                measured_x, measured_y = (
                    pixel_to_xy(
                        cx,
                        cy
                    )
                )


                error_x = (
                    measured_x
                    -
                    true_x
                )

                error_y = (
                    measured_y
                    -
                    true_y
                )


                error_2d = np.sqrt(
                    error_x ** 2
                    +
                    error_y ** 2
                )


                cv2.polylines(
                    display,
                    [
                        pts.astype(
                            np.int32
                        )
                    ],
                    True,
                    (0, 255, 0),
                    3
                )


                cv2.circle(
                    display,
                    (
                        int(cx),
                        int(cy)
                    ),
                    5,
                    (0, 0, 255),
                    -1
                )


                cv2.putText(
                    display,
                    (
                        f"ID1 X={measured_x:.4f} "
                        f"Y={measured_y:.4f}"
                    ),
                    (10, 105),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.65,
                    (0, 255, 0),
                    2
                )


                cv2.putText(
                    display,
                    (
                        f"Error = "
                        f"{error_2d * 100:.2f} cm"
                    ),
                    (10, 145),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.65,
                    (0, 255, 255),
                    2
                )


                cv2.putText(
                    display,
                    (
                        f"Pixel u={cx:.1f} "
                        f"v={cy:.1f}"
                    ),
                    (10, 185),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.60,
                    (255, 255, 255),
                    2
                )

            else:

                cv2.putText(
                    display,
                    "ID1 NOT DETECTED",
                    (10, 105),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.70,
                    (0, 0, 255),
                    2
                )


            cv2.putText(
                display,
                "SPACE=CAPTURE   N=SKIP   Q=QUIT",
                (10, FRAME_H - 25),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.60,
                (255, 255, 255),
                2
            )


            cv2.imshow(
                "Floor Validation",
                display
            )


            key = (
                cv2.waitKey(1)
                &
                0xFF
            )


            # =================================================
            # CAPTURE
            # =================================================

            if key == 32:

                if not detected:

                    print(
                        "[BLOCKED] ID1 not detected."
                    )

                    continue


                print()
                print("=" * 60)

                print(
                    f"{point_name} "
                    f"TRUE=({true_x:.4f}, "
                    f"{true_y:.4f})"
                )

                print(
                    f"Collecting "
                    f"{SAMPLES_PER_POINT} samples..."
                )

                print("=" * 60)


                xs = []
                ys = []

                errors = []


                for sample in range(
                    1,
                    SAMPLES_PER_POINT + 1
                ):

                    while True:

                        ret2, frame2 = (
                            cap.read()
                        )


                        if not ret2:

                            continue


                        (
                            detected2,
                            pts2,
                            cx2,
                            cy2,
                            _

                        ) = detect_marker(
                            frame2
                        )


                        if detected2:

                            break


                    mx, my = pixel_to_xy(
                        cx2,
                        cy2
                    )


                    ex = (
                        mx
                        -
                        true_x
                    )

                    ey = (
                        my
                        -
                        true_y
                    )


                    e2d = np.sqrt(
                        ex ** 2
                        +
                        ey ** 2
                    )


                    xs.append(mx)
                    ys.append(my)

                    errors.append(e2d)


                    writer.writerow([

                        datetime.now().isoformat(),

                        point_name,

                        sample,

                        f"{cx2:.3f}",

                        f"{cy2:.3f}",

                        f"{true_x:.6f}",

                        f"{true_y:.6f}",

                        f"{mx:.6f}",

                        f"{my:.6f}",

                        f"{ex:.6f}",

                        f"{ey:.6f}",

                        f"{e2d:.6f}"
                    ])


                    csv_handle.flush()


                    time.sleep(
                        SAMPLE_INTERVAL
                    )


                # =================================================
                # POINT SUMMARY
                # =================================================

                mean_x = float(
                    np.mean(xs)
                )

                mean_y = float(
                    np.mean(ys)
                )


                mean_ex = (
                    mean_x
                    -
                    true_x
                )

                mean_ey = (
                    mean_y
                    -
                    true_y
                )


                mean_error = float(
                    np.mean(errors)
                )


                max_error = float(
                    np.max(errors)
                )


                std_x = float(
                    np.std(xs)
                )

                std_y = float(
                    np.std(ys)
                )


                summary.append({

                    "point": point_name,

                    "true_x": true_x,

                    "true_y": true_y,

                    "mean_x": mean_x,

                    "mean_y": mean_y,

                    "error_x": mean_ex,

                    "error_y": mean_ey,

                    "mean_error": mean_error,

                    "max_error": max_error,

                    "std_x": std_x,

                    "std_y": std_y
                })


                print()
                print(
                    f"Mean X      : "
                    f"{mean_x:.4f} m"
                )

                print(
                    f"Mean Y      : "
                    f"{mean_y:.4f} m"
                )

                print(
                    f"Error X     : "
                    f"{mean_ex * 100:+.2f} cm"
                )

                print(
                    f"Error Y     : "
                    f"{mean_ey * 100:+.2f} cm"
                )

                print(
                    f"Mean 2D Err : "
                    f"{mean_error * 100:.2f} cm"
                )

                print(
                    f"Max 2D Err  : "
                    f"{max_error * 100:.2f} cm"
                )

                print(
                    f"Std X/Y     : "
                    f"{std_x * 100:.3f} / "
                    f"{std_y * 100:.3f} cm"
                )

                print()


                captured = True


            elif key == ord("n"):

                print(
                    f"[SKIP] {point_name}"
                )

                captured = True


            elif key == ord("q"):

                raise KeyboardInterrupt


    # ========================================================
    # FINAL SUMMARY
    # ========================================================

    print()
    print("=" * 78)
    print(" FINAL FLOOR VALIDATION SUMMARY")
    print("=" * 78)

    print(
        f"{'Point':<8}"
        f"{'Mean X':>10}"
        f"{'Mean Y':>10}"
        f"{'Err X cm':>12}"
        f"{'Err Y cm':>12}"
        f"{'2D cm':>10}"
    )

    print("-" * 78)


    for r in summary:

        print(
            f"{r['point']:<8}"
            f"{r['mean_x']:>10.4f}"
            f"{r['mean_y']:>10.4f}"
            f"{r['error_x'] * 100:>12.2f}"
            f"{r['error_y'] * 100:>12.2f}"
            f"{r['mean_error'] * 100:>10.2f}"
        )


    if len(summary) > 0:

        overall_mean = float(
            np.mean(
                [
                    r["mean_error"]
                    for r in summary
                ]
            )
        )


        overall_max = float(
            np.max(
                [
                    r["max_error"]
                    for r in summary
                ]
            )
        )


        print("-" * 78)

        print(
            f"Overall mean 2D error : "
            f"{overall_mean * 100:.2f} cm"
        )

        print(
            f"Overall max error     : "
            f"{overall_max * 100:.2f} cm"
        )


    print()
    print("CSV:")
    print(CSV_FILE)


except KeyboardInterrupt:

    print()
    print("[STOP] Validation stopped.")


finally:

    csv_handle.close()

    cap.release()

    cv2.destroyAllWindows()

    print()
    print("Program finished.")
