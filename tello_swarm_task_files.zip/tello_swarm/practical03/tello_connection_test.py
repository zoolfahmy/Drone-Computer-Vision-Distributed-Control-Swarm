from djitellopy import Tello
import time

print("=" * 50)
print(" PRACTICAL 03 - TELLO EDU CONNECTION TEST")
print("=" * 50)

tello = Tello()

try:
    print("\n[1] Connecting to Tello...")
    tello.connect()

    print("[OK] Tello connected")

    battery = tello.get_battery()
    print(f"[2] Battery    : {battery}%")

    temperature = tello.get_temperature()
    print(f"[3] Temperature: {temperature} C")

    height = tello.get_height()
    print(f"[4] Height     : {height} cm")

    tof = tello.get_distance_tof()
    print(f"[5] ToF        : {tof} cm")

    print("\nTELLO STATUS: READY")

except Exception as e:
    print("\n[ERROR]")
    print(e)

finally:
    print("\nTest completed.")
