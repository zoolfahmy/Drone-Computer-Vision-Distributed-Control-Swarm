import cv2
import numpy as np
import csv
import time
from pathlib import Path
from datetime import datetime


# ============================================================
# P04-B - VERTICAL PROJECTION TEST
# ============================================================
#
# PURPOSE:
# Measure apparent X/Y position error caused ONLY by changing
# marker altitude while the marker centre remains vertically
# above physical P5.
#
# NO FLIGHT
# NO TELLO CONNECTION
#
# P5 physical coordinate:
# X = 1.0668 m
# Y = 1.0668 m
#
# Test heights:
# 0, 20, 40, 50, 60, 70 cm
#
# 20 samples per height
#
# IMPORTANT:
# The marker must NOT be moved horizontally to make the
# displayed X/Y match P5.
#
# SPACE = capture current height
# N     = skip current height
# Q     = quit
# ============================================================


# ============================================================
# PATHS
# ============================================================

BASE_DIR = Path(__file__).resolve().parent

H_FILE = (
    BASE_DIR.parent
    / "practical02"
    / "arena_homography.npy"
)

LOG_DIR = BASE_DIR / "logs"
LOG_DIR.mkdir(parents=True, exist_ok=True)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

CSV_FILE = (
    LOG_DIR
    / f"vertical_projection_{timestamp}.csv"
)


# ============================================================
# CAMERA
# ============================================================

CAMERA_ID = 0

FRAME_W = 1280
FRAME_H = 720

CAMERA_FPS = 30

DETECT_SCALE = 2.0


# ============================================================
# ARENA
# ============================================================

ARENA_WIDTH_M = 2.1336
ARENA_HEIGHT_M = 2.1336

WARP_W = 800
WARP_H = 800


# ============================================================
# P5
# ============================================================

TRUE_X = 1.0668
TRUE_Y = 1.0668

MARKER_ID = 1


# ============================================================
# HEIGHT TEST
# ============================================================

HEIGHTS_CM = [
    0,
    20,
    40,
    50,
    60,
    70
]

SAMPLES_PER_HEIGHT = 20

SAMPLE_INTERVAL = 0.10


# ============================================================
# LOAD HOMOGRAPHY
# ============================================================

if not H_FILE.exists():

    print()
    print("[ERROR] Homography file not found:")
    print(H_FILE)

    raise SystemExit


H = np.load(H_FILE)


print()
print("Homography loaded:")
print(H_FILE)


# ============================================================
# ARUCO
# ============================================================

dictionary = cv2.aruco.getPredefinedDictionary(
    cv2.aruco.DICT_4X4_50
)

parameters = cv2.aruco.DetectorParameters()

parameters.cornerRefinementMethod = (
    cv2.aruco.CORNER_REFINE_SUBPIX
)

parameters.adaptiveThreshWinSizeMin = 3
parameters.adaptiveThreshWinSizeMax = 53
parameters.adaptiveThreshWinSizeStep = 2

parameters.minMarkerPerimeterRate = 0.005
parameters.maxMarkerPerimeterRate = 4.0

parameters.polygonalApproxAccuracyRate = 0.05

parameters.minCornerDistanceRate = 0.01
parameters.minMarkerDistanceRate = 0.01

parameters.minDistanceToBorder = 2

parameters.cornerRefinementWinSize = 5
parameters.cornerRefinementMaxIterations = 50
parameters.cornerRefinementMinAccuracy = 0.01

detector = cv2.aruco.ArucoDetector(
    dictionary,
    parameters
)


# ============================================================
# DETECT ID1
# ============================================================

def detect_id1(frame):

    enlarged = cv2.resize(
        frame,
        None,
        fx=DETECT_SCALE,
        fy=DETECT_SCALE,
        interpolation=cv2.INTER_LINEAR
    )

    gray = cv2.cvtColor(
        enlarged,
        cv2.COLOR_BGR2GRAY
    )

    corners, ids, _ = detector.detectMarkers(
        gray
    )

    if ids is None:

        return False, None, None, None


    for i, marker_id in enumerate(
        ids.flatten()
    ):

        if int(marker_id) != MARKER_ID:
            continue


        pts = (
            corners[i][0].astype(np.float32)
            /
            DETECT_SCALE
        )


        pixel_u = float(
            np.mean(pts[:, 0])
        )

        pixel_v = float(
            np.mean(pts[:, 1])
        )


        return (
            True,
            pts,
            pixel_u,
            pixel_v
        )


    return False, None, None, None


# ============================================================
# PIXEL -> FLOOR HOMOGRAPHY XY
# ============================================================

def pixel_to_xy(pixel_u, pixel_v):

    src = np.array(
        [[[pixel_u, pixel_v]]],
        dtype=np.float32
    )


    dst = cv2.perspectiveTransform(
        src,
        H
    )


    warp_x = float(
        dst[0][0][0]
    )

    warp_y = float(
        dst[0][0][1]
    )


    x_m = (
        warp_x
        /
        (WARP_W - 1)
        *
        ARENA_WIDTH_M
    )


    y_m = (
        warp_y
        /
        (WARP_H - 1)
        *
        ARENA_HEIGHT_M
    )


    return x_m, y_m


# ============================================================
# CAMERA
# ============================================================

cap = cv2.VideoCapture(
    CAMERA_ID,
    cv2.CAP_V4L2
)


if not cap.isOpened():

    print()
    print("[ERROR] Cannot open camera.")

    raise SystemExit


cap.set(
    cv2.CAP_PROP_FOURCC,
    cv2.VideoWriter_fourcc(*"MJPG")
)

cap.set(
    cv2.CAP_PROP_FRAME_WIDTH,
    FRAME_W
)

cap.set(
    cv2.CAP_PROP_FRAME_HEIGHT,
    FRAME_H
)

cap.set(
    cv2.CAP_PROP_FPS,
    CAMERA_FPS
)

# Must match calibration condition
cap.set(
    cv2.CAP_PROP_AUTOFOCUS,
    0
)


time.sleep(2)


# ============================================================
# CSV
# ============================================================

csv_handle = open(
    CSV_FILE,
    "w",
    newline=""
)

writer = csv.writer(
    csv_handle
)


writer.writerow([

    "timestamp",

    "physical_z_cm",

    "sample",

    "pixel_u",

    "pixel_v",

    "true_x_m",

    "true_y_m",

    "raw_x_m",

    "raw_y_m",

    "error_x_m",

    "error_y_m",

    "error_2d_m"
])


csv_handle.flush()


# ============================================================
# INTRO
# ============================================================

print()
print("=" * 72)
print(" P04-B - VERTICAL PROJECTION TEST")
print("=" * 72)

print()
print("NO FLIGHT")
print("NO TELLO CONNECTION")
print()

print(
    f"P5 TRUE = "
    f"({TRUE_X:.4f}, {TRUE_Y:.4f}) m"
)

print(
    f"HEIGHTS = {HEIGHTS_CM} cm"
)

print(
    f"SAMPLES/HEIGHT = "
    f"{SAMPLES_PER_HEIGHT}"
)

print()

print(
    "IMPORTANT:"
)

print(
    "Keep ID1 centre vertically above physical P5."
)

print(
    "DO NOT move ID1 horizontally to correct displayed XY."
)

print()


# ============================================================
# SUMMARY STORAGE
# ============================================================

summary = []


# ============================================================
# TEST LOOP
# ============================================================

try:

    for height_cm in HEIGHTS_CM:

        captured = False


        while not captured:

            ret, frame = cap.read()

            if not ret:
                continue


            (
                detected,
                pts,
                pixel_u,
                pixel_v

            ) = detect_id1(
                frame
            )


            display = frame.copy()


            # =================================================
            # HEADER
            # =================================================

            cv2.putText(
                display,
                "P04-B VERTICAL PROJECTION TEST",
                (10, 30),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.70,
                (0, 255, 255),
                2
            )


            cv2.putText(
                display,
                (
                    f"SET PHYSICAL Z = "
                    f"{height_cm} cm"
                ),
                (10, 70),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.75,
                (255, 255, 255),
                2
            )


            cv2.putText(
                display,
                (
                    f"P5 TRUE = "
                    f"{TRUE_X:.4f}, "
                    f"{TRUE_Y:.4f}"
                ),
                (10, 110),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.60,
                (255, 255, 255),
                2
            )


            # =================================================
            # MARKER DATA
            # =================================================

            if detected:

                raw_x, raw_y = pixel_to_xy(
                    pixel_u,
                    pixel_v
                )


                error_x = raw_x - TRUE_X
                error_y = raw_y - TRUE_Y


                error_2d = np.sqrt(
                    error_x ** 2
                    +
                    error_y ** 2
                )


                cv2.polylines(
                    display,
                    [
                        pts.astype(
                            np.int32
                        )
                    ],
                    True,
                    (0, 255, 0),
                    3
                )


                cv2.circle(
                    display,
                    (
                        int(pixel_u),
                        int(pixel_v)
                    ),
                    6,
                    (0, 0, 255),
                    -1
                )


                cv2.putText(
                    display,
                    "ID1 DETECTED",
                    (10, 150),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.65,
                    (0, 255, 0),
                    2
                )


                cv2.putText(
                    display,
                    (
                        f"Pixel u={pixel_u:.1f} "
                        f"v={pixel_v:.1f}"
                    ),
                    (10, 190),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.60,
                    (255, 255, 255),
                    2
                )


                cv2.putText(
                    display,
                    (
                        f"RAW X={raw_x:.4f} "
                        f"Y={raw_y:.4f}"
                    ),
                    (10, 230),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.65,
                    (0, 255, 0),
                    2
                )


                cv2.putText(
                    display,
                    (
                        f"dX={error_x * 100:+.2f} cm "
                        f"dY={error_y * 100:+.2f} cm"
                    ),
                    (10, 270),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.65,
                    (0, 255, 255),
                    2
                )


                cv2.putText(
                    display,
                    (
                        f"2D ERROR = "
                        f"{error_2d * 100:.2f} cm"
                    ),
                    (10, 310),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.70,
                    (0, 255, 255),
                    2
                )

            else:

                cv2.putText(
                    display,
                    "ID1 NOT DETECTED",
                    (10, 150),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.70,
                    (0, 0, 255),
                    2
                )


            cv2.putText(
                display,
                "SPACE=CAPTURE   N=SKIP   Q=QUIT",
                (10, FRAME_H - 25),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.60,
                (255, 255, 255),
                2
            )


            cv2.imshow(
                "P04-B Vertical Projection",
                display
            )


            key = (
                cv2.waitKey(1)
                &
                0xFF
            )


            # =================================================
            # SPACE
            # =================================================

            if key == 32:

                if not detected:

                    print()
                    print(
                        "[BLOCKED] ID1 not detected."
                    )

                    continue


                print()
                print("=" * 65)

                print(
                    f"PHYSICAL Z = "
                    f"{height_cm} cm"
                )

                print(
                    f"Collecting "
                    f"{SAMPLES_PER_HEIGHT} samples..."
                )

                print("=" * 65)


                us = []
                vs = []

                xs = []
                ys = []

                exs = []
                eys = []

                errors = []


                sample = 0


                while sample < SAMPLES_PER_HEIGHT:

                    ret2, frame2 = cap.read()

                    if not ret2:
                        continue


                    (
                        detected2,
                        pts2,
                        u2,
                        v2

                    ) = detect_id1(
                        frame2
                    )


                    if not detected2:
                        continue


                    x2, y2 = pixel_to_xy(
                        u2,
                        v2
                    )


                    ex2 = x2 - TRUE_X
                    ey2 = y2 - TRUE_Y


                    e2d = np.sqrt(
                        ex2 ** 2
                        +
                        ey2 ** 2
                    )


                    sample += 1


                    us.append(u2)
                    vs.append(v2)

                    xs.append(x2)
                    ys.append(y2)

                    exs.append(ex2)
                    eys.append(ey2)

                    errors.append(e2d)


                    writer.writerow([

                        datetime.now().isoformat(),

                        height_cm,

                        sample,

                        f"{u2:.3f}",

                        f"{v2:.3f}",

                        f"{TRUE_X:.6f}",

                        f"{TRUE_Y:.6f}",

                        f"{x2:.6f}",

                        f"{y2:.6f}",

                        f"{ex2:.6f}",

                        f"{ey2:.6f}",

                        f"{e2d:.6f}"
                    ])


                    csv_handle.flush()


                    print(
                        f"{sample:02d}/"
                        f"{SAMPLES_PER_HEIGHT}"
                        f"  u={u2:7.2f}"
                        f"  v={v2:7.2f}"
                        f"  X={x2:.4f}"
                        f"  Y={y2:.4f}"
                        f"  Err={e2d * 100:.2f}cm"
                    )


                    time.sleep(
                        SAMPLE_INTERVAL
                    )


                # =================================================
                # HEIGHT SUMMARY
                # =================================================

                mean_u = float(np.mean(us))
                mean_v = float(np.mean(vs))

                mean_x = float(np.mean(xs))
                mean_y = float(np.mean(ys))

                mean_ex = float(np.mean(exs))
                mean_ey = float(np.mean(eys))

                mean_error = float(
                    np.mean(errors)
                )

                max_error = float(
                    np.max(errors)
                )

                std_x = float(
                    np.std(xs)
                )

                std_y = float(
                    np.std(ys)
                )


                summary.append({

                    "z": height_cm,

                    "u": mean_u,
                    "v": mean_v,

                    "x": mean_x,
                    "y": mean_y,

                    "ex": mean_ex,
                    "ey": mean_ey,

                    "error": mean_error,
                    "max_error": max_error,

                    "std_x": std_x,
                    "std_y": std_y
                })


                print()
                print("-" * 65)

                print(
                    f"Z             : "
                    f"{height_cm} cm"
                )

                print(
                    f"Mean pixel    : "
                    f"u={mean_u:.2f}, "
                    f"v={mean_v:.2f}"
                )

                print(
                    f"Mean RAW XY   : "
                    f"{mean_x:.4f}, "
                    f"{mean_y:.4f} m"
                )

                print(
                    f"Mean dX       : "
                    f"{mean_ex * 100:+.2f} cm"
                )

                print(
                    f"Mean dY       : "
                    f"{mean_ey * 100:+.2f} cm"
                )

                print(
                    f"Mean 2D error : "
                    f"{mean_error * 100:.2f} cm"
                )

                print(
                    f"Max 2D error  : "
                    f"{max_error * 100:.2f} cm"
                )

                print(
                    f"Std X/Y       : "
                    f"{std_x * 100:.3f} / "
                    f"{std_y * 100:.3f} cm"
                )

                print("-" * 65)
                print()


                captured = True


            # =================================================
            # SKIP
            # =================================================

            elif key == ord("n"):

                print(
                    f"[SKIP] Z={height_cm} cm"
                )

                captured = True


            # =================================================
            # QUIT
            # =================================================

            elif key == ord("q"):

                raise KeyboardInterrupt


    # ========================================================
    # FINAL SUMMARY
    # ========================================================

    print()
    print("=" * 88)
    print(" VERTICAL PROJECTION SUMMARY")
    print("=" * 88)

    print(
        f"{'Z cm':>6}"
        f"{'Pixel U':>11}"
        f"{'Pixel V':>11}"
        f"{'Raw X':>10}"
        f"{'Raw Y':>10}"
        f"{'dX cm':>10}"
        f"{'dY cm':>10}"
        f"{'2D cm':>10}"
    )

    print("-" * 88)


    for r in summary:

        print(
            f"{r['z']:>6.0f}"
            f"{r['u']:>11.2f}"
            f"{r['v']:>11.2f}"
            f"{r['x']:>10.4f}"
            f"{r['y']:>10.4f}"
            f"{r['ex'] * 100:>10.2f}"
            f"{r['ey'] * 100:>10.2f}"
            f"{r['error'] * 100:>10.2f}"
        )


    print()
    print("CSV:")
    print(CSV_FILE)

    print()
    print("P04-B COMPLETE")


except KeyboardInterrupt:

    print()
    print("[STOP] Test stopped.")


finally:

    csv_handle.close()

    cap.release()

    cv2.destroyAllWindows()

    print()
    print("Program finished.")
