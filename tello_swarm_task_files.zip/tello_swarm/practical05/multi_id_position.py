# Task 1: positions of three drones from the shared camera
# Objective: read ID1, ID2 and ID3 from the camera host, in metres,
#            and check the distance between every pair of drones
#
# This program does not open a camera. The camera Pi runs camera_host.py and
# sends every marker position to every Raspberry Pi on the network.
import itertools
import math
import sys
from pathlib import Path

import cv2
import numpy as np

BASE_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE_DIR.parent / "shared_vision"))
from vision_client import VisionClient

DRONE_IDS = (1, 2, 3)
D_MIN_M = 0.80          # minimum allowed distance between two drones
MAX_AGE_S = 0.50        # positions older than this are not trusted


def positions_from_host(vision):
    """Return {marker_id: (x_m, y_m)} for every drone marker the host sees."""
    if vision.link_age() > MAX_AGE_S:
        return {}

    markers = vision.markers()
    positions = {}
    for marker_id in DRONE_IDS:
        if marker_id in markers:
            positions[marker_id] = (markers[marker_id]["x"],
                                    markers[marker_id]["y"])
    return positions


def spacing_report(positions):
    """Return [(i, j, distance_m, ok)] for every pair of drones seen."""
    report = []
    for i, j in itertools.combinations(sorted(positions), 2):
        d = math.dist(positions[i], positions[j])
        report.append((i, j, d, d >= D_MIN_M))
    return report


def main():
    vision = VisionClient().start()

    print("P = Print positions   Q = Quit")
    font = cv2.FONT_HERSHEY_SIMPLEX

    while True:
        image, age = vision.get_image()
        if image is None or age > 1.0:
            frame = np.zeros((720, 1280, 3), np.uint8)
            cv2.putText(frame, "Waiting for the camera host...", (20, 700),
                        font, 0.8, (0, 200, 255), 2)
        else:
            frame = image.copy()

        positions = positions_from_host(vision)
        report = spacing_report(positions)

        row = 35
        for marker_id, (x_m, y_m) in sorted(positions.items()):
            text = f"ID{marker_id}: X {x_m:.3f}  Y {y_m:.3f} m"
            cv2.putText(frame, text, (20, row), font, 0.8, (0, 255, 0), 2)
            row += 32

        for i, j, d, ok in report:
            text = f"ID{i}-ID{j}: {d:.2f} m " + ("OK" if ok else "TOO CLOSE")
            colour = (0, 255, 0) if ok else (0, 0, 255)
            cv2.putText(frame, text, (20, row), font, 0.8, colour, 2)
            row += 32

        cv2.imshow("Practical 05 - Multi-ID positions", frame)
        key = cv2.waitKey(30) & 0xFF

        if key == ord("q"):
            break
        elif key == ord("p"):
            for marker_id, (x_m, y_m) in sorted(positions.items()):
                print(f"ID{marker_id}: X {x_m:.3f} m  Y {y_m:.3f} m")
            for i, j, d, ok in report:
                print(f"ID{i}-ID{j}: {d:.3f} m", "OK" if ok else "TOO CLOSE")
            print()

    vision.stop()
    cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
