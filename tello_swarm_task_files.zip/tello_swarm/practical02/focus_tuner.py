import cv2

CAMERA_ID = 0
focus = 100

cap = cv2.VideoCapture(CAMERA_ID, cv2.CAP_V4L2)

cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)

# Disable autofocus
cap.set(cv2.CAP_PROP_AUTOFOCUS, 0)

# ArUco
aruco = cv2.aruco
dictionary = aruco.getPredefinedDictionary(
    aruco.DICT_4X4_50
)

parameters = aruco.DetectorParameters()
detector = aruco.ArucoDetector(
    dictionary,
    parameters
)

print("")
print("============================")
print(" MANUAL FOCUS TUNER")
print("============================")
print("+ / = : Increase focus")
print("-     : Decrease focus")
print("A     : Autofocus ON")
print("M     : Manual focus")
print("Q     : Quit")
print("============================")
print("")

while True:

    # Apply focus
    cap.set(
        cv2.CAP_PROP_FOCUS,
        focus
    )

    ret, frame = cap.read()

    if not ret:
        break

    # Detect ArUco
    corners, ids, rejected = detector.detectMarkers(
        frame
    )

    detected_ids = []

    if ids is not None:

        detected_ids = ids.flatten().tolist()

        aruco.drawDetectedMarkers(
            frame,
            corners,
            ids
        )

    # Current actual focus
    actual_focus = cap.get(
        cv2.CAP_PROP_FOCUS
    )

    # Display focus
    cv2.putText(
        frame,
        f"FOCUS: {actual_focus:.0f}",
        (10, 35),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.8,
        (0, 255, 255),
        2
    )

    # Display detected IDs
    cv2.putText(
        frame,
        "DETECTED: " + str(detected_ids),
        (10, 70),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.7,
        (0, 255, 0),
        2
    )

    cv2.putText(
        frame,
        "+/- CHANGE FOCUS | A=AUTO | M=MANUAL | Q=QUIT",
        (10, 105),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.55,
        (255, 255, 0),
        2
    )

    cv2.imshow(
        "Manual Focus Tuner",
        frame
    )

    key = cv2.waitKey(1) & 0xFF

    # Increase
    if key == ord('+') or key == ord('='):

        focus += 10

        print(
            "Focus:",
            focus
        )

    # Decrease
    elif key == ord('-'):

        focus -= 10

        if focus < 0:
            focus = 0

        print(
            "Focus:",
            focus
        )

    # Autofocus
    elif key == ord('a'):

        cap.set(
            cv2.CAP_PROP_AUTOFOCUS,
            1
        )

        print(
            "AUTOFOCUS ON"
        )

    # Manual
    elif key == ord('m'):

        cap.set(
            cv2.CAP_PROP_AUTOFOCUS,
            0
        )

        focus = int(
            cap.get(
                cv2.CAP_PROP_FOCUS
            )
        )

        print(
            "MANUAL FOCUS:",
            focus
        )

    # Quit
    elif key == ord('q'):

        break


cap.release()
cv2.destroyAllWindows()
