import cv2
import csv
import time
import math
import threading
import numpy as np

from pathlib import Path
from datetime import datetime
from djitellopy import Tello


# ============================================================
# P04-B1 V2 - AUTO MAPPING ONLY
#
# PURPOSE:
#   1. Takeoff
#   2. Track ArUco ID1 using ROI
#   3. Measure actual response:
#
#        FB +6
#        FB -6
#        LR +6
#        LR -6
#
#   4. Build differential XY response matrix
#   5. Validate matrix
#   6. SAVE MATRIX
#   7. LAND
#
# IMPORTANT:
#   NO POSITION HOLD in this program.
# ============================================================


# ============================================================
# FLIGHT CONFIG
# ============================================================

MIN_BATTERY = 50

STABILIZE_TIME = 4.0

MAP_RC = 6

PULSE_TIME = 0.70

BASELINE_TIME = 1.0

SETTLE_TIME = 1.5

RC_SEND_INTERVAL = 0.10


# ============================================================
# SAFETY
# ============================================================

MAX_DISPLACEMENT_M = 0.25

VISION_STOP_TIMEOUT = 0.50

VISION_LAND_TIMEOUT = 1.50

ARENA_WIDTH_M = 2.1336
ARENA_HEIGHT_M = 2.1336

ARENA_MARGIN_M = 0.20


# ============================================================
# CAMERA
# ============================================================

CAMERA_ID = 0

FRAME_W = 1280
FRAME_H = 720
CAMERA_FPS = 30

MARKER_ID = 1


# ============================================================
# ROI
# ============================================================

ROI_SIZE = 320

ROI_LOST_LIMIT = 3


# ============================================================
# HOMOGRAPHY
# ============================================================

WARP_W = 800
WARP_H = 800


# ============================================================
# MATRIX VALIDATION
# ============================================================

MIN_RESPONSE_MPS = 0.005

MIN_DETERMINANT = 0.00005

MAX_CONDITION = 10.0

MIN_SAMPLES = 5


# ============================================================
# PATHS
# ============================================================

BASE_DIR = Path(__file__).resolve().parent

H_FILE = (
    BASE_DIR.parent
    / "practical02"
    / "arena_homography.npy"
)

LOG_DIR = BASE_DIR / "logs"

LOG_DIR.mkdir(
    parents=True,
    exist_ok=True
)

timestamp = datetime.now().strftime(
    "%Y%m%d_%H%M%S"
)

CSV_FILE = (
    LOG_DIR
    / f"p04b1_auto_mapping_v2_{timestamp}.csv"
)

MATRIX_FILE = (
    LOG_DIR
    / f"p04b1_matrix_v2_{timestamp}.npy"
)

MATRIX_TXT_FILE = (
    LOG_DIR
    / f"p04b1_matrix_v2_{timestamp}.txt"
)

CALIBRATION_LATEST_FILE = (
    LOG_DIR
    / "p04b1_calibration_latest.npz"
)


# ============================================================
# LOAD HOMOGRAPHY
# ============================================================

if not H_FILE.exists():

    print()
    print("[ERROR] Homography file not found:")
    print(H_FILE)

    raise SystemExit


H = np.load(H_FILE)


# ============================================================
# ARUCO
# ============================================================

dictionary = cv2.aruco.getPredefinedDictionary(
    cv2.aruco.DICT_4X4_50
)

parameters = cv2.aruco.DetectorParameters()

parameters.cornerRefinementMethod = (
    cv2.aruco.CORNER_REFINE_SUBPIX
)

parameters.adaptiveThreshWinSizeMin = 3
parameters.adaptiveThreshWinSizeMax = 53
parameters.adaptiveThreshWinSizeStep = 2

parameters.minMarkerPerimeterRate = 0.005
parameters.maxMarkerPerimeterRate = 4.0

parameters.polygonalApproxAccuracyRate = 0.05

parameters.minCornerDistanceRate = 0.01
parameters.minMarkerDistanceRate = 0.01

parameters.minDistanceToBorder = 2

parameters.cornerRefinementWinSize = 5
parameters.cornerRefinementMaxIterations = 50
parameters.cornerRefinementMinAccuracy = 0.01


detector = cv2.aruco.ArucoDetector(
    dictionary,
    parameters
)


# ============================================================
# CAMERA
# ============================================================

cap = cv2.VideoCapture(
    CAMERA_ID,
    cv2.CAP_V4L2
)

if not cap.isOpened():

    print("[ERROR] Cannot open camera.")

    raise SystemExit


cap.set(
    cv2.CAP_PROP_FOURCC,
    cv2.VideoWriter_fourcc(*"MJPG")
)

cap.set(
    cv2.CAP_PROP_FRAME_WIDTH,
    FRAME_W
)

cap.set(
    cv2.CAP_PROP_FRAME_HEIGHT,
    FRAME_H
)

cap.set(
    cv2.CAP_PROP_FPS,
    CAMERA_FPS
)

cap.set(
    cv2.CAP_PROP_AUTOFOCUS,
    0
)

time.sleep(2)


# ============================================================
# TELLO
# ============================================================

tello = Tello()

airborne = False


# ============================================================
# VISION SHARED STATE
# ============================================================

vision_lock = threading.Lock()

vision_running = True


vision_state = {

    "detected": False,

    "x": None,
    "y": None,

    "angle": None,

    "source": "NONE",

    "frame_read_timestamp": 0.0,
    "frame_sequence": 0,
    "processing_timestamp": 0.0,
    "last_detection_timestamp": 0.0,

    "fps": 0.0
}


# ============================================================
# ROI TRACKING STATE
# ============================================================

tracking = False

last_center = None

consecutive_roi_lost = 0


# ============================================================
# LOG
# ============================================================

flight_log = []


# ============================================================
# UTILITY
# ============================================================

def normalize_angle(angle):

    while angle > 180:
        angle -= 360

    while angle < -180:
        angle += 360

    return angle


def arena_safe(x, y):

    return (
        ARENA_MARGIN_M
        <= x
        <= ARENA_WIDTH_M - ARENA_MARGIN_M

        and

        ARENA_MARGIN_M
        <= y
        <= ARENA_HEIGHT_M - ARENA_MARGIN_M
    )


# ============================================================
# HOMOGRAPHY
# ============================================================

def pixel_to_warp(u, v):

    point = np.array(
        [[[u, v]]],
        dtype=np.float32
    )

    transformed = cv2.perspectiveTransform(
        point,
        H
    )

    return (
        float(transformed[0][0][0]),
        float(transformed[0][0][1])
    )


def pixel_to_xy(u, v):

    wx, wy = pixel_to_warp(
        u,
        v
    )

    x = (
        wx
        /
        (WARP_W - 1)
        *
        ARENA_WIDTH_M
    )

    y = (
        wy
        /
        (WARP_H - 1)
        *
        ARENA_HEIGHT_M
    )

    return x, y


# ============================================================
# BASIC ARUCO DETECTION
# ============================================================

def detect_id1(image):

    gray = cv2.cvtColor(
        image,
        cv2.COLOR_BGR2GRAY
    )

    corners, ids, _ = detector.detectMarkers(
        gray
    )

    if ids is None:

        return (
            False,
            None
        )


    for i, marker_id in enumerate(
        ids.flatten()
    ):

        if int(marker_id) == MARKER_ID:

            pts = corners[i][0].astype(
                np.float32
            )

            return (
                True,
                pts
            )


    return (
        False,
        None
    )


# ============================================================
# ROI
# ============================================================

def make_roi(
    center_x,
    center_y,
    frame_width,
    frame_height
):

    half = ROI_SIZE // 2

    x1 = int(center_x - half)
    y1 = int(center_y - half)

    x2 = int(center_x + half)
    y2 = int(center_y + half)


    if x1 < 0:

        x2 -= x1
        x1 = 0


    if y1 < 0:

        y2 -= y1
        y1 = 0


    if x2 > frame_width:

        shift = x2 - frame_width

        x1 -= shift
        x2 = frame_width


    if y2 > frame_height:

        shift = y2 - frame_height

        y1 -= shift
        y2 = frame_height


    x1 = max(
        0,
        x1
    )

    y1 = max(
        0,
        y1
    )


    return (
        x1,
        y1,
        x2,
        y2
    )


# ============================================================
# ROI TRACKING
# ============================================================

def track_id1(frame):

    global tracking
    global last_center
    global consecutive_roi_lost


    h, w = frame.shape[:2]


    detected = False

    pts_global = None

    source = "NONE"


    # ========================================================
    # ROI SEARCH
    # ========================================================

    if (
        tracking
        and
        last_center is not None
    ):

        cx, cy = last_center


        x1, y1, x2, y2 = make_roi(
            cx,
            cy,
            w,
            h
        )


        roi = frame[
            y1:y2,
            x1:x2
        ]


        found, pts = detect_id1(
            roi
        )


        if found:

            pts[:, 0] += x1
            pts[:, 1] += y1

            pts_global = pts

            detected = True

            source = "ROI"

            consecutive_roi_lost = 0


        else:

            consecutive_roi_lost += 1


            if (
                consecutive_roi_lost
                >=
                ROI_LOST_LIMIT
            ):

                tracking = False

                last_center = None


    # ========================================================
    # FULL FRAME RECOVERY
    # ========================================================

    if not tracking:

        found, pts = detect_id1(
            frame
        )


        if found:

            pts_global = pts

            detected = True

            source = "FULL"

            tracking = True

            consecutive_roi_lost = 0


    if not detected:

        return (
            False,
            None,
            None,
            None,
            source
        )


    # ========================================================
    # CENTER
    # ========================================================

    u = float(
        np.mean(
            pts_global[:, 0]
        )
    )

    v = float(
        np.mean(
            pts_global[:, 1]
        )
    )


    last_center = (
        u,
        v
    )


    # ========================================================
    # XY
    # ========================================================

    x, y = pixel_to_xy(
        u,
        v
    )


    # ========================================================
    # ANGLE
    # ========================================================

    p0x, p0y = pixel_to_warp(
        pts_global[0][0],
        pts_global[0][1]
    )

    p1x, p1y = pixel_to_warp(
        pts_global[1][0],
        pts_global[1][1]
    )


    angle = math.degrees(
        math.atan2(
            p1y - p0y,
            p1x - p0x
        )
    )


    angle = normalize_angle(
        angle
    )


    return (
        True,
        x,
        y,
        angle,
        source
    )


# ============================================================
# VISION THREAD
# ============================================================

def vision_worker():

    global vision_running


    counter = 0

    fps_start = time.perf_counter()

    fps = 0.0


    frame_sequence = 0

    while vision_running:

        ret, frame = cap.read()


        if not ret:

            continue


        frame_read_timestamp = time.perf_counter()
        frame_sequence += 1

        (
            detected,
            x,
            y,
            angle,
            source

        ) = track_id1(
            frame
        )


        now = time.perf_counter()


        counter += 1


        elapsed = (
            now
            -
            fps_start
        )


        if elapsed >= 1.0:

            fps = (
                counter
                /
                elapsed
            )

            counter = 0

            fps_start = now


        with vision_lock:

            vision_state[
                "detected"
            ] = detected

            vision_state[
                "x"
            ] = x

            vision_state[
                "y"
            ] = y

            vision_state[
                "angle"
            ] = angle

            vision_state[
                "source"
            ] = source

            # Publish timing and result together for the same frame.
            vision_state["frame_read_timestamp"] = frame_read_timestamp
            vision_state["frame_sequence"] = frame_sequence
            vision_state["processing_timestamp"] = now

            if detected:
                vision_state["last_detection_timestamp"] = frame_read_timestamp

            vision_state[
                "fps"
            ] = fps


# ============================================================
# GET VISION
# ============================================================

def vision_is_fresh(state):

    return (
        state["detected"]
        and state["frame_sequence"] > 0
        and 0.0 <= time.perf_counter() - state["frame_read_timestamp"]
        <= VISION_STOP_TIMEOUT
    )


def get_vision():

    with vision_lock:

        return dict(
            vision_state
        )


# ============================================================
# GET STABLE POSITION
# ============================================================

def get_position_median(
    duration=0.50
):

    xs = []
    ys = []
    angles = []


    last_sequence = 0
    start = time.perf_counter()


    while (
        time.perf_counter()
        -
        start
        <
        duration
    ):

        state = get_vision()


        if time.perf_counter() - state["last_detection_timestamp"] > VISION_LAND_TIMEOUT:
            tello.send_rc_control(0, 0, 0, 0)
            raise RuntimeError("Vision lost during position capture.")

        if (
            vision_is_fresh(state)
            and state["frame_read_timestamp"] >= start
            and state["frame_sequence"] != last_sequence
        ):
            last_sequence = state["frame_sequence"]

            xs.append(
                state["x"]
            )

            ys.append(
                state["y"]
            )

            angles.append(
                state["angle"]
            )


        time.sleep(
            0.03
        )


    if len(xs) < 5:

        return None


    return {

        "x":
            float(
                np.median(xs)
            ),

        "y":
            float(
                np.median(ys)
            ),

        "angle":
            float(
                np.median(angles)
            ),

        "samples":
            len(xs)
    }


# ============================================================
# VELOCITY REGRESSION
# ============================================================

def estimate_velocity(samples):

    if len(samples) < MIN_SAMPLES:

        return None


    t = np.array(
        [s[0] for s in samples],
        dtype=float
    )

    x = np.array(
        [s[1] for s in samples],
        dtype=float
    )

    y = np.array(
        [s[2] for s in samples],
        dtype=float
    )


    t = t - t[0]


    if np.ptp(t) < 0.25:

        return None


    vx = float(
        np.polyfit(
            t,
            x,
            1
        )[0]
    )


    vy = float(
        np.polyfit(
            t,
            y,
            1
        )[0]
    )


    return {

        "vx":
            vx,

        "vy":
            vy,

        "speed":
            math.hypot(
                vx,
                vy
            ),

        "samples":
            len(samples),

        "duration":
            float(
                t[-1]
            )
    }


# ============================================================
# RUN PHASE
# ============================================================

def run_phase(
    phase,
    duration,
    rc_lr,
    rc_fb,
    origin_x,
    origin_y
):

    print()
    print(
        f"[PHASE] {phase}"
    )


    samples = []


    start = time.perf_counter()

    last_sample_sequence = 0

    last_send = -999.0

    last_print = -999.0


    while True:

        now = time.perf_counter()

        phase_time = (
            now
            -
            start
        )


        if phase_time >= duration:

            break


        state = get_vision()


        vision_age = (
            now
            -
            state["frame_read_timestamp"]
        )


        # ====================================================
        # VISION SAFETY
        # ====================================================

        if not vision_is_fresh(state):

            tello.send_rc_control(
                0,
                0,
                0,
                0
            )


            if (
                now - state["last_detection_timestamp"]
                >
                VISION_LAND_TIMEOUT
            ):

                raise RuntimeError(
                    "Vision lost."
                )


            time.sleep(
                0.02
            )

            continue


        x = state["x"]
        y = state["y"]


        # ====================================================
        # ARENA SAFETY
        # ====================================================

        if not arena_safe(
            x,
            y
        ):

            raise RuntimeError(
                "Arena boundary safety triggered."
            )


        # ====================================================
        # DISPLACEMENT SAFETY
        # ====================================================

        displacement = math.hypot(
            x - origin_x,
            y - origin_y
        )


        if (
            displacement
            >
            MAX_DISPLACEMENT_M
        ):

            raise RuntimeError(
                "Maximum displacement exceeded: "
                f"{displacement:.3f} m"
            )


        # ====================================================
        # SAMPLE
        # ====================================================

        if (
            state["frame_sequence"] != last_sample_sequence
            and state["frame_read_timestamp"] >= start
        ):
            samples.append(
                (
                    state["frame_read_timestamp"] - start,
                    x,
                    y
                )
            )
            last_sample_sequence = state["frame_sequence"]


        # ====================================================
        # RC
        # ====================================================

        if (
            now
            -
            last_send
            >=
            RC_SEND_INTERVAL
        ):

            last_send = now


            tello.send_rc_control(
                rc_lr,
                rc_fb,
                0,
                0
            )


        # ====================================================
        # LOG
        # ====================================================

        flight_log.append({

            "timestamp":
                datetime.now().isoformat(),

            "phase":
                phase,

            "phase_time_s":
                phase_time,

            "x_m":
                x,

            "y_m":
                y,

            "origin_x_m":
                origin_x,

            "origin_y_m":
                origin_y,

            "displacement_m":
                displacement,

            "angle_deg":
                state["angle"],

            "rc_lr":
                rc_lr,

            "rc_fb":
                rc_fb,

            "vision_fps":
                state["fps"],

            "vision_source":
                state["source"],

            "vision_age_s":
                vision_age
        })


        # ====================================================
        # TERMINAL
        # ====================================================

        if (
            now
            -
            last_print
            >=
            0.25
        ):

            last_print = now


            print(
                f"{phase:12s}"
                f" X={x:.3f}"
                f" Y={y:.3f}"
                f" D={displacement*100:5.1f}cm"
                f" LR={rc_lr:+3d}"
                f" FB={rc_fb:+3d}"
                f" FPS={state['fps']:.1f}"
            )


        time.sleep(
            0.01
        )


    # ========================================================
    # STOP
    # ========================================================

    tello.send_rc_control(
        0,
        0,
        0,
        0
    )


    velocity = estimate_velocity(
        samples
    )


    print(
        f"[END] {phase}"
        f" | N={len(samples)}"
    )


    if velocity is not None:

        print(
            f"      Vx="
            f"{velocity['vx']*100:+.2f} cm/s"
            f" Vy="
            f"{velocity['vy']*100:+.2f} cm/s"
            f" |V|="
            f"{velocity['speed']*100:.2f} cm/s"
        )


    else:

        print(
            "      velocity unavailable"
        )


    return {

        "phase":
            phase,

        "samples":
            samples,

        "velocity":
            velocity
    }


# ============================================================
# SETTLE
# ============================================================

def settle(
    duration,
    origin_x,
    origin_y
):

    return run_phase(
        "SETTLE",
        duration,
        0,
        0,
        origin_x,
        origin_y
    )


# ============================================================
# CSV
# ============================================================

def save_csv():

    if len(flight_log) == 0:

        return


    with open(
        CSV_FILE,
        "w",
        newline=""
    ) as f:

        writer = csv.DictWriter(
            f,
            fieldnames=list(
                flight_log[0].keys()
            )
        )

        writer.writeheader()

        writer.writerows(
            flight_log
        )


# ============================================================
# PRINT VELOCITY
# ============================================================

def print_velocity(
    name,
    result
):

    velocity = result[
        "velocity"
    ]


    if velocity is None:

        print(
            f"{name:<10}"
            " insufficient data"
        )

        return


    print(
        f"{name:<10}"
        f" Vx={velocity['vx']*100:+7.2f}"
        f" Vy={velocity['vy']*100:+7.2f}"
        f" cm/s"
        f" N={velocity['samples']:>3d}"
    )


# ============================================================
# INTRO
# ============================================================

print()
print("=" * 74)
print(" P04-B1 V2 - AUTOMATIC XY RESPONSE MAPPING")
print("=" * 74)

print()

print(
    f"Mapping RC          : +/-{MAP_RC}"
)

print(
    f"Pulse               : {PULSE_TIME:.2f} s"
)

print(
    f"Max displacement    : "
    f"{MAX_DISPLACEMENT_M*100:.0f} cm"
)

print(
    f"ROI                 : "
    f"{ROI_SIZE} x {ROI_SIZE}"
)

print()

print(
    "NO POSITION HOLD WILL BE ACTIVATED."
)

print()


# ============================================================
# MAIN
# ============================================================

vision_thread = None


try:

    # ========================================================
    # START VISION
    # ========================================================

    vision_thread = threading.Thread(
        target=vision_worker,
        daemon=True
    )

    vision_thread.start()


    print(
        "Waiting for camera..."
    )

    time.sleep(
        2
    )


    state = get_vision()


    if not vision_is_fresh(state):

        raise RuntimeError(
            "ID1 not detected before takeoff."
        )


    print(
        f"Vision OK | "
        f"X={state['x']:.3f} "
        f"Y={state['y']:.3f}"
    )


    # ========================================================
    # CONNECT
    # ========================================================

    print()
    print(
        "Connecting Tello..."
    )

    tello.connect()


    battery = tello.get_battery()


    print(
        f"Battery = {battery}%"
    )


    if battery < MIN_BATTERY:

        raise RuntimeError(
            "Battery too low."
        )


    # ========================================================
    # TAKEOFF
    # ========================================================

    print()
    print(
        "Taking off..."
    )

    # Connection/battery checks may have outlasted the first observation.
    if not vision_is_fresh(get_vision()):
        raise RuntimeError("Fresh ID1 observation required before takeoff.")

    tello.takeoff()

    airborne = True


    tello.send_rc_control(
        0,
        0,
        0,
        0
    )


    print(
        f"Stabilizing "
        f"{STABILIZE_TIME:.1f}s..."
    )

    time.sleep(
        STABILIZE_TIME
    )


    # ========================================================
    # ORIGIN
    # ========================================================

    origin = get_position_median(
        1.0
    )


    if origin is None:

        raise RuntimeError(
            "Cannot establish origin."
        )


    origin_x = origin["x"]
    origin_y = origin["y"]


    print()
    print("=" * 60)

    print(
        f"ORIGIN X = "
        f"{origin_x:.3f} m"
    )

    print(
        f"ORIGIN Y = "
        f"{origin_y:.3f} m"
    )

    print(
        f"ANGLE    = "
        f"{origin['angle']:+.1f} deg"
    )

    print("=" * 60)


    if not arena_safe(
        origin_x,
        origin_y
    ):

        raise RuntimeError(
            "Origin too close to arena boundary."
        )


    # ========================================================
    # BASELINE
    # ========================================================

    baseline = run_phase(
        "BASELINE",
        BASELINE_TIME,
        0,
        0,
        origin_x,
        origin_y
    )


    # ========================================================
    # FB +
    # ========================================================

    fb_plus = run_phase(
        "FB_PLUS",
        PULSE_TIME,
        0,
        +MAP_RC,
        origin_x,
        origin_y
    )


    settle(
        SETTLE_TIME,
        origin_x,
        origin_y
    )


    # ========================================================
    # FB -
    # ========================================================

    fb_minus = run_phase(
        "FB_MINUS",
        PULSE_TIME,
        0,
        -MAP_RC,
        origin_x,
        origin_y
    )


    settle(
        SETTLE_TIME,
        origin_x,
        origin_y
    )


    # ========================================================
    # LR +
    # ========================================================

    lr_plus = run_phase(
        "LR_PLUS",
        PULSE_TIME,
        +MAP_RC,
        0,
        origin_x,
        origin_y
    )


    settle(
        SETTLE_TIME,
        origin_x,
        origin_y
    )


    # ========================================================
    # LR -
    # ========================================================

    lr_minus = run_phase(
        "LR_MINUS",
        PULSE_TIME,
        -MAP_RC,
        0,
        origin_x,
        origin_y
    )


    # ========================================================
    # STOP
    # ========================================================

    tello.send_rc_control(
        0,
        0,
        0,
        0
    )


    time.sleep(
        0.5
    )


    # ========================================================
    # LAND NOW
    # ========================================================

    print()
    print(
        "Mapping complete."
    )

    print(
        "Landing..."
    )


    tello.land()

    airborne = False


    # ========================================================
    # SAVE CSV
    # ========================================================

    save_csv()


    # ========================================================
    # RAW RESULTS
    # ========================================================

    print()
    print("=" * 74)
    print(" RAW RESPONSE")
    print("=" * 74)

    print()

    print_velocity(
        "BASELINE",
        baseline
    )

    print()

    print_velocity(
        "FB_PLUS",
        fb_plus
    )

    print_velocity(
        "FB_MINUS",
        fb_minus
    )

    print()

    print_velocity(
        "LR_PLUS",
        lr_plus
    )

    print_velocity(
        "LR_MINUS",
        lr_minus
    )


    # ========================================================
    # CHECK DATA
    # ========================================================

    results = [
        fb_plus,
        fb_minus,
        lr_plus,
        lr_minus
    ]


    if any(
        result["velocity"] is None
        for result in results
    ):

        raise RuntimeError(
            "One or more mapping phases "
            "have insufficient data."
        )


    # ========================================================
    # DIFFERENTIAL RESPONSE
    # ========================================================

    vp_fb = fb_plus[
        "velocity"
    ]

    vm_fb = fb_minus[
        "velocity"
    ]


    vp_lr = lr_plus[
        "velocity"
    ]

    vm_lr = lr_minus[
        "velocity"
    ]


    fb_vx = (
        vp_fb["vx"]
        -
        vm_fb["vx"]
    ) / 2.0


    fb_vy = (
        vp_fb["vy"]
        -
        vm_fb["vy"]
    ) / 2.0


    lr_vx = (
        vp_lr["vx"]
        -
        vm_lr["vx"]
    ) / 2.0


    lr_vy = (
        vp_lr["vy"]
        -
        vm_lr["vy"]
    ) / 2.0


    fb_mag = math.hypot(
        fb_vx,
        fb_vy
    )


    lr_mag = math.hypot(
        lr_vx,
        lr_vy
    )


    fb_direction = normalize_angle(
        math.degrees(
            math.atan2(
                fb_vy,
                fb_vx
            )
        )
    )


    lr_direction = normalize_angle(
        math.degrees(
            math.atan2(
                lr_vy,
                lr_vx
            )
        )
    )


    print()
    print("=" * 74)
    print(" DIFFERENTIAL RESPONSE")
    print("=" * 74)

    print()

    print(
        f"FB +{MAP_RC} equivalent:"
    )

    print(
        f"Vx  = "
        f"{fb_vx*100:+.2f} cm/s"
    )

    print(
        f"Vy  = "
        f"{fb_vy*100:+.2f} cm/s"
    )

    print(
        f"|V| = "
        f"{fb_mag*100:.2f} cm/s"
    )

    print(
        f"Dir = "
        f"{fb_direction:+.1f} deg"
    )


    print()

    print(
        f"LR +{MAP_RC} equivalent:"
    )

    print(
        f"Vx  = "
        f"{lr_vx*100:+.2f} cm/s"
    )

    print(
        f"Vy  = "
        f"{lr_vy*100:+.2f} cm/s"
    )

    print(
        f"|V| = "
        f"{lr_mag*100:.2f} cm/s"
    )

    print(
        f"Dir = "
        f"{lr_direction:+.1f} deg"
    )


    # ========================================================
    # RESPONSE MATRIX
    #
    # Column 0 = FB +MAP_RC
    # Column 1 = LR +MAP_RC
    # ========================================================

    M = np.array([

        [
            fb_vx,
            lr_vx
        ],

        [
            fb_vy,
            lr_vy
        ]

    ])


    determinant = float(
        np.linalg.det(
            M
        )
    )


    condition = float(
        np.linalg.cond(
            M
        )
    )


    print()
    print("=" * 74)
    print(" RESPONSE MATRIX")
    print("=" * 74)

    print()

    print(
        f"M{MAP_RC} ="
    )

    print(M)

    print()

    print(
        f"det(M)  = "
        f"{determinant:+.8f}"
    )

    print(
        f"cond(M) = "
        f"{condition:.2f}"
    )


    # ========================================================
    # VALIDATION
    # ========================================================

    response_ok = (
        fb_mag
        >=
        MIN_RESPONSE_MPS

        and

        lr_mag
        >=
        MIN_RESPONSE_MPS
    )


    determinant_ok = (
        abs(determinant)
        >=
        MIN_DETERMINANT
    )


    condition_ok = (
        np.isfinite(
            condition
        )

        and

        condition
        <=
        MAX_CONDITION
    )


    matrix_pass = (
        response_ok
        and
        determinant_ok
        and
        condition_ok
    )


    print()
    print("=" * 74)
    print(" MATRIX VALIDATION")
    print("=" * 74)

    print()

    print(
        f"FB response : "
        f"{'PASS' if fb_mag >= MIN_RESPONSE_MPS else 'FAIL'}"
    )

    print(
        f"LR response : "
        f"{'PASS' if lr_mag >= MIN_RESPONSE_MPS else 'FAIL'}"
    )

    print(
        f"Determinant : "
        f"{'PASS' if determinant_ok else 'FAIL'}"
    )

    print(
        f"Condition   : "
        f"{'PASS' if condition_ok else 'FAIL'}"
    )


    if matrix_pass:

        inverse = np.linalg.inv(
            M
        )


        print()
        print(
            "[PASS] Mapping matrix accepted."
        )

        print()

        print(
            "Inverse matrix:"
        )

        print(
            inverse
        )


        # ====================================================
        # SAVE MATRIX
        # ====================================================

        np.save(
            MATRIX_FILE,
            M
        )

        # Stable, self-describing artifact consumed by position hold.
        # It is written only after this matrix passes validation.
        np.savez(
            CALIBRATION_LATEST_FILE,
            matrix=M,
            calibration_rc=float(MAP_RC),
            determinant=determinant,
            condition=condition,
            timestamp=timestamp,
            marker_id=int(MARKER_ID),
            frame_w=int(FRAME_W),
            frame_h=int(FRAME_H),
            warp_w=int(WARP_W),
            warp_h=int(WARP_H),
            homography=H.copy()
        )


        with open(
            MATRIX_TXT_FILE,
            "w"
        ) as f:

            f.write(
                "P04-B1 AUTO MAPPING V2\n"
            )

            f.write(
                f"Timestamp: {timestamp}\n"
            )

            f.write(
                f"Mapping RC: +/-{MAP_RC}\n\n"
            )

            f.write(
                "Matrix columns:\n"
            )

            f.write(
                "Column 0 = FB response\n"
            )

            f.write(
                "Column 1 = LR response\n\n"
            )

            f.write(
                "M =\n"
            )

            f.write(
                np.array2string(
                    M,
                    precision=8
                )
            )

            f.write(
                "\n\nInverse =\n"
            )

            f.write(
                np.array2string(
                    inverse,
                    precision=8
                )
            )

            f.write(
                "\n\n"
            )

            f.write(
                f"det = {determinant:.8f}\n"
            )

            f.write(
                f"condition = {condition:.4f}\n"
            )

            f.write(
                f"FB magnitude = "
                f"{fb_mag:.6f} m/s\n"
            )

            f.write(
                f"LR magnitude = "
                f"{lr_mag:.6f} m/s\n"
            )

            f.write(
                f"FB direction = "
                f"{fb_direction:.2f} deg\n"
            )

            f.write(
                f"LR direction = "
                f"{lr_direction:.2f} deg\n"
            )


        print()
        print(
            "Matrix saved:"
        )

        print(
            MATRIX_FILE
        )

        print(
            MATRIX_TXT_FILE
        )

        print(
            CALIBRATION_LATEST_FILE
        )


    else:

        print()
        print(
            "[FAIL] Matrix NOT accepted."
        )

        print(
            "Do NOT use this matrix "
            "for position hold."
        )


    print()
    print(
        "CSV:"
    )

    print(
        CSV_FILE
    )


except KeyboardInterrupt:

    print()
    print(
        "[STOP] User requested stop."
    )


except Exception as e:

    print()
    print(
        "[ERROR]"
    )

    print(
        e
    )


finally:

    # ========================================================
    # STOP HORIZONTAL MOTION FIRST
    # ========================================================

    try:

        tello.send_rc_control(
            0,
            0,
            0,
            0
        )

    except Exception:

        pass


    # ========================================================
    # LAND IF NECESSARY
    # ========================================================

    if airborne:

        print()
        print(
            "[SAFETY] Landing..."
        )

        try:

            time.sleep(
                0.3
            )

            tello.land()

        except Exception as e:

            print(
                "[WARN] Landing:",
                e
            )


    # ========================================================
    # STOP VISION
    # ========================================================

    vision_running = False


    if (
        vision_thread is not None
        and
        vision_thread.is_alive()
    ):

        vision_thread.join(
            timeout=1.0
        )


    # ========================================================
    # SAVE PARTIAL CSV
    # ========================================================

    if len(flight_log) > 0:

        try:

            save_csv()

        except Exception as e:

            print(
                "[WARN] CSV:",
                e
            )


    cap.release()

    cv2.destroyAllWindows()


    try:

        tello.end()

    except Exception:

        pass


    print()
    print(
        "Program finished."
    )
