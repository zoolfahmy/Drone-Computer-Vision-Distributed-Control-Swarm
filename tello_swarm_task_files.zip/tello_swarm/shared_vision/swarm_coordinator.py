#!/usr/bin/env python3
"""
SWARM COORDINATOR  -  starts several step11_hold.py --swarm agents together
and lands all of them if anything goes wrong with any one.
=============================================================================

Run on any Pi on the swarm Ethernet (normally the camera Pi):

    python3 swarm_coordinator.py --markers 1,2                      # watch only, never GO
    python3 swarm_coordinator.py --markers 1,2 --confirm SWARM-GO-2 # GO when all READY

Each flight Pi runs its own agent, e.g.
    python3 step11_hold.py --swarm --marker 1 --wp 10,0 --hold 8 --confirm WP-RC18
    python3 step11_hold.py --swarm --marker 2 --wp 10,0 --hold 8 --confirm WP-RC18

Sequence: IDLE (heartbeat) -> all expected agents READY -> GO (once) ->
monitor -> all LANDED -> done.

LAND_ALL is sent (and kept sent) when, after GO:
  * any agent reports ABORTED or a fault, or
  * any expected agent is silent for more than 1.5 s while a drone may be flying,
  * the flight time limit is reached, or the coordinator is stopped (Ctrl+C/SIGTERM).
Before GO, an agent that aborts cancels the whole run (LAND_ALL keeps the
others on the ground).  The agents themselves land if this coordinator goes
silent for 1.5 s, so stopping it always brings every drone down.
"""
import argparse
import signal
import sys
import time

from swarm_link import SwarmLink

CMD_DT = 0.2
AGENT_TIMEOUT_S = 1.5
END_STATES = ("LANDED", "ABORTED", "ENDED")


def on_sigterm(signum, frame):
    raise KeyboardInterrupt


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--markers", required=True, help="expected drone marker IDs, e.g. 1,2")
    ap.add_argument("--confirm", default="", help="SWARM-GO-<number of drones> to allow GO")
    ap.add_argument("--ready-timeout", type=float, default=180.0)
    ap.add_argument("--flight-timeout", type=float, default=150.0,
                    help="LAND_ALL this long after GO if not all landed")
    args = ap.parse_args()
    markers = sorted(int(m) for m in args.markers.split(",") if m.strip())
    token = f"SWARM-GO-{len(markers)}"
    armed = args.confirm == token
    signal.signal(signal.SIGTERM, on_sigterm)

    print("=" * 72)
    print(f" SWARM COORDINATOR  markers {markers}  "
          + ("ARMED: GO when all READY" if armed else f"WATCH ONLY (GO needs --confirm {token})"))
    print("=" * 72)

    link = SwarmLink().start()
    run_id = time.strftime("%H%M%S")
    cmd, why = "IDLE", ""
    go_at = None
    t0 = time.perf_counter()
    last_print = 0.0
    result = "?"
    seen_airborne = set()

    def land_all(reason):
        nonlocal cmd, why
        if cmd != "LAND_ALL":
            print(f"\n*** LAND_ALL: {reason} ***\n", flush=True)
        cmd, why = "LAND_ALL", reason

    try:
        while True:
            now = time.perf_counter()
            st = link.statuses()
            for m in markers:
                s = st.get(m, ({}, 1e9))[0]
                if s.get("airborne"):
                    seen_airborne.add(m)

            if cmd == "IDLE":
                bad = [m for m in markers if m in st and st[m][0].get("state") in END_STATES]
                if bad:
                    land_all(f"ID{bad[0]} {st[bad[0]][0].get('state')} before GO: "
                             f"{st[bad[0]][0].get('fault', '')}")
                    result = "CANCELLED"
                ready = [m for m in markers if m in st and st[m][1] <= AGENT_TIMEOUT_S
                         and st[m][0].get("state") == "READY"]
                if cmd == "IDLE" and len(ready) == len(markers) and armed:
                    cmd, go_at = "GO", now
                    print(f"\n*** ALL {len(markers)} READY -> GO (run {run_id}) ***\n", flush=True)
                elif cmd == "IDLE" and now - t0 > args.ready_timeout:
                    land_all("not all agents READY in time")
                    result = "NOT_READY"

            elif cmd == "GO":
                for m in markers:
                    s, age = st.get(m, ({}, 1e9))
                    if s.get("fault") or s.get("state") == "ABORTED":
                        land_all(f"ID{m}: {s.get('fault') or s.get('state')}")
                        break
                    if age > AGENT_TIMEOUT_S and s.get("state") not in END_STATES:
                        land_all(f"ID{m} silent for {age:.1f} s")
                        break
                if cmd == "GO" and now - go_at > args.flight_timeout:
                    land_all("flight time limit")

            all_done = all(m in st and st[m][0].get("state") in END_STATES for m in markers)
            if cmd != "IDLE" and all_done:
                if result == "?":
                    ok = all(st[m][0].get("state") == "LANDED" for m in markers)
                    result = "ALL LANDED - COMPLETE" if (ok and cmd == "GO") else f"ENDED ({why})"
                break
            if cmd == "LAND_ALL" and now - t0 > 2.0:
                # Wait for every agent that is still talking to report the end.
                # A silent agent's last status is stale: its Pi crashed or lost
                # Ethernet.  The Tello then lands itself after ~15 s without commands.
                talking = [m for m in markers if m in st and st[m][1] <= 3.0
                           and st[m][0].get("state") not in END_STATES]
                if not talking:
                    silent = [m for m in markers if m in st and st[m][1] > 3.0
                              and st[m][0].get("state") not in END_STATES]
                    if silent:
                        print(f"!!! ID{silent} SILENT - check those drones by eye; a Tello "
                              "with no commands lands itself after ~15 s.", flush=True)
                    result = result if result != "?" else f"LAND_ALL ({why})"
                    break

            link.send({"type": "cmd", "cmd": cmd, "run": run_id, "why": why})

            if now - last_print >= 1.0:
                last_print = now
                parts = []
                for m in markers:
                    s, age = st.get(m, ({}, None))
                    if age is None:
                        parts.append(f"ID{m}: --")
                        continue
                    pos = (f"({s['x']:.2f},{s['y']:.2f})" if s.get("x") is not None else "")
                    parts.append(f"ID{m}@{s.get('host', '?')}: {s.get('state')}{pos}"
                                 f" bat {s.get('battery')}%"
                                 + (f" FAULT {s['fault']}" if s.get("fault") else "")
                                 + (f" [silent {age:.1f}s]" if age > AGENT_TIMEOUT_S else ""))
                print(f"[{now - t0:5.1f}s] {cmd:8s} | " + " | ".join(parts), flush=True)
            time.sleep(CMD_DT)

    except KeyboardInterrupt:
        land_all("coordinator stopped")
        result = "STOPPED"
    finally:
        if cmd == "LAND_ALL" or result == "STOPPED":
            end = time.perf_counter() + 1.5
            while time.perf_counter() < end:
                link.send({"type": "cmd", "cmd": "LAND_ALL", "run": run_id, "why": why})
                time.sleep(CMD_DT)
        link.stop()

    print(f"RESULT: {result}")
    return 0 if result.startswith("ALL LANDED") else 1


if __name__ == "__main__":
    sys.exit(main())
