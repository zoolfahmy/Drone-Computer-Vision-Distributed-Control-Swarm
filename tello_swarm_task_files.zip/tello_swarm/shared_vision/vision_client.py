#!/usr/bin/env python3
"""
VISION CLIENT  -  receives the shared overhead vision on a flight Pi
====================================================================

The flight Pi does not open the camera.  camera_host.py (on the camera Pi)
broadcasts every marker's arena position; this module listens for it and
hands a flight script exactly the record Step 10 used to build itself:

    from vision_client import VisionClient

    vision = VisionClient()
    vision.start()
    state = vision.get_state(1)     # marker ID 1
    state["detected"], state["x"], state["y"], state["angle"],
    state["frame_read_timestamp"], state["frame_sequence"],
    state["last_detection_timestamp"], state["fps"], ...

Timestamps are on THIS Pi's clock (time.perf_counter), already corrected for
the time the frame spent on the camera Pi, so the Step 10 freshness rules
(0.5 s hold, 1.5 s land) work unchanged.  If the cable is pulled or the host
stops, the record simply goes stale and those rules land the drone.

Check the link from any Pi:

    python3 vision_client.py

Nothing to configure: the host is found automatically, and so is its video.
"""

import json
import socket
import threading
import time
import urllib.request

import cv2
import numpy as np

POSE_PORT = 9870
PROTOCOL = "tello-arena-pose/1"

# A second camera host on the network is ignored while the first one is alive.
HOST_SWITCH_AFTER_S = 1.0


class VisionClient:

    def __init__(self, port=POSE_PORT, video=True):
        self.port = port
        self.video_enabled = video

        self._lock = threading.Lock()
        self._running = False
        self._sock = None

        self._sid = None
        self._seq = 0
        self._frame_ts = 0.0        # when the latest frame was read (our clock)
        self._rx_ts = 0.0           # when its packet arrived (our clock)
        self._markers = {}          # {id: marker dict} of the latest frame
        self._last_seen = {}        # {id: frame timestamp of last detection}
        self._fps = 0.0

        self.info = None            # static host data (frame size, homography...)
        self.host_ip = None
        self.simulated = False
        self.packets = 0
        self.second_host_ts = 0.0   # last time a different host was heard

        self._image = None
        self._image_ts = 0.0

    # ------------------------------------------------------------------
    def start(self):
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        if hasattr(socket, "SO_REUSEPORT"):
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEPORT, 1)
        try:
            sock.bind(("", self.port))
        except OSError as exc:
            raise RuntimeError(
                f"Cannot listen on UDP port {self.port}: {exc}") from exc
        sock.settimeout(0.5)
        self._sock = sock
        self._running = True
        threading.Thread(target=self._pose_loop, daemon=True).start()
        if self.video_enabled:
            threading.Thread(target=self._video_loop, daemon=True).start()
        return self

    def stop(self):
        self._running = False
        try:
            self._sock.close()
        except Exception:
            pass

    # ------------------------------------------------------------------
    def _pose_loop(self):
        while self._running:
            try:
                data, addr = self._sock.recvfrom(65535)
            except socket.timeout:
                continue
            except OSError:
                break
            t_rx = time.perf_counter()
            try:
                packet = json.loads(data)
                if packet.get("proto") != PROTOCOL:
                    continue
                sid = packet["sid"]
                seq = int(packet["seq"])
                age = min(1.0, max(0.0, float(packet.get("age", 0.0))))
                markers = {int(k): v for k, v in packet["m"].items()}
            except (ValueError, KeyError, TypeError, AttributeError):
                continue

            with self._lock:
                if sid != self._sid:
                    if (self._sid is not None
                            and t_rx - self._rx_ts < HOST_SWITCH_AFTER_S):
                        self.second_host_ts = t_rx      # two hosts running
                        continue
                    self._sid = sid                      # new / restarted host
                    self._seq = 0
                    self.host_ip = addr[0]
                    self.info = None
                if seq <= self._seq:
                    continue                             # duplicate or late
                self._seq = seq
                self._rx_ts = t_rx
                self._frame_ts = t_rx - age
                self._markers = markers
                self._fps = float(packet.get("fps", 0.0))
                self.simulated = bool(packet.get("sim", False))
                self.packets += 1
                for marker_id in markers:
                    self._last_seen[marker_id] = self._frame_ts
                if "info" in packet:
                    self.info = packet["info"]

    # ------------------------------------------------------------------
    def _video_loop(self):
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        while self._running:
            ip, info = self.host_ip, self.info
            if ip is None or info is None or self.link_age() > 2.0:
                time.sleep(0.2)
                continue
            url = f"http://{ip}:{info.get('http_port', 8080)}/stream"
            try:
                with opener.open(url, timeout=3) as r:
                    while self._running and self.host_ip == ip:
                        length = None
                        while True:
                            line = r.readline()
                            if not line:
                                raise ConnectionError("stream closed")
                            line = line.strip()
                            if line.lower().startswith(b"content-length:"):
                                length = int(line.split(b":")[1])
                            elif line == b"" and length is not None:
                                break
                        data = r.read(length)
                        if len(data) != length:
                            raise ConnectionError("stream cut")
                        image = cv2.imdecode(np.frombuffer(data, np.uint8),
                                             cv2.IMREAD_COLOR)
                        if image is not None:
                            with self._lock:
                                self._image = image
                                self._image_ts = time.perf_counter()
            except Exception:
                time.sleep(1.0)

    # ------------------------------------------------------------------
    def get_state(self, marker_id):
        """The Step 10 `vision_state` record for one marker."""
        with self._lock:
            m = self._markers.get(marker_id)
            return {
                "detected": m is not None,
                "x": m["x"] if m else None,
                "y": m["y"] if m else None,
                "angle": m["a"] if m else None,
                "pts": np.array(m["p"], dtype=np.float32) if m else None,
                "source": m.get("s", "ROI") if m else "NONE",
                "frame_read_timestamp": self._frame_ts,
                "frame_sequence": self._seq,
                "processing_timestamp": self._rx_ts,
                "last_detection_timestamp": self._last_seen.get(marker_id, 0.0),
                "fps": self._fps,
            }

    def markers(self):
        """All drone markers in the latest frame: {id: {x, y, a, u, v, p}}."""
        with self._lock:
            return {k: dict(v) for k, v in self._markers.items()}

    def link_age(self):
        """Seconds since the last pose packet (large if none yet)."""
        with self._lock:
            if self._rx_ts == 0.0:
                return 1e9
            return time.perf_counter() - self._rx_ts

    def two_hosts(self):
        """True if a second camera host was heard in the last 2 seconds."""
        return (self.second_host_ts > 0.0
                and time.perf_counter() - self.second_host_ts < 2.0)

    def get_image(self):
        """Latest video picture and its age in seconds, or (None, None)."""
        with self._lock:
            if self._image is None:
                return None, None
            return self._image, time.perf_counter() - self._image_ts


# ============================================================
# LINK CHECK:  python3 vision_client.py
# ============================================================

def main():
    import argparse
    ap = argparse.ArgumentParser(
        description="Show what this Pi receives from camera_host.py.")
    ap.add_argument("--port", type=int, default=POSE_PORT)
    args = ap.parse_args()

    client = VisionClient(port=args.port, video=False).start()
    print(f"Listening for the camera host on UDP port {args.port} ... (Ctrl+C to stop)")
    try:
        while True:
            time.sleep(1.0)
            age = client.link_age()
            if age > 1.0:
                print("  no pose packets  - is camera_host.py running, and is "
                      "this Pi on the same network (Ethernet switch)?")
                continue
            state = client.get_state(0)
            frame_age_ms = (time.perf_counter() - state["frame_read_timestamp"]) * 1000
            seen = "   ".join(
                f"ID{k} x={m['x']:.3f} y={m['y']:.3f} a={m['a']:+.1f}"
                for k, m in sorted(client.markers().items()))
            print(f"  host {client.host_ip}"
                  f"{' [SIMULATED]' if client.simulated else ''}"
                  f" | {state['fps']:.1f} fps | frame age {frame_age_ms:.0f} ms | "
                  f"{seen or 'no drone markers in view'}"
                  f"{' | WARNING: two camera hosts are running' if client.two_hosts() else ''}")
    except KeyboardInterrupt:
        pass
    finally:
        client.stop()


if __name__ == "__main__":
    main()
