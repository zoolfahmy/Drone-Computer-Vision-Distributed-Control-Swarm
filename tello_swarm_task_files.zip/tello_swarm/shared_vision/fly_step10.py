#!/usr/bin/env python3
"""
FLY STEP 10  -  Step 10 brake/settle flight, shared vision, live display, keyboard control
==========================================================================================

Run on a flight Pi (the camera host must be running somewhere on the network,
or on this same Pi):

    python3 fly_step10.py                # this Pi flies the drone with marker ID 1
    python3 fly_step10.py --marker 2     # ... marker ID 2
    python3 fly_step10.py --sim          # no drone: a pretend Tello, for bench tests

The window opens straight away with the overhead view and a status panel.
Nothing is typed to allow flight.  Keys (click the window, or type in the
terminal the script was started from):

    A            arm / disarm
    T            take off and fly the mission      (only while ARMED)
    L or SPACE   land now
    E            EMERGENCY: stop the motors at once (the drone drops)
    Q            quit (lands first if flying); Ctrl+C does the same

The flight itself is p04b1_step10_brake_settle.py: the same altitude hold,
pulse/brake/observe navigation, limits and failsafes, with the same numbers.
What differs:
  * vision comes from camera_host.py through vision_client.py instead of this
    script opening the camera;
  * the flight steps run in a background thread so the display and the keys
    stay alive, and you can fly again without restarting the script;
  * arming is two key presses (A, then T) instead of --pilot-arm plus a typed
    token.  A is refused, with the reason shown, unless the Tello is connected,
    the battery is at least 50 %, the camera host sees this drone's marker and
    the mission target would stay clear of the 20 cm arena margin;
  * NOT carried over: Step 10's start-up check of
    logs/p04b1_calibration_rc6_differential.npz.  Step 10's controller never
    reads that matrix (it uses the fixed "X error -> FB, Y error -> LR" map),
    and the check also refuses to start as soon as the arena homography is
    re-made, which it must be whenever the camera is moved.

The CSV log has the same columns as the Step 10 log.
"""

import argparse
import atexit
import csv
import logging
import math
import os
import select
import sys
import threading
import time
from collections import deque
from datetime import datetime
from pathlib import Path

import cv2
import numpy as np

from vision_client import POSE_PORT, VisionClient


# ============================================================
# FLIGHT            (all values below are the Step 10 values)
# ============================================================

MIN_BATTERY = 50

STABILIZE_TIME = 6.0
HOLD_TIME = 6.0              # length of the mission after the target is set
TARGET_CAPTURE_TIME = 2.0
CONTROL_DT = 0.10            # 10 Hz controller

# Mission: move this far from the point where the drone hovers after take-off.
TARGET_DX_M = 0.10
TARGET_DY_M = 0.00

# ============================================================
# ARENA
# ============================================================

ARENA_WIDTH_M = 2.1336
ARENA_HEIGHT_M = 2.1336
WARP_W = 800
WARP_H = 800

# ============================================================
# XY CONTROLLER
# ============================================================

XY_DEADBAND_M = 0.05
VEL_FILTER_ALPHA = 0.25
VELOCITY_DEADBAND_MPS = 0.008

# Pulse / brake / observe scheduler
PULSE_ON_S = 0.10
OBSERVE_S = 0.18
BRAKE_ON_S = 0.24
BRAKE_TRIGGER_MPS = 0.012
APPROACH_TRIGGER_M = 0.09
MAX_PULSES = 6
SETTLE_REQUIRED_S = 0.70

# ============================================================
# SAFETY
# ============================================================

VISION_HOLD_TIMEOUT = 0.50   # stop horizontal correction
VISION_LAND_TIMEOUT = 1.50   # land
MAX_POSITION_ERROR_M = 0.40
ARENA_MARGIN_M = 0.20

# ============================================================
# Z CONTROL
# ============================================================

TOF_MIN_VALID = 20
TOF_MAX_VALID = 200
FILTER_SIZE = 5
Z_UPDATE_INTERVAL = 0.35
Z_DEADBAND_CM = 3.0
KP_Z = 0.80
MAX_RC_Z = 6
MIN_ACTIVE_Z_RC = 4
SOFT_CEILING_OFFSET = 8.0
HARD_CEILING_OFFSET = 15.0
HARD_DESCENT_RC = -8

# ============================================================
# KEYBOARD ARMING
# ============================================================

ARM_TIMEOUT_S = 60           # an unused ARM switches itself off after this

BASE_DIR = Path(__file__).resolve().parent
LOG_DIR = BASE_DIR / "logs"
WINDOW = "Tello flight - overhead view"


# ============================================================
# CONTROL MATHS   (Step 10, unchanged)
# ============================================================

def clamp(value, low, high):
    return max(low, min(high, value))


def vision_is_fresh(state):
    return (
        state["detected"]
        and state["frame_sequence"] > 0
        and 0.0 <= time.perf_counter() - state["frame_read_timestamp"]
        <= VISION_HOLD_TIMEOUT
    )


def calculate_z_control(current_tof, target_tof):
    if current_tof is None:
        return 0, None, "INVALID"

    error = target_tof - current_tof
    soft_ceiling = target_tof + SOFT_CEILING_OFFSET
    hard_ceiling = target_tof + HARD_CEILING_OFFSET

    if current_tof >= hard_ceiling:
        return HARD_DESCENT_RC, error, "HARD_CEILING"

    if abs(error) <= Z_DEADBAND_CM:
        rc_z = 0
        state = "HOLD"
    else:
        rc_z = int(round(KP_Z * error))
        if 0 < rc_z < MIN_ACTIVE_Z_RC:
            rc_z = MIN_ACTIVE_Z_RC
        elif -MIN_ACTIVE_Z_RC < rc_z < 0:
            rc_z = -MIN_ACTIVE_Z_RC
        rc_z = int(clamp(rc_z, -MAX_RC_Z, MAX_RC_Z))
        state = "UP" if rc_z > 0 else "DOWN"

    if current_tof >= soft_ceiling:
        if rc_z > 0:
            rc_z = 0
        if rc_z == 0:
            state = "SOFT_CEILING"

    return rc_z, error, state


def calculate_xy_control(x, y, target_x, target_y, vx_meas=0.0, vy_meas=0.0):
    """Empirical single-axis direction map. Pulse scheduler gates command timing."""
    ex, ey = target_x - x, target_y - y
    d = math.hypot(ex, ey)
    axis_tol = XY_DEADBAND_M
    if abs(ex) <= axis_tol and abs(ey) <= axis_tol:
        return (0, 0, ex, ey, d, 0.0, 0.0, "PULSE_DONE")
    # Correct dominant normalized error; X uses confirmed FB map, Y confirmed LR map.
    if abs(ex) >= abs(ey):
        return (0, -6 if ex > 0 else 6, ex, ey, d, 0.0, 0.0, "PULSE_X")
    return (6 if ey > 0 else -6, 0, ex, ey, d, 0.0, 0.0, "PULSE_Y")


def arena_safe(x, y):
    return (ARENA_MARGIN_M <= x <= ARENA_WIDTH_M - ARENA_MARGIN_M
            and ARENA_MARGIN_M <= y <= ARENA_HEIGHT_M - ARENA_MARGIN_M)


class PulseNavigator:
    """Step 10's velocity estimator and pulse / brake / re-measure scheduler,
    one call per 10 Hz control tick.  Logic and numbers are unchanged."""

    def __init__(self, target_x, target_y, start_time):
        self.target_x = target_x
        self.target_y = target_y
        self.nav_phase = "DECIDE"
        self.nav_phase_start = start_time
        self.pulse_lr = self.pulse_fb = 0
        self.pulse_start_error = None
        self.pulse_axis = None
        self.pulse_axis_error_start = None
        self.pulse_count = 0
        self.settle_start = None
        self.prev_xy_t = None
        self.prev_x = None
        self.prev_y = None
        self.vx_filt = 0.0
        self.vy_filt = 0.0
        self.reason = ""          # why the last tick asked for a failsafe

    def update(self, now, x, y):
        """Returns (rc_lr, rc_fb, ex, ey, distance_error, vx_des, vy_des, xy_state).
        distance_error above MAX_POSITION_ERROR_M means: failsafe, land."""

        # Estimate translational velocity from overhead marker motion.
        if self.prev_xy_t is not None and now > self.prev_xy_t:
            dt_xy = now - self.prev_xy_t
            vx_raw = (x - self.prev_x) / dt_xy
            vy_raw = (y - self.prev_y) / dt_xy
            self.vx_filt = (1.0 - VEL_FILTER_ALPHA) * self.vx_filt + VEL_FILTER_ALPHA * vx_raw
            self.vy_filt = (1.0 - VEL_FILTER_ALPHA) * self.vy_filt + VEL_FILTER_ALPHA * vy_raw
        self.prev_xy_t, self.prev_x, self.prev_y = now, x, y
        vx_filt, vy_filt = self.vx_filt, self.vy_filt

        (rc_lr, rc_fb, ex, ey, distance_error,
         vx_des, vy_des, xy_state) = calculate_xy_control(
            x, y, self.target_x, self.target_y, vx_filt, vy_filt)

        in_xy_box = (abs(ex) <= XY_DEADBAND_M and abs(ey) <= XY_DEADBAND_M)
        speed = math.hypot(vx_filt, vy_filt)
        self.reason = ""

        if in_xy_box and speed > VELOCITY_DEADBAND_MPS:
            # Position is good but aircraft is still moving: brake from measured arena velocity.
            self.settle_start = None
            if abs(vx_filt) >= abs(vy_filt):
                # +Vx needs FB+6 to brake; -Vx needs FB-6.
                rc_lr, rc_fb = 0, (6 if vx_filt > 0 else -6)
                xy_state = "VEL_TARGET_BRAKE_X"
            else:
                # Closed-loop Y evidence: +Vy is opposed by LR-6, -Vy by LR+6.
                rc_lr, rc_fb = (-6 if vy_filt > 0 else 6), 0
                xy_state = "VEL_TARGET_BRAKE_Y"
            self.nav_phase = "TARGET_BRAKE"
            self.nav_phase_start = now
        elif in_xy_box and speed <= VELOCITY_DEADBAND_MPS:
            rc_lr = rc_fb = 0
            if self.nav_phase != "SETTLE":
                self.nav_phase = "SETTLE"
                self.settle_start = now
            xy_state = "VEL_SETTLE"
            if self.settle_start is not None and now - self.settle_start >= SETTLE_REQUIRED_S:
                self.nav_phase = "COMPLETE"
                xy_state = "VEL_SETTLED"
        else:
            if self.nav_phase in ("SETTLE", "COMPLETE", "TARGET_BRAKE"):
                self.nav_phase = "DECIDE"
                self.settle_start = None
            if self.nav_phase == "DECIDE":
                self.pulse_lr, self.pulse_fb = rc_lr, rc_fb
                self.pulse_start_error = distance_error
                self.pulse_axis = "X" if rc_fb != 0 else "Y"
                self.pulse_axis_error_start = ex if self.pulse_axis == "X" else ey
                self.pulse_count += 1
                self.nav_phase = "PULSE"
                self.nav_phase_start = now
            elif self.nav_phase == "PULSE":
                rc_lr, rc_fb = self.pulse_lr, self.pulse_fb
                axis_err = ex if self.pulse_axis == "X" else ey
                axis_vel = vx_filt if self.pulse_axis == "X" else vy_filt
                toward_fast = (axis_err * axis_vel > 0
                               and abs(axis_vel) >= BRAKE_TRIGGER_MPS
                               and abs(axis_err) <= APPROACH_TRIGGER_M)
                xy_state = "VEL_PULSE_ACTIVE"
                if toward_fast or now - self.nav_phase_start >= PULSE_ON_S:
                    # Active opposite pulse to arrest measured momentum.
                    rc_lr, rc_fb = -self.pulse_lr, -self.pulse_fb
                    self.nav_phase = "BRAKE"
                    self.nav_phase_start = now
                    xy_state = "VEL_BRAKE_START"
            elif self.nav_phase == "BRAKE":
                rc_lr, rc_fb = -self.pulse_lr, -self.pulse_fb
                xy_state = "VEL_BRAKE_ACTIVE"
                if now - self.nav_phase_start >= BRAKE_ON_S:
                    rc_lr = rc_fb = 0
                    self.nav_phase = "OBSERVE"
                    self.nav_phase_start = now
                    xy_state = "VEL_NEUTRAL"
            elif self.nav_phase == "OBSERVE":
                rc_lr = rc_fb = 0
                xy_state = "VEL_OBSERVE"
                if now - self.nav_phase_start >= OBSERVE_S:
                    axis_now = ex if self.pulse_axis == "X" else ey
                    axis_before = self.pulse_axis_error_start
                    if axis_before is not None and abs(axis_now) > abs(axis_before) + 0.02:
                        xy_state = "VEL_AXIS_DIVERGENCE"
                        distance_error = MAX_POSITION_ERROR_M + 0.01
                    elif (self.pulse_start_error is not None
                          and distance_error > self.pulse_start_error + 0.10):
                        xy_state = "VEL_TOTAL_DIVERGENCE"
                        distance_error = MAX_POSITION_ERROR_M + 0.01
                    elif self.pulse_count >= MAX_PULSES:
                        xy_state = "VEL_PULSE_LIMIT"
                        distance_error = MAX_POSITION_ERROR_M + 0.01
                    else:
                        self.nav_phase = "DECIDE"

        if distance_error > MAX_POSITION_ERROR_M:
            self.reason = xy_state
        return rc_lr, rc_fb, ex, ey, distance_error, vx_des, vy_des, xy_state


# ============================================================
# PRETEND TELLO  (--sim)
# ============================================================

class FakeTello:
    """Accepts the calls this script makes on a Tello and flies nothing."""

    def __init__(self):
        self.is_flying = False
        self.retry_count = 3
        self.last_rc = (0, 0, 0, 0)

    def connect(self):
        time.sleep(0.3)

    def get_current_state(self):
        return {"bat": 87, "tof": self.get_distance_tof(),
                "h": 70 if self.is_flying else 0}

    def get_battery(self):
        return 87

    def get_distance_tof(self):
        return 80 if self.is_flying else 10

    def takeoff(self):
        time.sleep(2.0)
        self.is_flying = True

    def land(self):
        time.sleep(1.5)
        self.is_flying = False

    def emergency(self):
        self.is_flying = False

    def send_rc_control(self, lr, fb, ud, yaw):
        self.last_rc = (lr, fb, ud, yaw)

    def send_command_without_return(self, command):
        if command == "land":
            self.is_flying = False

    def end(self):
        pass


def make_tello(args):
    if args.sim:
        return FakeTello()
    from djitellopy import Tello
    # The library prints one line per RC command; keep the terminal readable.
    Tello.LOGGER.setLevel(logging.ERROR)
    return Tello(host=args.tello_ip)


class FlightStop(Exception):
    """A planned stop of the flight sequence (always followed by landing)."""


# ============================================================
# FLIGHT  (runs in a background thread; the display runs in the main thread)
# ============================================================

FLYING_STATES = ("TAKEOFF", "STABILIZE", "ALT REF", "CAPTURE", "MISSION", "LANDING")


class Flight:

    def __init__(self, args, vision):
        self.args = args
        self.marker = args.marker
        self.vision = vision
        self.tello = None

        self.state = "CONNECTING"
        self.connected = False
        self.armed = False
        self.armed_at = 0.0
        self.airborne = False
        self.finished = False

        self.takeoff_event = threading.Event()
        self.land_event = threading.Event()
        self.emergency_event = threading.Event()
        self.quit_event = threading.Event()
        self.land_requested_at = 0.0
        self.raw_land_sent = False

        self.battery = None
        self.tof = None
        self.message = "Starting..."
        self.telemetry = {}
        self.trail = deque(maxlen=400)
        self.flight_log = []
        self.end_reason = ""             # why the last mission asked for a failsafe
        self.tof_buffer = deque(maxlen=FILTER_SIZE)
        self.csv_file = None
        self._state_obj = None
        self._state_time = 0.0

    # ---------------- small helpers ----------------

    def say(self, text):
        self.message = text.strip()
        print(f"[{time.strftime('%H:%M:%S')}] {text}", flush=True)

    def set_state(self, state):
        self.state = state

    def vision_state(self):
        return self.vision.get_state(self.marker)

    def check_stop(self):
        if self.emergency_event.is_set():
            raise FlightStop("EMERGENCY stop.")
        if self.land_event.is_set():
            raise FlightStop("Landing requested from the keyboard.")

    def flush_replies(self):
        """Forget command replies nobody is waiting for.  'land' and 'emergency'
        sent straight from the keyboard are answered by the drone later; left in
        the library's queue, such a reply would be taken as the answer to the
        next command."""
        try:
            self.tello.get_own_udp_object()["responses"].clear()
        except Exception:
            pass

    def read_drone_state(self):
        """Battery and height from the drone's own status packets (no command
        is sent).  Returns the status record, or None."""
        try:
            st = self.tello.get_current_state()
            if "bat" in st:
                self.battery = int(st["bat"])
            if "tof" in st:
                self.tof = int(st["tof"])
            return st
        except Exception:
            return None

    def pause(self, seconds):
        end = time.perf_counter() + seconds
        while time.perf_counter() < end:
            self.check_stop()
            self.read_drone_state()
            time.sleep(0.02)

    # ---------------- keyboard (called from the display thread) ----------------

    def preflight_problems(self):
        problems = []
        if not self.connected:
            problems.append("Tello not connected")
        elif self.battery is None or self.battery < MIN_BATTERY:
            problems.append(f"battery {self.battery}% is below {MIN_BATTERY}%")
        state = self.vision_state()
        if self.vision.link_age() > VISION_HOLD_TIMEOUT:
            problems.append("no data from the camera host")
        elif not vision_is_fresh(state):
            problems.append(f"marker ID{self.marker} is not visible to the camera")
        elif not arena_safe(state["x"] + TARGET_DX_M, state["y"] + TARGET_DY_M):
            problems.append("drone is too close to the arena edge")
        if self.vision.two_hosts():
            problems.append("two camera hosts are running - stop one")
        if self.vision.simulated and not self.args.sim:
            problems.append("camera host is SIMULATED - not flying a real drone on it")
        return problems

    def on_key(self, key):
        key = key.lower()
        if key == "a":
            self.toggle_arm()
        elif key == "t":
            self.request_takeoff()
        elif key in ("l", " "):
            self.request_land()
        elif key == "e":
            self.emergency()
        elif key in ("q", "\x03"):          # Q, or Ctrl+C arriving as a key
            self.request_quit()

    def toggle_arm(self):
        if self.state != "IDLE":
            self.say("Arm/disarm only works on the ground (state IDLE).")
            return
        if self.armed:
            self.armed = False
            self.say("DISARMED.")
            return
        problems = self.preflight_problems()
        if problems:
            self.say("Cannot arm: " + "; ".join(problems) + ".")
            return
        self.armed = True
        self.armed_at = time.perf_counter()
        self.say("ARMED. Press T to take off, A to disarm.")

    def request_takeoff(self):
        if self.state != "IDLE":
            self.say("T ignored: not on the ground in IDLE.")
            return
        if not self.armed:
            self.say("Press A to arm first, then T.")
            return
        problems = self.preflight_problems()
        if problems:
            self.say("Cannot take off: " + "; ".join(problems) + ".")
            return
        # A new take-off clears earlier stop requests.  This happens here, in
        # the keyboard thread, so an L or E pressed after this T is never lost.
        self.land_event.clear()
        self.emergency_event.clear()
        self.raw_land_sent = False
        self.takeoff_event.set()

    def request_land(self):
        if self.state in FLYING_STATES or self.airborne:
            if not self.land_event.is_set():
                self.land_requested_at = time.perf_counter()
                self.raw_land_sent = False
            self.land_event.set()
            try:
                self.tello.send_rc_control(0, 0, 0, 0)
            except Exception:
                pass
            self.say("LAND requested.")
        else:
            # Not in a flight sequence.  L still always means "land": send it
            # anyway, in case the drone is in the air and this script lost track.
            self.takeoff_event.clear()
            self.land_event.set()            # also stops a take-off just requested
            self.armed = False
            try:
                if self.connected:
                    self.tello.send_rc_control(0, 0, 0, 0)
                    self.tello.send_command_without_return("land")
            except Exception:
                pass
            self.say("LAND sent (no flight in progress). Disarmed.")

    def emergency(self):
        self.emergency_event.set()
        self.armed = False
        self.takeoff_event.clear()
        try:
            if self.tello is not None:
                self.tello.emergency()
        except Exception as exc:
            self.say(f"[WARN] emergency command: {exc}")
        self.airborne = False
        self.say("EMERGENCY: motors stopped.")

    def request_quit(self):
        self.quit_event.set()
        self.takeoff_event.clear()
        if self.state in FLYING_STATES or self.airborne:
            self.request_land()
            self.say("Quit: landing first...")

    def watchdog(self):
        """Display thread, every frame.  If a landing was asked for and the
        flight thread has not started it within a second (for example it is
        still waiting for the take-off reply), send 'land' directly."""
        if (self.land_event.is_set() and self.airborne and not self.raw_land_sent
                and self.state != "LANDING"
                and time.perf_counter() - self.land_requested_at > 1.0):
            self.raw_land_sent = True
            try:
                self.tello.send_command_without_return("land")
                self.say("LAND sent directly.")
            except Exception as exc:
                self.say(f"[WARN] direct land: {exc}")

    # ---------------- background thread ----------------

    def run(self):
        try:
            while not self.quit_event.is_set():
                if not self.connected:
                    self.connect_once()
                    continue
                self.idle_tick()
                if self.takeoff_event.is_set():
                    self.takeoff_event.clear()
                    self.fly()
                time.sleep(0.05)
        except Exception as exc:                      # never leave a drone in the air
            self.say(f"[ERROR] flight thread: {exc}")
            if self.airborne:
                self.land_sequence()
        finally:
            try:
                if self.tello is not None:
                    self.tello.send_rc_control(0, 0, 0, 0)
                    self.tello.end()
            except Exception:
                pass
            self.finished = True

    def connect_once(self):
        self.set_state("CONNECTING")
        try:
            if self.tello is None:
                self.tello = make_tello(self.args)
            self.flush_replies()
            self.tello.retry_count = 1
            self.tello.connect()
            self.tello.retry_count = 3
            self.battery = int(self.tello.get_battery())
            self._state_time = time.perf_counter()
            self.connected = True
            self.set_state("IDLE")
            self.say(f"Tello connected. Battery = {self.battery}%. Press A to arm.")
        except Exception as exc:
            self.message = ("Tello not reachable - is this Pi's Wi-Fi on the "
                            "drone's TELLO-xxxx network? Retrying...")
            print(f"[{time.strftime('%H:%M:%S')}] Tello not reachable ({exc}). Retrying...",
                  flush=True)
            self.quit_event.wait(2.0)

    def idle_tick(self):
        now = time.perf_counter()
        st = self.read_drone_state()
        if st is not None and st is not self._state_obj:
            self._state_obj = st                 # a new status packet arrived
            self._state_time = now
        if now - self._state_time > 3.0:
            self.connected = False
            self.armed = False
            self.say("Tello link lost. Reconnecting...")
            return
        if self.armed and now - self.armed_at > ARM_TIMEOUT_S:
            self.armed = False
            self.say(f"DISARMED (not used for {ARM_TIMEOUT_S} s).")

    # ---------------- ToF / altitude (Step 10) ----------------

    def get_valid_tof(self):
        try:
            value = int(self.tello.get_distance_tof())
            if TOF_MIN_VALID <= value <= TOF_MAX_VALID:
                return value
        except Exception:
            pass
        return None

    def filtered_tof(self, value):
        if value is not None:
            self.tof_buffer.append(value)
        if len(self.tof_buffer) == 0:
            return None
        return float(np.median(list(self.tof_buffer)))

    def collect_tof_reference(self):
        """Capture altitude only after a stable rolling ToF window is observed."""
        self.say("Collecting STABLE altitude reference...")
        values = []
        start = time.monotonic()
        last_print = None
        while time.monotonic() - start < 12.0:
            self.check_stop()
            v = self.get_valid_tof()
            if v is not None:
                self.tof = v
                values.append(float(v))
                values = values[-15:]
                if v != last_print:
                    print(f"ToF={v} cm  window={len(values)}/15", flush=True)
                    last_print = v
                if len(values) >= 10:
                    med = float(np.median(values))
                    spread = max(values) - min(values)
                    # Stable hover reference: tight window, plausible flight height.
                    if 60.0 <= med <= 120.0 and spread <= 6.0:
                        print(f"Stable ToF reference: median={med:.1f} cm "
                              f"spread={spread:.1f} cm", flush=True)
                        return med
            time.sleep(0.10)
        return None

    def capture_xy_target(self):
        self.say("Capturing XY hold target...")
        xs, ys, angles = [], [], []
        last_sequence = 0
        start = time.perf_counter()
        while time.perf_counter() - start < TARGET_CAPTURE_TIME:
            self.check_stop()
            self.read_drone_state()
            state = self.vision_state()
            if time.perf_counter() - state["last_detection_timestamp"] > VISION_LAND_TIMEOUT:
                self.tello.send_rc_control(0, 0, 0, 0)
                raise RuntimeError("Vision lost during position capture.")
            if (vision_is_fresh(state)
                    and state["frame_read_timestamp"] >= start
                    and state["frame_sequence"] != last_sequence):
                last_sequence = state["frame_sequence"]
                xs.append(state["x"])
                ys.append(state["y"])
                angles.append(state["angle"])
            time.sleep(0.05)
        if len(xs) < 10:
            return None
        return {"x": float(np.median(xs)), "y": float(np.median(ys)),
                "angle": float(np.median(angles)), "samples": len(xs)}

    # ---------------- one flight ----------------

    def fly(self):
        tello = self.tello
        self.set_state("TAKEOFF")           # from now on L and E are flight stops
        self.armed = False                  # the arming is used up by this flight
        self.flight_log = []
        self.end_reason = ""
        self.tof_buffer.clear()
        self.trail.clear()
        self.telemetry = {}
        LOG_DIR.mkdir(parents=True, exist_ok=True)
        self.csv_file = LOG_DIR / (
            f"fly_step10_id{self.marker}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv")

        try:
            battery = int(tello.get_battery())
            self.battery = battery
            print(f"Battery = {battery}%", flush=True)
            if battery < MIN_BATTERY:
                raise FlightStop("Battery too low.")

            # Fresh observation required right before take-off.
            if not vision_is_fresh(self.vision_state()):
                raise FlightStop(f"Fresh ID{self.marker} observation required before takeoff.")

            self.check_stop()               # L or E pressed since T
            self.say("Taking off...")
            self.flush_replies()
            self.airborne = True            # from here on, every exit path lands
            tello.takeoff()
            tello.send_rc_control(0, 0, 0, 0)
            self.check_stop()

            self.set_state("STABILIZE")
            self.say(f"Stabilizing {STABILIZE_TIME:.1f}s...")
            self.pause(STABILIZE_TIME)

            # ---- altitude target ----
            self.set_state("ALT REF")
            target_tof = self.collect_tof_reference()
            if target_tof is None:
                raise FlightStop("Cannot establish altitude reference.")
            self.tof_buffer.clear()
            print(f"Z TARGET = {target_tof:.1f} cm", flush=True)
            self.telemetry = {"target_tof": target_tof}

            # Verify reference remains representative before locking XY origin.
            self.pause(0.8)
            verify_tof = self.get_valid_tof()
            if verify_tof is None or abs(float(verify_tof) - target_tof) > 8.0:
                raise FlightStop("Altitude reference moved before XY lock: "
                                 f"target={target_tof:.1f}, now={verify_tof}")
            print(f"Z reference verified: {verify_tof} cm", flush=True)

            # ---- XY target ----
            self.set_state("CAPTURE")
            target = self.capture_xy_target()
            if target is None:
                raise FlightStop("Unable to establish XY target.")
            target_x = target["x"] + TARGET_DX_M
            target_y = target["y"] + TARGET_DY_M
            reference_angle = target["angle"]
            print("=" * 60, flush=True)
            print(f"XY TARGET: X = {target_x:.3f} m  Y = {target_y:.3f} m  | "
                  f"yaw reference = {reference_angle:+.1f} deg | "
                  f"samples = {target['samples']}", flush=True)
            print("=" * 60, flush=True)
            if not arena_safe(target_x, target_y):
                raise FlightStop("Captured target too close to arena boundary.")

            # ---- mission ----
            self.set_state("MISSION")
            self.say("Mission started. L or SPACE lands.")
            self.mission(target_x, target_y, reference_angle, target_tof)

        except FlightStop as stop:
            self.say(f"[STOP] {stop}")
        except Exception as exc:
            self.say(f"[ERROR] {exc}")
        finally:
            self.land_sequence()

    def mission(self, target_x, target_y, reference_angle, target_tof):
        tello = self.tello
        hold_start = time.perf_counter()
        nav = PulseNavigator(target_x, target_y, hold_start)

        last_control = 0.0
        last_z_update = -999.0
        last_print = -999.0
        rc_z = 0
        tof_raw = None
        tof_value = None
        z_error = None
        z_state = "INIT"

        def row(now, state, vision_age, **kw):
            base = {
                "time_s": now - hold_start,
                "x_m": state["x"], "y_m": state["y"],
                "target_x_m": target_x, "target_y_m": target_y,
                "error_x_m": None, "error_y_m": None, "error_distance_m": None,
                "vx_des_mps": 0.0, "vy_des_mps": 0.0,
                "rc_lr": 0, "rc_fb": 0, "rc_z": 0,
                "xy_state": "", "aruco_angle_deg": state["angle"],
                "reference_angle_deg": reference_angle,
                "vision_fps": state["fps"], "vision_source": state["source"],
                "vision_age_s": vision_age, "tof_raw_cm": tof_raw,
                "tof_filtered_cm": tof_value, "target_tof_cm": target_tof,
                "z_error_cm": z_error, "z_state": z_state,
            }
            base.update(kw)
            self.flight_log.append(base)
            self.telemetry = dict(base, target_tof=target_tof,
                                  elapsed=now - hold_start)
            return base

        while time.perf_counter() - hold_start < HOLD_TIME:

            if self.land_event.is_set() or self.emergency_event.is_set():
                break

            now = time.perf_counter()

            # ---------------- 10 Hz control ----------------
            if now - last_control < CONTROL_DT:
                time.sleep(0.005)
                continue
            last_control = now

            # ---------------- vision ----------------
            state = self.vision_state()
            vision_age = now - state["frame_read_timestamp"]
            vision_lost = not vision_is_fresh(state)

            if vision_lost and now - state["last_detection_timestamp"] > VISION_LAND_TIMEOUT:
                tello.send_rc_control(0, 0, 0, 0)
                row(now, state, vision_age, xy_state="VISION_LAND")
                self.say("[SAFETY] Vision lost. Landing.")
                break

            # ---------------- Z control ----------------
            if now - last_z_update >= Z_UPDATE_INTERVAL:
                last_z_update = now
                tof_raw = self.get_valid_tof()
                tof_value = self.filtered_tof(tof_raw)
                rc_z, z_error, z_state = calculate_z_control(tof_value, target_tof)
                if tof_raw is not None:
                    self.tof = tof_raw

            if vision_lost:
                # Stop XY this cycle; keep independently updated Z control active.
                tello.send_rc_control(0, 0, int(rc_z), 0)
                row(now, state, vision_age, rc_z=rc_z, xy_state="VISION_HOLD")
                continue

            x = state["x"]
            y = state["y"]
            self.trail.append((x, y))

            # ---------------- arena boundary ----------------
            if not arena_safe(x, y):
                self.say("[SAFETY] Arena boundary margin exceeded.")
                row(now, state, vision_age,
                    error_x_m=target_x - x, error_y_m=target_y - y,
                    error_distance_m=float(np.hypot(target_x - x, target_y - y)),
                    xy_state="ARENA_FAILSAFE")
                break

            # ---------------- XY control ----------------
            (rc_lr, rc_fb, ex, ey, distance_error,
             vx_des, vy_des, xy_state) = nav.update(now, x, y)

            # ---------------- large error failsafe ----------------
            if distance_error > MAX_POSITION_ERROR_M:
                self.end_reason = nav.reason
                self.say(f"[SAFETY] Position error {distance_error:.2f} m "
                         f"({nav.reason}).")
                row(now, state, vision_age,
                    error_x_m=ex, error_y_m=ey, error_distance_m=distance_error,
                    vx_des_mps=vx_des, vy_des_mps=vy_des,
                    xy_state="ERROR_FAILSAFE")
                break

            # ---------------- send combined RC ----------------
            tello.send_rc_control(int(rc_lr), int(rc_fb), int(rc_z), 0)

            row(now, state, vision_age,
                error_x_m=ex, error_y_m=ey, error_distance_m=distance_error,
                vx_des_mps=vx_des, vy_des_mps=vy_des,
                rc_lr=rc_lr, rc_fb=rc_fb, rc_z=rc_z, xy_state=xy_state)

            if now - last_print >= 0.50:
                last_print = now
                print(f"X={x:.3f} Y={y:.3f} | EX={ex*100:+5.1f}cm EY={ey*100:+5.1f}cm"
                      f" | E={distance_error*100:5.1f}cm | LR={rc_lr:+3d} FB={rc_fb:+3d} "
                      f"Z={rc_z:+3d} | {xy_state} | FPS={state['fps']:.1f}", flush=True)

    def land_sequence(self):
        tello = self.tello
        self.set_state("LANDING")
        try:
            tello.send_rc_control(0, 0, 0, 0)
        except Exception as exc:
            print("[WARN] Stop RC:", exc, flush=True)

        if self.emergency_event.is_set():
            # Repeat the motor stop: covers E pressed in the instant before
            # the take-off command reached the drone.
            try:
                tello.emergency()
            except Exception as exc:
                print("[WARN] emergency:", exc, flush=True)
        elif self.airborne:
            time.sleep(0.5)
            print("Landing...", flush=True)
            self.flush_replies()
            try:
                tello.land()
            except Exception as exc:
                # No "ok" from the drone.  Usual cause: it is already on the
                # ground (a direct 'land' got there first).  Send once more in
                # case it is not.
                print(f"[NOTE] The drone did not confirm 'land' ({exc}). "
                      "If it is still flying press L again, or E.", flush=True)
                try:
                    tello.send_command_without_return("land")
                except Exception:
                    pass
        self.airborne = False

        saved = ""
        if self.flight_log:
            try:
                with open(self.csv_file, "w", newline="") as f:
                    writer = csv.DictWriter(f, fieldnames=list(self.flight_log[0].keys()))
                    writer.writeheader()
                    writer.writerows(self.flight_log)
                saved = f" Log: {self.csv_file.name}"
                self.print_summary()
            except Exception as exc:
                print("[WARN] CSV:", exc, flush=True)

        result = self.result_text()
        was_emergency = self.emergency_event.is_set()
        self.armed = False
        self.takeoff_event.clear()
        self.land_event.clear()
        self.emergency_event.clear()
        self.set_state("IDLE")
        if was_emergency:
            self.say(f"EMERGENCY stop done - check the drone.{saved}  A arms again.")
        else:
            self.say(f"Landed. {result}.{saved}  A arms again.")

    def result_text(self):
        """How the last flight ended, for the message bar."""
        last = self.flight_log[-1]["xy_state"] if self.flight_log else "no mission flown"
        if self.end_reason:
            last += f" ({self.end_reason})"
        return f"Last state: {last}"

    def status_lines(self):
        """Extra rows for the status panel (used by scripts built on this one)."""
        return []

    def print_summary(self):
        log = self.flight_log
        errors = np.array([r["error_distance_m"] for r in log
                           if r["error_distance_m"] is not None], dtype=float)
        ex = np.array([r["error_x_m"] for r in log if r["error_x_m"] is not None], dtype=float)
        ey = np.array([r["error_y_m"] for r in log if r["error_y_m"] is not None], dtype=float)
        fps = np.array([r["vision_fps"] for r in log if r["vision_fps"] > 0], dtype=float)
        ang = np.array([r["aruco_angle_deg"] for r in log
                        if r["aruco_angle_deg"] is not None], dtype=float)
        print()
        print("=" * 76)
        print(f" FLIGHT RESULT  -  marker ID{self.marker}")
        print("=" * 76)
        print(f"Target X,Y = ({log[0]['target_x_m']:.3f}, {log[0]['target_y_m']:.3f}) m")
        if len(errors):
            print(f"Mean position error : {np.mean(errors)*100:.2f} cm")
            print(f"Median error        : {np.median(errors)*100:.2f} cm")
            print(f"95th percentile     : {np.percentile(errors, 95)*100:.2f} cm")
            print(f"Maximum error       : {np.max(errors)*100:.2f} cm")
            print(f"Mean |X error|      : {np.mean(np.abs(ex))*100:.2f} cm")
            print(f"Mean |Y error|      : {np.mean(np.abs(ey))*100:.2f} cm")
        if len(fps):
            print(f"Median vision FPS   : {np.median(fps):.1f}")
        if len(ang):
            print(f"Yaw median          : {np.median(ang):+.2f} deg")
            print(f"Yaw min/max         : {np.min(ang):+.2f} / {np.max(ang):+.2f} deg")
        print("CSV:")
        print(self.csv_file, flush=True)


# ============================================================
# DISPLAY
# ============================================================

WHITE = (255, 255, 255)
GREY = (180, 180, 180)
GREEN = (80, 220, 80)
ORANGE = (0, 165, 255)
YELLOW = (0, 220, 255)
RED = (60, 60, 255)
CYAN = (255, 220, 0)
FONT = cv2.FONT_HERSHEY_SIMPLEX
CANVAS_W, CANVAS_H = 1280, 720
PANEL_W = 300                 # status panel width (top-left corner)


def text(img, s, org, color=WHITE, scale=0.55, thick=1):
    cv2.putText(img, s, org, FONT, scale, color, thick, cv2.LINE_AA)


def shade(img, x0, y0, x1, y1, keep=0.30):
    """Darken a rectangle so text on it stays readable."""
    x0, y0 = max(0, x0), max(0, y0)
    x1, y1 = min(img.shape[1], x1), min(img.shape[0], y1)
    if x1 > x0 and y1 > y0:
        roi = img[y0:y1, x0:x1]
        roi[:] = (roi * keep).astype(np.uint8)


class Hud:

    def __init__(self, flight, vision):
        self.flight = flight
        self.vision = vision
        self._hash = None
        self._Hinv = None
        self._sx = self._sy = 1.0

    # arena metres -> picture pixels
    def to_pixel(self, x, y, on_video):
        if on_video and self._Hinv is not None:
            p = np.array([[[x / ARENA_WIDTH_M * (WARP_W - 1),
                            y / ARENA_HEIGHT_M * (WARP_H - 1)]]], dtype=np.float32)
            q = cv2.perspectiveTransform(p, self._Hinv)[0, 0]
            return int(round(q[0] * self._sx)), int(round(q[1] * self._sy))
        size = 600
        ox, oy = (CANVAS_W - size) // 2 + 100, (CANVAS_H - size) // 2 - 16
        return (int(ox + x / ARENA_WIDTH_M * size), int(oy + y / ARENA_HEIGHT_M * size))

    def background(self):
        """The video picture, or a drawn arena map if no video is arriving."""
        info = self.vision.info
        if info is not None and info.get("h_hash") != self._hash:
            self._hash = info.get("h_hash")
            self._Hinv = np.linalg.inv(np.array(info["H"], dtype=float).reshape(3, 3))
        image, age = self.vision.get_image()
        if image is not None and age is not None and age < 1.0 and info is not None:
            img = image
            if img.shape[1] != CANVAS_W or img.shape[0] != CANVAS_H:
                img = cv2.resize(img, (CANVAS_W, CANVAS_H))
            else:
                img = img.copy()
            self._sx = CANVAS_W / float(info["frame_w"])
            self._sy = CANVAS_H / float(info["frame_h"])
            return img, True

        img = np.full((CANVAS_H, CANVAS_W, 3), (38, 36, 34), np.uint8)
        a = self.to_pixel(0, 0, False)
        b = self.to_pixel(ARENA_WIDTH_M, ARENA_HEIGHT_M, False)
        cv2.rectangle(img, a, b, (70, 68, 64), -1)
        cv2.rectangle(img, a, b, (200, 200, 200), 2)
        text(img, "ARENA MAP  (no video from the camera host)", (a[0], a[1] - 10),
             GREY, 0.5)
        for mid, m in self.vision.markers().items():
            p = self.to_pixel(m["x"], m["y"], False)
            mine = (mid == self.flight.marker)
            cv2.circle(img, p, 9, CYAN if mine else GREEN, -1 if mine else 2)
            text(img, f"ID {mid}", (p[0] + 20, p[1] + 5), CYAN if mine else GREEN, 0.5)
        return img, False

    def render(self):
        f = self.flight
        tm = f.telemetry or {}
        now = time.perf_counter()
        img, on_video = self.background()
        state = f.vision_state()
        fresh = vision_is_fresh(state)
        link_ok = self.vision.link_age() <= VISION_HOLD_TIMEOUT

        # ---- arena safety margin ----
        m = ARENA_MARGIN_M
        corners = [self.to_pixel(m, m, on_video),
                   self.to_pixel(ARENA_WIDTH_M - m, m, on_video),
                   self.to_pixel(ARENA_WIDTH_M - m, ARENA_HEIGHT_M - m, on_video),
                   self.to_pixel(m, ARENA_HEIGHT_M - m, on_video)]
        cv2.polylines(img, [np.array(corners, np.int32)], True, YELLOW, 1, cv2.LINE_AA)

        # ---- flown path, target, own marker ----
        trail = list(f.trail)
        if len(trail) > 1:
            pts = np.array([self.to_pixel(x, y, on_video) for x, y in trail], np.int32)
            cv2.polylines(img, [pts], False, CYAN, 1, cv2.LINE_AA)
        if tm.get("target_x_m") is not None and f.state in ("MISSION", "LANDING", "IDLE"):
            tx, ty = tm["target_x_m"], tm["target_y_m"]
            p = self.to_pixel(tx, ty, on_video)
            r = max(6, abs(self.to_pixel(tx + XY_DEADBAND_M, ty, on_video)[0] - p[0]))
            cv2.circle(img, p, r, RED, 1, cv2.LINE_AA)
            cv2.drawMarker(img, p, RED, cv2.MARKER_CROSS, 22, 2, cv2.LINE_AA)
            text(img, "TARGET", (p[0] - 30, p[1] + r + 18), RED, 0.5, 1)
        if fresh:
            if on_video and state["pts"] is not None:
                pts = (state["pts"] * [self._sx, self._sy]).astype(np.int32)
                cv2.polylines(img, [pts], True, CYAN, 3, cv2.LINE_AA)
            elif not on_video:
                cv2.circle(img, self.to_pixel(state["x"], state["y"], False), 14, CYAN, 2)

        # ---- status panel (top-left corner) ----
        if f.state == "IDLE" and f.armed:
            badge, colour = "ARMED", ORANGE
        elif f.state == "IDLE":
            badge, colour = "IDLE", GREY
        elif f.state == "CONNECTING":
            badge, colour = "NO TELLO", RED
        elif f.state == "LANDING":
            badge, colour = "LANDING", YELLOW
        else:
            badge, colour = f.state, GREEN
        if f.emergency_event.is_set() and f.state != "IDLE":
            badge, colour = "EMERGENCY", RED

        if not link_ok:
            vis, vis_col = "NO CAMERA HOST", RED
        elif not fresh:
            vis, vis_col = f"ID{f.marker} NOT SEEN", RED
        else:
            age_ms = (now - state["frame_read_timestamp"]) * 1000
            vis, vis_col = f"OK {age_ms:3.0f} ms {state['fps']:.0f} fps", GREEN
        if self.vision.simulated:
            vis += " SIM"

        batt = "--" if f.battery is None else f"{f.battery} %"
        batt_col = RED if (f.battery is not None and f.battery < MIN_BATTERY) else WHITE
        tello = ("sim, " if f.args.sim else "") + ("connected" if f.connected
                                                    else "NOT CONNECTED")
        lines = [
            ("TELLO", tello, WHITE if f.connected else RED),
            ("BATTERY", batt, batt_col),
            ("VISION", vis, vis_col),
            ("HEIGHT", "--" if f.tof is None else f"{f.tof} cm", WHITE),
            ("X , Y", f"{state['x']:.3f} , {state['y']:.3f} m" if fresh else "--", WHITE),
            ("YAW", f"{int(round(state['angle'])):+d} deg" if fresh else "--", WHITE),
        ]
        if f.state == "MISSION":
            target_tof = tm.get("target_tof")
            if target_tof is not None:
                lines[3] = ("HEIGHT", f"{f.tof} cm -> {target_tof:.0f}  {tm.get('z_state', '')}",
                            WHITE)
            if tm.get("error_x_m") is not None:
                lines += [
                    ("TARGET", f"{tm['target_x_m']:.3f} , {tm['target_y_m']:.3f} m", WHITE),
                    ("ERROR", f"{tm['error_x_m']*100:+.1f} , {tm['error_y_m']*100:+.1f} cm",
                     WHITE),
                    ("RC", f"LR {tm['rc_lr']:+d}  FB {tm['rc_fb']:+d}  Z {tm['rc_z']:+d}",
                     WHITE),
                ]
            lines += [
                ("NAV", str(tm.get("xy_state", "")), YELLOW),
                ("TIME", f"{tm.get('elapsed', 0.0):.1f} / {HOLD_TIME:.0f} s", WHITE),
            ]
        lines += f.status_lines()

        x0, y0, w, lh = 8, 8, PANEL_W, 24
        h = 86 + lh * len(lines)
        shade(img, x0, y0, x0 + w, y0 + h)
        text(img, f"DRONE ID {f.marker}", (x0 + 12, y0 + 28), WHITE, 0.75, 2)
        (bw, _), _ = cv2.getTextSize(badge, FONT, 0.65, 2)
        cv2.rectangle(img, (x0 + 10, y0 + 40), (x0 + bw + 30, y0 + 70), colour, -1)
        text(img, badge, (x0 + 20, y0 + 62), (20, 20, 20), 0.65, 2)
        y = y0 + 96
        for label, value, col in lines:
            text(img, label, (x0 + 12, y), GREY, 0.45)
            text(img, value, (x0 + 92, y), col, 0.5)
            y += lh
        msg = f.message

        # ---- bottom bar: message + keys ----
        shade(img, 0, CANVAS_H - 62, CANVAS_W, CANVAS_H)
        text(img, msg[:150], (14, CANVAS_H - 40), WHITE, 0.52)
        text(img, "A arm/disarm    T take off    L or SPACE land    "
                  "E EMERGENCY motor stop    Q quit",
             (14, CANVAS_H - 14), GREY, 0.52)

        if not fresh and f.state in ("TAKEOFF", "STABILIZE", "ALT REF", "CAPTURE", "MISSION"):
            text(img, "NO VISION", (CANVAS_W // 2 - 150, CANVAS_H // 2), RED, 1.8, 4)
        return img


def window_key(code):
    """A key press in the video window -> one character, or None.

    Only plain keys count.  Arrow and function keys are ignored: cut down to
    one byte (the usual `waitKey() & 0xFF`) the arrows would read as the
    letters Q, R, S and T - quit and take-off."""
    if code is None or code < 0:
        return None
    code &= 0xFFFF                 # drop modifier bits (NumLock etc.) some builds add
    if 0 < code < 128:
        return chr(code)
    return None


class TerminalKeys:
    """Single key presses from the terminal, without Enter."""

    def __init__(self):
        self.fd = None
        self.old = None
        try:
            import termios
            import tty
            if sys.stdin.isatty():
                self.fd = sys.stdin.fileno()
                self.old = termios.tcgetattr(self.fd)
                tty.setcbreak(self.fd)
                atexit.register(self.restore)
        except Exception:
            self.fd = None

    def poll(self):
        if self.fd is None:
            return None
        try:
            ready, _, _ = select.select([self.fd], [], [], 0)
            if ready:
                data = os.read(self.fd, 32).decode(errors="ignore")
                # Arrow / function keys arrive as ESC sequences ("ESC [ A").
                # Drop them whole, or the letter inside would act as a key.
                if data and not data.startswith("\x1b"):
                    return data[0]
        except Exception:
            pass
        return None

    def restore(self):
        if self.fd is not None and self.old is not None:
            try:
                import termios
                termios.tcsetattr(self.fd, termios.TCSADRAIN, self.old)
            except Exception:
                pass
            self.old = None


# ============================================================
# MAIN
# ============================================================

def parse_args(argv=None, description=None):
    ap = argparse.ArgumentParser(
        description=description or "Step 10 flight with shared overhead vision, "
                                   "live display and keyboard control.")
    ap.add_argument("--marker", type=int, default=1,
                    help="ArUco ID on the drone this Pi flies (default 1)")
    ap.add_argument("--tello-ip", default="192.168.10.1",
                    help="Tello address (default 192.168.10.1 = direct Wi-Fi)")
    ap.add_argument("--port", type=int, default=POSE_PORT,
                    help="UDP port of the camera host's pose packets (default 9870)")
    ap.add_argument("--sim", action="store_true",
                    help="no drone: use a pretend Tello (bench test)")
    ap.add_argument("--no-display", action="store_true",
                    help="no window: status and keys in the terminal only")
    ap.add_argument("--no-video", action="store_true",
                    help="do not fetch the video; draw an arena map instead")
    ap.add_argument("--display-scale", type=float, default=1.0,
                    help="window size factor, e.g. 0.6 over a slow remote desktop")
    return ap.parse_args(argv)


def main(argv=None, flight_class=None, title="FLY STEP 10", description=None):
    """flight_class, title and description let observe_flight.py reuse this
    window, keyboard and landing code with a different flight."""
    args = parse_args(argv, description)

    use_window = not args.no_display
    if use_window and not os.environ.get("DISPLAY"):
        print("[INFO] No screen found (DISPLAY is not set): running without a "
              "window. Status and keys are in this terminal; the picture is on "
              "the camera host's web page.")
        use_window = False

    try:
        vision = VisionClient(port=args.port,
                              video=use_window and not args.no_video).start()
    except RuntimeError as exc:
        raise SystemExit(f"[ERROR] {exc}")

    flight = (flight_class or Flight)(args, vision)
    hud = Hud(flight, vision)
    keys = TerminalKeys()

    print("=" * 72)
    print(f" {title}  -  drone marker ID{args.marker}"
          + ("   ***  PRETEND TELLO (--sim)  ***" if args.sim else ""))
    print("=" * 72)
    print("Keys:  A arm/disarm | T take off | L or SPACE land | "
          "E EMERGENCY motor stop | Q quit")
    print()

    thread = threading.Thread(target=flight.run, daemon=True)
    thread.start()

    if use_window:
        cv2.namedWindow(WINDOW, cv2.WINDOW_NORMAL | cv2.WINDOW_KEEPRATIO
                        | cv2.WINDOW_GUI_NORMAL)
        cv2.resizeWindow(WINDOW, int(CANVAS_W * args.display_scale),
                         int(CANVAS_H * args.display_scale))

    last_status = 0.0
    shown = False
    draw_error = False
    try:
        while not flight.finished:
            try:
                key = keys.poll()
                if use_window:
                    try:
                        picture = hud.render()
                    except Exception as exc:        # a drawing error must not end a flight
                        if not draw_error:
                            print(f"[WARN] display: {exc}", flush=True)
                            draw_error = True
                        picture = np.zeros((CANVAS_H, CANVAS_W, 3), np.uint8)
                        text(picture, "display error - keys still work: "
                                      "L land, E emergency, Q quit", (30, 60), WHITE, 0.8, 2)
                    cv2.imshow(WINDOW, picture)
                    k = window_key(cv2.waitKeyEx(25))
                    if k is not None and key is None:
                        key = k
                    if shown and cv2.getWindowProperty(WINDOW, cv2.WND_PROP_VISIBLE) < 1:
                        key = "q"                   # window closed with the mouse
                    shown = True
                else:
                    time.sleep(0.04)
                    now = time.perf_counter()
                    if now - last_status >= 2.0 and flight.state != "MISSION":
                        last_status = now
                        s = flight.vision_state()
                        seen = (f"ID{args.marker} X={s['x']:.3f} Y={s['y']:.3f}"
                                if vision_is_fresh(s) else f"ID{args.marker} NOT SEEN")
                        print(f"[{time.strftime('%H:%M:%S')}] "
                              f"{'ARMED' if flight.armed and flight.state == 'IDLE' else flight.state} | "
                              f"batt {flight.battery}% | {seen}", flush=True)
                if key:
                    flight.on_key(key)
                flight.watchdog()
            except KeyboardInterrupt:
                print("\n[STOP] Ctrl+C")
                flight.request_quit()
            # On the ground there is nothing to wait for once quit is asked.
            if (flight.quit_event.is_set() and not flight.airborne
                    and flight.state in ("IDLE", "CONNECTING")):
                break
    finally:
        flying = flight.airborne or flight.state in FLYING_STATES
        flight.request_quit()
        thread.join(timeout=25.0 if flying else 1.0)
        keys.restore()
        vision.stop()
        if use_window:
            cv2.destroyAllWindows()
        print("Program finished.")


if __name__ == "__main__":
    main()
