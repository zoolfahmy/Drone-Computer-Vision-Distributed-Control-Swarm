import cv2

# ==========================================
# PRACTICAL 02
# Real-Time ArUco Detection
# ==========================================

CAMERA_ID = 0

# -----------------------------
# ArUco Dictionary
# -----------------------------

aruco_dict = cv2.aruco.getPredefinedDictionary(
    cv2.aruco.DICT_4X4_50
)

parameters = cv2.aruco.DetectorParameters()

detector = cv2.aruco.ArucoDetector(
    aruco_dict,
    parameters
)

# -----------------------------
# Open USB Camera
# -----------------------------

cap = cv2.VideoCapture(CAMERA_ID)

if not cap.isOpened():
    print("ERROR: Camera cannot be opened")
    exit()

cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)

print("====================================")
print(" PRACTICAL 02 - ArUco Tracking")
print("====================================")
print("Camera ready")
print("Press Q to exit")
print()

while True:

    ret, frame = cap.read()

    if not ret:
        print("ERROR: Cannot read frame")
        break

    # ---------------------------------
    # Detect ArUco
    # ---------------------------------

    gray = cv2.cvtColor(
        frame,
        cv2.COLOR_BGR2GRAY
    )

    corners, ids, rejected = detector.detectMarkers(gray)

    # ---------------------------------
    # Marker detected
    # ---------------------------------

    if ids is not None:

        cv2.aruco.drawDetectedMarkers(
            frame,
            corners,
            ids
        )

        for marker_corner, marker_id in zip(corners, ids.flatten()):

            points = marker_corner.reshape((4, 2))

            top_left = points[0]
            top_right = points[1]
            bottom_right = points[2]
            bottom_left = points[3]

            # Calculate marker centre
            center_x = int(
                (
                    top_left[0]
                    + top_right[0]
                    + bottom_right[0]
                    + bottom_left[0]
                ) / 4
            )

            center_y = int(
                (
                    top_left[1]
                    + top_right[1]
                    + bottom_right[1]
                    + bottom_left[1]
                ) / 4
            )

            # Centre point
            cv2.circle(
                frame,
                (center_x, center_y),
                7,
                (0, 0, 255),
                -1
            )

            # Text
            text = (
                f"ID:{marker_id} "
                f"X:{center_x} "
                f"Y:{center_y}"
            )

            cv2.putText(
                frame,
                text,
                (center_x + 10, center_y - 10),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.7,
                (0, 255, 0),
                2
            )

    # ---------------------------------
    # Camera centre
    # ---------------------------------

    height, width = frame.shape[:2]

    camera_center = (
        width // 2,
        height // 2
    )

    cv2.drawMarker(
        frame,
        camera_center,
        (255, 0, 0),
        cv2.MARKER_CROSS,
        30,
        2
    )

    cv2.putText(
        frame,
        f"Camera Center: {camera_center}",
        (20, 35),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.7,
        (255, 0, 0),
        2
    )

    # ---------------------------------
    # Display
    # ---------------------------------

    cv2.imshow(
        "Practical 02 - ArUco Position Tracking",
        frame
    )

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()

print("ArUco tracking stopped")
