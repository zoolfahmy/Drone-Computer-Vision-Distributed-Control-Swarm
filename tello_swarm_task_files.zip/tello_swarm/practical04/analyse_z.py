# Task 6: analyse an altitude hold log
import csv
import statistics as st

f = "logs/p04a3_relative_z_hold_20260929_110955.csv"   # replace with your log

rows = list(csv.DictReader(open(f)))

e = [abs(float(r["error_cm"])) for r in rows if r["error_cm"]]

print("samples      :", len(e))
print("target (cm)  :", rows[0]["target_tof_cm"])
print("mean |error| :", round(st.mean(e), 2), "cm")
print("max  |error| :", max(e), "cm")
