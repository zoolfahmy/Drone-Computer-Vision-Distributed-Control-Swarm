#!/usr/bin/env python3
"""P04-B1 hardware preflight: telemetry only, never takeoff/RC."""
import sys
import time
from datetime import datetime
from djitellopy import Tello

MIN_BATTERY = 50
SAMPLES = 10
INTERVAL_S = 0.5

def safe_call(label, fn):
    try:
        value = fn()
        print(f"{label}: {value}")
        return value
    except Exception as exc:
        print(f"{label}: ERROR: {exc}")
        return None

print("=" * 64)
print("TELLO HARDWARE PREFLIGHT — NO TAKEOFF / NO RC")
print(datetime.now().isoformat(timespec="seconds"))
print("=" * 64)
tello = Tello()
connected = False
try:
    print("Connecting to Tello SDK...")
    tello.connect()
    connected = True
    battery = safe_call("Battery %", tello.get_battery)
    safe_call("Temperature C", tello.get_temperature)
    safe_call("Flight time s", tello.get_flight_time)
    safe_call("Barometer cm", tello.get_barometer)
    safe_call("Height cm", tello.get_height)
    if battery is not None and battery < MIN_BATTERY:
        print(f"FAIL: battery {battery}% < {MIN_BATTERY}%")
        sys.exit(2)

    print("\nTelemetry samples:")
    valid_tof = []
    for i in range(1, SAMPLES + 1):
        tof = safe_call(f"ToF[{i:02d}] cm", tello.get_distance_tof)
        if isinstance(tof, (int, float)) and 1 <= tof <= 500:
            valid_tof.append(float(tof))
        time.sleep(INTERVAL_S)

    if valid_tof:
        print(f"ToF valid: {len(valid_tof)}/{SAMPLES}; "
              f"range={min(valid_tof):.1f}-{max(valid_tof):.1f} cm")
    else:
        print("WARN: no valid ToF samples")
    print("\nPASS: SDK/telemetry preflight completed.")
    print("No takeoff or RC command was issued.")
finally:
    if connected:
        try:
            tello.end()
        except Exception as exc:
            print(f"Disconnect warning: {exc}")
    print("Tello SDK session closed.")
