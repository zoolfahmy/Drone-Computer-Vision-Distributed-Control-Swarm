# Task 1D: Canny edge detection
# Objective: find edges from changes of brightness, and see the effect
#            of the two thresholds and of blurring first
import cv2
import numpy as np

WINDOW = "Task 1D - Canny edges"
FONT = cv2.FONT_HERSHEY_SIMPLEX

cap = cv2.VideoCapture(0)

if not cap.isOpened():
    print("ERROR: Camera /dev/video0 cannot be opened")
    exit()

cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)

cv2.namedWindow(WINDOW)
cv2.createTrackbar("Low", WINDOW, 50, 255, lambda value: None)
cv2.createTrackbar("High", WINDOW, 150, 255, lambda value: None)

print("Task 1D - Canny edges")
print("B = Blur on/off   P = Print thresholds   S = Save image   Q = Quit")

use_blur = True

while True:

    ret, frame = cap.read()

    if not ret:
        print("ERROR: Cannot read camera frame")
        break

    # ---------- process ----------
    low = cv2.getTrackbarPos("Low", WINDOW)
    high = cv2.getTrackbarPos("High", WINDOW)

    # Edges are found in brightness, so colour is removed first
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    # A light blur removes camera noise that would become false edges
    if use_blur:
        gray = cv2.GaussianBlur(gray, (5, 5), 0)

    # A pixel is an edge when the brightness change is above High.
    # Between Low and High it is kept only if it touches a strong edge.
    edges = cv2.Canny(gray, low, high)

    edge_percent = 100.0 * cv2.countNonZero(edges) / edges.size

    # ---------- display ----------
    size = (640, 360)
    view = np.hstack([cv2.resize(gray, size), cv2.resize(edges, size)])
    view = cv2.cvtColor(view, cv2.COLOR_GRAY2BGR)
    cv2.putText(view, "Grayscale" + (" + blur" if use_blur else ""), (8, 26),
                FONT, 0.7, (0, 255, 255), 2)
    cv2.putText(view, f"Edges  Low {low}  High {high}  {edge_percent:.1f}% white",
                (648, 26), FONT, 0.7, (0, 255, 255), 2)
    cv2.imshow(WINDOW, view)

    key = cv2.waitKey(1) & 0xFF

    if key == ord('q'):
        break

    elif key == ord('b'):
        use_blur = not use_blur
        print("Blur:", "ON" if use_blur else "OFF")

    elif key == ord('p'):
        print(f"Low = {low}  High = {high}  blur = {'ON' if use_blur else 'OFF'}  "
              f"edge pixels = {edge_percent:.1f}%")

    elif key == ord('s'):
        cv2.imwrite("task1d_edges.jpg", view)
        print("Saved: task1d_edges.jpg")

cap.release()
cv2.destroyAllWindows()

print("Camera closed")
