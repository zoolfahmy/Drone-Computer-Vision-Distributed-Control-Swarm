import csv
import time
import numpy as np

from pathlib import Path
from datetime import datetime
from collections import deque
from djitellopy import Tello


# ============================================================
# P04-A3
# RELATIVE ALTITUDE HOLD + SOFT/HARD CEILING
#
# AIRBORNE TEST
# XY CONTROL = OFF
#
# Control feedback:
# Tello ToF
#
# IMPORTANT:
# All ceiling values are RELATIVE ToF thresholds.
# They are NOT yet calibrated physical altitude values.
# ============================================================


# ============================================================
# SAFETY
# ============================================================

MIN_BATTERY = 50

STABILIZE_TIME = 4.0
TEST_DURATION = 12.0

CONTROL_DT = 0.20


# ============================================================
# ToF
# ============================================================

TOF_MIN_VALID = 20
TOF_MAX_VALID = 200

FILTER_SIZE = 5

REFERENCE_SAMPLES = 15
REFERENCE_INTERVAL = 0.12


# ============================================================
# Z CONTROLLER
# ============================================================

DEADBAND_CM = 3.0

KP_Z = 0.80

MAX_RC_Z = 10
MIN_ACTIVE_RC = 4


# ============================================================
# RELATIVE CEILING
# ============================================================

# ToF increasing is treated as increasing distance from floor
# based on our previous airborne observations.
#
# These thresholds are RELATIVE sensor thresholds.

SOFT_CEILING_OFFSET = 8.0

HARD_CEILING_OFFSET = 15.0


# At soft ceiling:
# no upward command is allowed.

# At hard ceiling:
# command controlled descent.

HARD_DESCENT_RC = -8


# ============================================================
# PATHS
# ============================================================

BASE_DIR = Path(__file__).resolve().parent

LOG_DIR = BASE_DIR / "logs"
LOG_DIR.mkdir(parents=True, exist_ok=True)

timestamp = datetime.now().strftime(
    "%Y%m%d_%H%M%S"
)

CSV_FILE = (
    LOG_DIR
    / f"p04a3_relative_z_hold_{timestamp}.csv"
)


# ============================================================
# TELLO
# ============================================================

tello = Tello()

airborne = False


# ============================================================
# FILTER
# ============================================================

tof_buffer = deque(
    maxlen=FILTER_SIZE
)


def get_valid_tof():

    try:

        value = int(
            tello.get_distance_tof()
        )

        if (
            TOF_MIN_VALID
            <= value
            <= TOF_MAX_VALID
        ):
            return value

    except Exception:
        pass

    return None


def filtered_tof(new_value):

    if new_value is not None:

        tof_buffer.append(
            new_value
        )

    if len(tof_buffer) == 0:

        return None

    return float(
        np.median(
            list(tof_buffer)
        )
    )


# ============================================================
# RC LIMIT
# ============================================================

def clamp(value, low, high):

    return max(
        low,
        min(high, value)
    )


# ============================================================
# Z CONTROLLER
# ============================================================

def calculate_z_control(
    current_tof,
    target_tof
):

    if current_tof is None:

        return 0, None, "INVALID_TOF"


    # --------------------------------------------------------
    # Error definition
    #
    # target > current:
    # drone lower than target -> UP
    #
    # current > target:
    # drone higher than target -> DOWN
    # --------------------------------------------------------

    error = (
        target_tof
        -
        current_tof
    )


    soft_ceiling = (
        target_tof
        +
        SOFT_CEILING_OFFSET
    )

    hard_ceiling = (
        target_tof
        +
        HARD_CEILING_OFFSET
    )


    # ========================================================
    # HARD CEILING
    # ========================================================

    if current_tof >= hard_ceiling:

        return (
            HARD_DESCENT_RC,
            error,
            "HARD_CEILING"
        )


    # ========================================================
    # DEADBAND
    # ========================================================

    if abs(error) <= DEADBAND_CM:

        rc_z = 0

        state = "HOLD"


    else:

        rc_z = int(
            round(
                KP_Z
                *
                error
            )
        )


        # ----------------------------------------------------
        # Minimum useful command
        # ----------------------------------------------------

        if (
            rc_z > 0
            and
            rc_z < MIN_ACTIVE_RC
        ):
            rc_z = MIN_ACTIVE_RC


        elif (
            rc_z < 0
            and
            rc_z > -MIN_ACTIVE_RC
        ):
            rc_z = -MIN_ACTIVE_RC


        rc_z = int(
            clamp(
                rc_z,
                -MAX_RC_Z,
                MAX_RC_Z
            )
        )


        if rc_z > 0:

            state = "UP"

        elif rc_z < 0:

            state = "DOWN"

        else:

            state = "HOLD"


    # ========================================================
    # SOFT CEILING
    # ========================================================

    if current_tof >= soft_ceiling:

        # Never allow UP beyond soft ceiling

        if rc_z > 0:

            rc_z = 0

        if rc_z == 0:

            state = "SOFT_CEILING"

        else:

            state = "SOFT_CEILING_DOWN"


    return (
        rc_z,
        error,
        state
    )


# ============================================================
# REFERENCE
# ============================================================

def collect_reference():

    print()
    print(
        "Collecting airborne ToF reference..."
    )

    values = []

    start = time.time()


    while len(values) < REFERENCE_SAMPLES:

        tof = get_valid_tof()

        if tof is not None:

            values.append(
                tof
            )

            print(
                f"Reference "
                f"{len(values):02d}/"
                f"{REFERENCE_SAMPLES}"
                f" : {tof} cm"
            )


        if time.time() - start > 10:

            break


        time.sleep(
            REFERENCE_INTERVAL
        )


    if len(values) < 5:

        return None, values


    reference = float(
        np.median(values)
    )


    return reference, values


# ============================================================
# START
# ============================================================

print()
print("=" * 72)
print(" P04-A3 - RELATIVE ALTITUDE HOLD + CEILING")
print("=" * 72)

print()
print("XY CONTROL : OFF")
print("Z CONTROL  : ToF")
print()

print(
    f"Deadband        : ±{DEADBAND_CM:.0f} cm"
)

print(
    f"Soft ceiling    : TARGET + "
    f"{SOFT_CEILING_OFFSET:.0f} ToF-cm"
)

print(
    f"Hard ceiling    : TARGET + "
    f"{HARD_CEILING_OFFSET:.0f} ToF-cm"
)

print(
    f"Maximum RC Z    : ±{MAX_RC_Z}"
)

print()


csv_handle = None


try:

    # ========================================================
    # CONNECT
    # ========================================================

    print("Connecting to Tello...")

    tello.connect()

    battery = tello.get_battery()

    print(
        f"[OK] Battery = {battery}%"
    )


    if battery < MIN_BATTERY:

        print()
        print(
            "[BLOCKED] Battery too low."
        )

        raise SystemExit


    # ========================================================
    # CSV
    # ========================================================

    csv_handle = open(
        CSV_FILE,
        "w",
        newline=""
    )

    writer = csv.writer(
        csv_handle
    )


    writer.writerow([

        "timestamp",

        "flight_time_s",

        "tof_raw_cm",

        "tof_filtered_cm",

        "target_tof_cm",

        "error_cm",

        "rc_z",

        "state",

        "get_height_cm",

        "battery_pct"
    ])

    csv_handle.flush()


    # ========================================================
    # TAKEOFF
    # ========================================================

    print()
    print("Taking off...")

    tello.takeoff()

    airborne = True


    # No horizontal/yaw command

    tello.send_rc_control(
        0,
        0,
        0,
        0
    )


    print(
        f"Stabilizing for "
        f"{STABILIZE_TIME:.1f}s..."
    )

    time.sleep(
        STABILIZE_TIME
    )


    # ========================================================
    # REFERENCE
    # ========================================================

    target_tof, reference_values = (
        collect_reference()
    )


    if target_tof is None:

        print()
        print(
            "[ABORT] Cannot establish "
            "valid ToF reference."
        )

        raise RuntimeError(
            "Invalid airborne ToF reference"
        )


    tof_buffer.clear()


    print()
    print("=" * 60)

    print(
        f"TARGET ToF = "
        f"{target_tof:.1f} cm"
    )

    print(
        f"NORMAL BAND = "
        f"{target_tof - DEADBAND_CM:.1f}"
        f" - "
        f"{target_tof + DEADBAND_CM:.1f} cm"
    )

    print(
        f"SOFT CEILING = "
        f"{target_tof + SOFT_CEILING_OFFSET:.1f}"
    )

    print(
        f"HARD CEILING = "
        f"{target_tof + HARD_CEILING_OFFSET:.1f}"
    )

    print("=" * 60)

    print()


    # ========================================================
    # CONTROL LOOP
    # ========================================================

    flight_start = time.time()

    invalid_count = 0


    while True:

        now = time.time()

        flight_time = (
            now
            -
            flight_start
        )


        if flight_time >= TEST_DURATION:

            break


        raw_tof = get_valid_tof()

        filtered = filtered_tof(
            raw_tof
        )


        # ====================================================
        # SENSOR FAILURE
        # ====================================================

        if raw_tof is None:

            invalid_count += 1

        else:

            invalid_count = 0


        # Multiple invalid readings:
        # safest action for this test is no vertical movement.

        if invalid_count >= 3:

            rc_z = 0

            error = None

            state = "SENSOR_FAIL"

        else:

            (
                rc_z,
                error,
                state

            ) = calculate_z_control(
                filtered,
                target_tof
            )


        # ====================================================
        # COMMAND
        # ====================================================

        tello.send_rc_control(
            0,      # left/right OFF
            0,      # forward/back OFF
            rc_z,   # vertical only
            0       # yaw OFF
        )


        # ====================================================
        # TELEMETRY
        # ====================================================

        try:

            height = tello.get_height()

        except Exception:

            height = None


        try:

            battery_now = tello.get_battery()

        except Exception:

            battery_now = battery


        # ====================================================
        # LOG
        # ====================================================

        writer.writerow([

            datetime.now().isoformat(),

            f"{flight_time:.3f}",

            (
                raw_tof
                if raw_tof is not None
                else ""
            ),

            (
                f"{filtered:.2f}"
                if filtered is not None
                else ""
            ),

            f"{target_tof:.2f}",

            (
                f"{error:.2f}"
                if error is not None
                else ""
            ),

            rc_z,

            state,

            (
                height
                if height is not None
                else ""
            ),

            battery_now
        ])


        csv_handle.flush()


        # ====================================================
        # DISPLAY
        # ====================================================

        print(
            f"t={flight_time:5.2f}s"
            f"  raw={str(raw_tof):>4}"
            f"  filt="
            f"{filtered if filtered is not None else '---'}"
            f"  err="
            f"{error if error is not None else '---'}"
            f"  RCZ={rc_z:+3d}"
            f"  {state}"
        )


        time.sleep(
            CONTROL_DT
        )


    # ========================================================
    # STOP VERTICAL COMMAND
    # ========================================================

    tello.send_rc_control(
        0,
        0,
        0,
        0
    )


    time.sleep(1)


    # ========================================================
    # LAND
    # ========================================================

    print()
    print("Landing...")

    tello.land()

    airborne = False


    print()
    print("=" * 72)
    print(" P04-A3 COMPLETE")
    print("=" * 72)

    print()
    print("CSV:")
    print(CSV_FILE)


# ============================================================
# ERROR
# ============================================================

except KeyboardInterrupt:

    print()
    print("[STOP] User requested stop.")


except Exception as e:

    print()
    print("[ERROR]")
    print(e)


# ============================================================
# SAFETY CLEANUP
# ============================================================

finally:

    if airborne:

        print()
        print(
            "[SAFETY] Landing Tello..."
        )

        try:

            tello.send_rc_control(
                0,
                0,
                0,
                0
            )

            time.sleep(0.5)

            tello.land()

        except Exception as e:

            print(
                "[WARN] Landing exception:",
                e
            )


    if csv_handle is not None:

        try:

            csv_handle.close()

        except Exception:

            pass


    try:

        tello.end()

    except Exception:

        pass


    print()
    print("Program finished.")
