# Task 1B: colour masking
# Objective: keep only the pixels of one colour with an HSV range,
#            and find the range that isolates your own object
import json
from pathlib import Path

import cv2
import numpy as np

RANGE_FILE = Path(__file__).resolve().parent / "hsv_range.json"
WINDOW = "Task 1B - Colour mask"
FONT = cv2.FONT_HERSHEY_SIMPLEX

# Starting ranges: H min, H max, S min, S max, V min, V max
PRESETS = {
    "1": ("red",    [170, 10, 120, 255, 70, 255]),     # red wraps around 179 -> 0
    "2": ("green",  [40, 85, 80, 255, 60, 255]),
    "3": ("blue",   [100, 130, 120, 255, 60, 255]),
    "4": ("yellow", [20, 35, 100, 255, 100, 255]),
}
NAMES = ["H min", "H max", "S min", "S max", "V min", "V max"]
LIMITS = [179, 179, 255, 255, 255, 255]


def colour_mask(hsv, values):
    """White where the pixel is inside the HSV range, black elsewhere."""
    h_min, h_max, s_min, s_max, v_min, v_max = values
    if h_min <= h_max:
        return cv2.inRange(hsv, (h_min, s_min, v_min), (h_max, s_max, v_max))
    # H min above H max: the range passes through 179 -> 0 (red)
    upper_part = cv2.inRange(hsv, (h_min, s_min, v_min), (179, s_max, v_max))
    lower_part = cv2.inRange(hsv, (0, s_min, v_min), (h_max, s_max, v_max))
    return cv2.bitwise_or(upper_part, lower_part)


def set_sliders(values):
    for name, value in zip(NAMES, values):
        cv2.setTrackbarPos(name, WINDOW, value)


cap = cv2.VideoCapture(0)

if not cap.isOpened():
    print("ERROR: Camera /dev/video0 cannot be opened")
    exit()

cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)

cv2.namedWindow(WINDOW)
for name, limit, start in zip(NAMES, LIMITS, PRESETS["3"][1]):
    cv2.createTrackbar(name, WINDOW, start, limit, lambda value: None)

print("Task 1B - Colour mask")
print("1 = Red   2 = Green   3 = Blue   4 = Yellow")
print("P = Print range   S = Save range   Q = Quit")

while True:

    ret, frame = cap.read()

    if not ret:
        print("ERROR: Cannot read camera frame")
        break

    # ---------- process ----------
    values = [cv2.getTrackbarPos(name, WINDOW) for name in NAMES]

    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    mask = colour_mask(hsv, values)

    # Keep the original colours only where the mask is white
    result = cv2.bitwise_and(frame, frame, mask=mask)

    white_percent = 100.0 * cv2.countNonZero(mask) / mask.size

    # ---------- display ----------
    size = (426, 240)
    view = np.hstack([cv2.resize(frame, size),
                      cv2.cvtColor(cv2.resize(mask, size), cv2.COLOR_GRAY2BGR),
                      cv2.resize(result, size)])
    cv2.putText(view, "Original", (8, 24), FONT, 0.6, (0, 255, 255), 2)
    cv2.putText(view, f"Mask  {white_percent:.1f}% white", (434, 24), FONT, 0.6, (0, 255, 255), 2)
    cv2.putText(view, "Result", (860, 24), FONT, 0.6, (0, 255, 255), 2)
    cv2.imshow(WINDOW, view)

    key = cv2.waitKey(1) & 0xFF

    if key == ord('q'):
        break

    elif chr(key) in PRESETS:
        colour, preset = PRESETS[chr(key)]
        set_sliders(preset)
        print("Preset:", colour, preset)

    elif key == ord('p'):
        print("HSV range:", dict(zip(NAMES, values)), f"white = {white_percent:.1f}%")

    elif key == ord('s'):
        RANGE_FILE.write_text(json.dumps(values))
        print("Saved:", RANGE_FILE.name, values)

cap.release()
cv2.destroyAllWindows()

print("Camera closed")
