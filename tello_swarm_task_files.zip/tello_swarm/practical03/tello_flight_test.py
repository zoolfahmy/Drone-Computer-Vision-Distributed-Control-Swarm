from djitellopy import Tello
import time

# ==========================================================
# PRACTICAL 03-B
# TELLO EDU BASIC FLIGHT TEST
# Raspberry Pi 5 + DJITelloPy
# ==========================================================

MIN_BATTERY = 40
HOVER_TIME = 5

tello = Tello()
airborne = False

print("=" * 55)
print(" PRACTICAL 03-B - TELLO EDU BASIC FLIGHT TEST")
print("=" * 55)

try:
    # ------------------------------------------------------
    # 1. CONNECT
    # ------------------------------------------------------
    print("\n[1] Connecting to Tello...")

    tello.connect()

    print("[OK] Tello connected")

    # ------------------------------------------------------
    # 2. BATTERY CHECK
    # ------------------------------------------------------
    battery = tello.get_battery()

    print(f"[2] Battery: {battery}%")

    if battery < MIN_BATTERY:
        print(f"[ABORT] Battery below {MIN_BATTERY}%")
        raise SystemExit

    print("[OK] Battery level sufficient")

    # ------------------------------------------------------
    # 3. TEMPERATURE
    # ------------------------------------------------------
    temperature = tello.get_temperature()

    print(f"[3] Temperature: {temperature} C")

    # ------------------------------------------------------
    # 4. COUNTDOWN
    # ------------------------------------------------------
    print("\nWARNING: TELLO WILL TAKE OFF")

    for i in range(5, 0, -1):
        print(f"Takeoff in {i}...")
        time.sleep(1)

    # ------------------------------------------------------
    # 5. TAKEOFF
    # ------------------------------------------------------
    print("\n[4] TAKEOFF")

    tello.takeoff()
    airborne = True

    print("[OK] Tello airborne")

    # ------------------------------------------------------
    # 6. HOVER
    # ------------------------------------------------------
    print(f"\n[5] Hovering for {HOVER_TIME} seconds")

    for i in range(HOVER_TIME):
        height = tello.get_height()
        tof = tello.get_distance_tof()

        print(
            f"Time: {i + 1}s | "
            f"Height: {height} cm | "
            f"ToF: {tof} cm"
        )

        time.sleep(1)

    # ------------------------------------------------------
    # 7. LAND
    # ------------------------------------------------------
    print("\n[6] LAND")

    tello.land()
    airborne = False

    print("[OK] Tello landed")

    # ------------------------------------------------------
    # TEST COMPLETE
    # ------------------------------------------------------
    print("\n==========================================")
    print(" BASIC FLIGHT TEST: PASSED")
    print("==========================================")

except KeyboardInterrupt:

    print("\n[WARNING] Ctrl+C detected")

    if airborne:
        print("Landing Tello...")
        try:
            tello.land()
        except:
            pass


except SystemExit:

    print("\nFlight test aborted.")


except Exception as e:

    print("\n[ERROR]")
    print(e)

    if airborne:
        print("[SAFETY] Attempting automatic landing...")

        try:
            tello.land()
        except Exception as land_error:
            print("[ERROR] Automatic landing failed:")
            print(land_error)


finally:

    print("\nClosing Tello connection...")

    try:
        tello.end()
    except:
        pass

    print("Test completed.")
