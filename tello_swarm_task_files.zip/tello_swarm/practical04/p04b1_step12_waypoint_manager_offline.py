#!/usr/bin/env python3
"""Step 12 offline waypoint-manager validation.
No DJI/Tello imports and no flight commands.
"""
import argparse, math
from dataclasses import dataclass

@dataclass
class Waypoint:
    name: str
    x: float
    y: float

class WaypointManager:
    def __init__(self, waypoints, tolerance_m=0.05, settle_samples=3):
        self.waypoints=waypoints
        self.tolerance_m=tolerance_m
        self.settle_samples=settle_samples
        self.index=0
        self.inside_count=0

    @property
    def done(self): return self.index >= len(self.waypoints)
    @property
    def target(self): return None if self.done else self.waypoints[self.index]

    def update(self, x, y):
        if self.done: return "MISSION_COMPLETE", 0.0
        t=self.target
        d=math.hypot(t.x-x,t.y-y)
        if d <= self.tolerance_m:
            self.inside_count += 1
            state="SETTLE"
            if self.inside_count >= self.settle_samples:
                reached=t.name
                self.index += 1
                self.inside_count=0
                return f"{reached}_ACCEPTED", d
        else:
            self.inside_count=0
            state="APPROACH"
        return state,d

def synthetic_path():
    # L-shaped teaching mission: origin -> WP1(+X) -> WP2(+Y).
    points=[]
    for x in (0.00,0.03,0.06,0.085,0.095,0.10,0.10,0.10):
        points.append((x,0.00))
    for y in (0.02,0.05,0.075,0.095,0.10,0.10,0.10):
        points.append((0.10,y))
    return points

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--tolerance-cm",type=float,default=5.0)
    ap.add_argument("--settle-samples",type=int,default=3)
    a=ap.parse_args()
    wps=[Waypoint("WP1",0.10,0.00),Waypoint("WP2",0.10,0.10)]
    mgr=WaypointManager(wps,a.tolerance_cm/100,a.settle_samples)
    print("STEP 12 OFFLINE WAYPOINT MANAGER")
    print(f"Tolerance     : {a.tolerance_cm:.1f} cm")
    print(f"Settle samples: {a.settle_samples}")
    print("Mission       : START -> WP1(+10cm X) -> WP2(+10cm Y)")
    for i,(x,y) in enumerate(synthetic_path()):
        target=mgr.target.name if mgr.target else "DONE"
        state,d=mgr.update(x,y)
        print(f"{i:02d} pos=({x:+.3f},{y:+.3f}) target={target:4s} "
              f"error={d*100:4.1f}cm state={state}")
    print("RESULT        :", "PASS" if mgr.done else "FAIL")
    print("MODE          : OFFLINE ONLY / NO FLIGHT COMMANDS")

if __name__ == "__main__":
    main()
