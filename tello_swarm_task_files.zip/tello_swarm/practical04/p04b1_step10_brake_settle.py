# Offline entry exits before hardware imports, calibration loading, or setup.
# The live path below remains inhibited by its unconditional flight gate.
import sys

if "--offline" in sys.argv[1:]:
    from p04b1_stage1f_offline import main as offline_main
    raise SystemExit(offline_main([arg for arg in sys.argv[1:] if arg != "--offline"]))

PREFLIGHT_ONLY = "--preflight" in sys.argv[1:]
if PREFLIGHT_ONLY:
    sys.argv.remove("--preflight")

# Flight is fail-closed by default.  The pilot must explicitly arm locally.
PILOT_ARM_TOKEN = "ARM-STEP10-BRAKE-SETTLE"
PILOT_ARMED = "--pilot-arm" in sys.argv[1:]
if PILOT_ARMED:
    sys.argv.remove("--pilot-arm")

import cv2
import csv
import time
import math
import threading
import numpy as np

from pathlib import Path
from datetime import datetime
from collections import deque
from djitellopy import Tello


# ============================================================
# P04-B1 V1
# XY POSITION HOLD + Z HOLD
#
# Vision:
#   EMEET C980 Pro
#   1280x720 MJPG
#   ArUco ID1
#   ROI tracking 320x320
#
# XY target:
#   Automatically captured after takeoff + stabilization
#
# XY controller:
#   Arena position error -> desired velocity
#   -> inverse differential mapping -> FB/LR
#
# Z:
#   ToF altitude hold
#
# Yaw:
#   MONITOR ONLY
#
# IMPORTANT:
#   First closed-loop XY test.
#   Conservative horizontal command limit = +/-4
# ============================================================


# ============================================================
# FLIGHT
# ============================================================

MIN_BATTERY = 50

STABILIZE_TIME = 6.0

# Duration of actual position-hold test
HOLD_TIME = 6.0

# Samples used to establish initial XY target
TARGET_CAPTURE_TIME = 2.0

CONTROL_DT = 0.10        # 10 Hz controller


# ============================================================
# CAMERA
# ============================================================

CAMERA_ID = 0

FRAME_W = 1280
FRAME_H = 720
CAMERA_FPS = 30

MARKER_ID = 1


# ============================================================
# ROI
# ============================================================

ROI_SIZE = 320
ROI_LOST_LIMIT = 3


# ============================================================
# ARENA
# ============================================================

ARENA_WIDTH_M = 2.1336
ARENA_HEIGHT_M = 2.1336

WARP_W = 800
WARP_H = 800


# ============================================================
# XY CONTROLLER
# ============================================================

# Position error deadband
XY_DEADBAND_M = 0.05       # 5 cm

# Position error -> desired arena velocity
#
# v_des = KP_XY * position_error
#
# Conservative first test.
KP_XY = 0.35

# Maximum requested correction velocity
MAX_DESIRED_VEL_MPS = 0.035

# Stage 1D velocity damping from overhead ID1 trajectory
KD_VEL = 0.45
VEL_FILTER_ALPHA = 0.25
MAX_MEASURED_VEL_MPS = 0.15
VELOCITY_DEADBAND_MPS = 0.008

# Horizontal Tello command limit
MAX_XY_RC = 6

# Avoid tiny ineffective commands
MIN_ACTIVE_XY_RC = 2


# ============================================================
# V4.1 DIFFERENTIAL RESPONSE MATRIX
#
# For RC +10:
#
# [Vx]   [+0.016692  +0.057230] [LR10]
# [Vy] = [-0.019983  +0.008231] [FB10]
#
# Column 1 = LR +10 response
# Column 2 = FB +10 response
#
# Units: m/s
# ============================================================

FALLBACK_MATRIX = np.array([
    [+0.016692, +0.057230],
    [-0.019983, +0.008231]
], dtype=float)
FALLBACK_CALIBRATION_RC = 10.0

CALIBRATION_FILE = (
    Path(__file__).resolve().parent / "logs" / "p04b1_calibration_rc6_differential.npz"
)
EXPECTED_COLUMN_ORDER = "LR,FB"

# Stage 1D is fail-closed: never fly with an embedded/fallback response matrix.
def load_response_calibration():
    if not CALIBRATION_FILE.exists():
        raise RuntimeError(f"required calibration file not found: {CALIBRATION_FILE}")

    data = np.load(CALIBRATION_FILE, allow_pickle=False)
    matrix = np.asarray(data["matrix"], dtype=float)
    calibration_rc = float(np.asarray(data["calibration_rc"]).item())
    if matrix.shape != (2, 2):
        raise ValueError("matrix must be 2x2")
    if not np.all(np.isfinite(matrix)) or calibration_rc <= 0:
        raise ValueError("invalid calibration values")
    if abs(calibration_rc - 6.0) > 1e-9:
        raise ValueError(f"RC6 calibration required; got RC{calibration_rc:g}")
    if "column_order" not in data.files:
        raise ValueError("missing calibration metadata: column_order")
    column_order = str(np.asarray(data["column_order"]).item())
    if column_order != EXPECTED_COLUMN_ORDER:
        raise ValueError(f"column_order={column_order}; expected {EXPECTED_COLUMN_ORDER}")
    condition = float(np.linalg.cond(matrix))
    if not np.isfinite(condition) or condition > 10.0:
        raise ValueError(f"matrix condition too high: {condition:.2f}")

    expected = {
        "frame_w": FRAME_W, "frame_h": FRAME_H,
        "marker_id": MARKER_ID, "warp_w": WARP_W, "warp_h": WARP_H,
    }
    for key, wanted in expected.items():
        if key not in data.files:
            raise ValueError(f"missing calibration metadata: {key}")
        actual = int(np.asarray(data[key]).item())
        if actual != int(wanted):
            raise ValueError(f"calibration {key}={actual}; expected {wanted}")

    if "homography" not in data.files:
        raise ValueError("missing calibration homography")
    calibration_h = np.asarray(data["homography"], dtype=float)
    if calibration_h.shape != H.shape or not np.allclose(
        calibration_h, H, rtol=1e-9, atol=1e-9
    ):
        raise ValueError("calibration homography does not match current H")

    return matrix, calibration_rc, str(CALIBRATION_FILE)


# Calibration is loaded only after H has been loaded below.
RESPONSE_MATRIX = None
CALIBRATION_RC = None
CALIBRATION_SOURCE = None
RESPONSE_MATRIX_INV = None


# ============================================================
# SAFETY
# ============================================================

# Stop horizontal correction quickly if vision disappears
VISION_HOLD_TIMEOUT = 0.50

# Land if ID1 remains lost
VISION_LAND_TIMEOUT = 1.50

# If drone moves too far from captured target
MAX_POSITION_ERROR_M = 0.40

# Arena safety margin
ARENA_MARGIN_M = 0.20


# ============================================================
# Z CONTROL
# ============================================================

TOF_MIN_VALID = 20
TOF_MAX_VALID = 200

FILTER_SIZE = 5

REFERENCE_SAMPLES = 15
REFERENCE_INTERVAL = 0.12

Z_UPDATE_INTERVAL = 0.35

Z_DEADBAND_CM = 3.0

KP_Z = 0.80

MAX_RC_Z = 6
MIN_ACTIVE_Z_RC = 4

SOFT_CEILING_OFFSET = 8.0
HARD_CEILING_OFFSET = 15.0

HARD_DESCENT_RC = -8


# ============================================================
# PATH
# ============================================================

BASE_DIR = Path(__file__).resolve().parent

H_FILE = (
    BASE_DIR.parent
    / "practical02"
    / "arena_homography.npy"
)

LOG_DIR = BASE_DIR / "logs"

LOG_DIR.mkdir(
    parents=True,
    exist_ok=True
)

timestamp = datetime.now().strftime(
    "%Y%m%d_%H%M%S"
)

CSV_FILE = (
    LOG_DIR
    / f"p04b1_step10_brake_settle_{timestamp}.csv"
)


# ============================================================
# HOMOGRAPHY
# ============================================================

if not H_FILE.exists():

    print("[ERROR] Homography file not found:")
    print(H_FILE)

    raise SystemExit


H = np.load(H_FILE)

try:
    RESPONSE_MATRIX, CALIBRATION_RC, CALIBRATION_SOURCE = load_response_calibration()
    RESPONSE_MATRIX_INV = np.linalg.inv(RESPONSE_MATRIX)
except Exception as exc:
    print(f"[FATAL] RC6 discrete calibration validation failed: {exc}")
    print("[FATAL] Fallback calibration is DISABLED. No flight allowed.")
    raise SystemExit(2)

print("[CALIBRATION VALIDATED]")
print(f"Source   : {CALIBRATION_SOURCE}")
print(f"RC       : +/-{CALIBRATION_RC:g}")
print("Matrix:")
print(RESPONSE_MATRIX)
print("Fallback : DISABLED")

# RC10 calibration diagnostics.  Direction coupling is represented by the
# measured 2x2 response matrix above; do not reduce it to axis-only signs.
print("[INFO] RC6 paired-differential calibration active")
print(f"[INFO] Column order: {EXPECTED_COLUMN_ORDER}")
print(f"[INFO] Response-matrix condition: {np.linalg.cond(RESPONSE_MATRIX):.3f}")
if PREFLIGHT_ONLY:
    print("[PRE-FLIGHT CHECK OK]")
    print(f"Calibration : RC{CALIBRATION_RC:g} / {EXPECTED_COLUMN_ORDER}")
    print(f"Condition   : {np.linalg.cond(RESPONSE_MATRIX):.3f}")
    print("Takeoff     : INHIBITED (preflight-only mode)")
    raise SystemExit(0)

if not PILOT_ARMED:
    print("[FATAL] Stage 1F flight gate is LOCKED.")
    print("[FATAL] Run hardware pre-flight, then use --pilot-arm locally.")
    raise SystemExit(3)

print("[PILOT ARM] Flight-capable path requested locally.")
confirmation = input(f"Type {PILOT_ARM_TOKEN} to arm this short validation: ").strip()
if confirmation != PILOT_ARM_TOKEN:
    print("[FATAL] Pilot arm confirmation failed. Takeoff inhibited.")
    raise SystemExit(4)
print("[PILOT ARM] CONFIRMED. Live safety checks remain active.")


# ============================================================
# ARUCO
# ============================================================

dictionary = cv2.aruco.getPredefinedDictionary(
    cv2.aruco.DICT_4X4_50
)

parameters = cv2.aruco.DetectorParameters()

parameters.cornerRefinementMethod = (
    cv2.aruco.CORNER_REFINE_SUBPIX
)

parameters.adaptiveThreshWinSizeMin = 3
parameters.adaptiveThreshWinSizeMax = 53
parameters.adaptiveThreshWinSizeStep = 2

parameters.minMarkerPerimeterRate = 0.005
parameters.maxMarkerPerimeterRate = 4.0

parameters.polygonalApproxAccuracyRate = 0.05

parameters.minCornerDistanceRate = 0.01
parameters.minMarkerDistanceRate = 0.01

parameters.minDistanceToBorder = 2

parameters.cornerRefinementWinSize = 5
parameters.cornerRefinementMaxIterations = 50
parameters.cornerRefinementMinAccuracy = 0.01


detector = cv2.aruco.ArucoDetector(
    dictionary,
    parameters
)


# ============================================================
# CAMERA
# ============================================================

cap = cv2.VideoCapture(
    CAMERA_ID,
    cv2.CAP_V4L2
)

if not cap.isOpened():

    print("[ERROR] Cannot open EMEET camera.")
    raise SystemExit


cap.set(
    cv2.CAP_PROP_FOURCC,
    cv2.VideoWriter_fourcc(*"MJPG")
)

cap.set(
    cv2.CAP_PROP_FRAME_WIDTH,
    FRAME_W
)

cap.set(
    cv2.CAP_PROP_FRAME_HEIGHT,
    FRAME_H
)

cap.set(
    cv2.CAP_PROP_FPS,
    CAMERA_FPS
)

cap.set(
    cv2.CAP_PROP_AUTOFOCUS,
    0
)

time.sleep(2)


# ============================================================
# TELLO
# ============================================================

tello = Tello()

airborne = False


# ============================================================
# SHARED VISION STATE
# ============================================================

vision_lock = threading.Lock()

vision_running = True

vision_state = {

    "detected": False,

    "x": None,
    "y": None,

    "angle": None,

    "pts": None,

    "source": "NONE",

    "frame_read_timestamp": 0.0,
    "frame_sequence": 0,
    "processing_timestamp": 0.0,
    "last_detection_timestamp": 0.0,

    "fps": 0.0
}


# ============================================================
# ROI TRACKER STATE
# ============================================================

tracking = False

last_center = None

consecutive_roi_lost = 0


# ============================================================
# LOG
# ============================================================

flight_log = []


# ============================================================
# ToF
# ============================================================

tof_buffer = deque(
    maxlen=FILTER_SIZE
)


# ============================================================
# UTILITY
# ============================================================

def clamp(value, low, high):

    return max(
        low,
        min(high, value)
    )


def normalize_angle(angle):

    while angle > 180:
        angle -= 360

    while angle < -180:
        angle += 360

    return angle


# ============================================================
# HOMOGRAPHY
# ============================================================

def pixel_to_warp(u, v):

    point = np.array(
        [[[u, v]]],
        dtype=np.float32
    )

    transformed = cv2.perspectiveTransform(
        point,
        H
    )

    return (
        float(transformed[0][0][0]),
        float(transformed[0][0][1])
    )


def pixel_to_xy(u, v):

    wx, wy = pixel_to_warp(
        u,
        v
    )

    x = (
        wx
        /
        (WARP_W - 1)
        *
        ARENA_WIDTH_M
    )

    y = (
        wy
        /
        (WARP_H - 1)
        *
        ARENA_HEIGHT_M
    )

    return x, y


# ============================================================
# BASIC ARUCO DETECTION
# ============================================================

def detect_id1(image):

    gray = cv2.cvtColor(
        image,
        cv2.COLOR_BGR2GRAY
    )

    corners, ids, _ = detector.detectMarkers(
        gray
    )

    if ids is None:

        return (
            False,
            None
        )


    for i, marker_id in enumerate(
        ids.flatten()
    ):

        if int(marker_id) == MARKER_ID:

            pts = corners[i][0].astype(
                np.float32
            )

            return (
                True,
                pts
            )


    return (
        False,
        None
    )


# ============================================================
# ROI
# ============================================================

def make_roi(
    center_x,
    center_y,
    frame_width,
    frame_height
):

    half = ROI_SIZE // 2

    x1 = int(center_x - half)
    y1 = int(center_y - half)

    x2 = int(center_x + half)
    y2 = int(center_y + half)


    if x1 < 0:

        x2 -= x1
        x1 = 0


    if y1 < 0:

        y2 -= y1
        y1 = 0


    if x2 > frame_width:

        shift = x2 - frame_width

        x1 -= shift
        x2 = frame_width


    if y2 > frame_height:

        shift = y2 - frame_height

        y1 -= shift
        y2 = frame_height


    x1 = max(0, x1)
    y1 = max(0, y1)


    return (
        x1,
        y1,
        x2,
        y2
    )


# ============================================================
# TRACK ID1
# ============================================================

def track_id1(frame):

    global tracking
    global last_center
    global consecutive_roi_lost


    h, w = frame.shape[:2]


    detected = False

    pts_global = None

    source = "NONE"


    # --------------------------------------------------------
    # ROI SEARCH
    # --------------------------------------------------------

    if (
        tracking
        and
        last_center is not None
    ):

        cx, cy = last_center

        x1, y1, x2, y2 = make_roi(
            cx,
            cy,
            w,
            h
        )

        roi = frame[
            y1:y2,
            x1:x2
        ]

        found, pts = detect_id1(
            roi
        )


        if found:

            pts[:, 0] += x1
            pts[:, 1] += y1

            pts_global = pts

            detected = True

            source = "ROI"

            consecutive_roi_lost = 0


        else:

            consecutive_roi_lost += 1


            if (
                consecutive_roi_lost
                >=
                ROI_LOST_LIMIT
            ):

                tracking = False

                last_center = None


    # --------------------------------------------------------
    # FULL SEARCH
    # --------------------------------------------------------

    if not tracking:

        found, pts = detect_id1(
            frame
        )


        if found:

            pts_global = pts

            detected = True

            source = "FULL"

            tracking = True

            consecutive_roi_lost = 0


    if not detected:

        return (
            False,
            None,
            None,
            None,
            None,
            source
        )


    # --------------------------------------------------------
    # CENTER
    # --------------------------------------------------------

    u = float(
        np.mean(
            pts_global[:, 0]
        )
    )

    v = float(
        np.mean(
            pts_global[:, 1]
        )
    )


    last_center = (
        u,
        v
    )


    # --------------------------------------------------------
    # XY
    # --------------------------------------------------------

    x, y = pixel_to_xy(
        u,
        v
    )


    # --------------------------------------------------------
    # ANGLE
    # --------------------------------------------------------

    c0x, c0y = pixel_to_warp(
        pts_global[0][0],
        pts_global[0][1]
    )

    c1x, c1y = pixel_to_warp(
        pts_global[1][0],
        pts_global[1][1]
    )


    angle = math.degrees(
        math.atan2(
            c1y - c0y,
            c1x - c0x
        )
    )

    angle = normalize_angle(
        angle
    )


    return (
        True,
        x,
        y,
        angle,
        pts_global.copy(),
        source
    )


# ============================================================
# VISION THREAD
# ============================================================

def vision_worker():

    global vision_running


    frame_counter = 0

    fps_timer = time.perf_counter()

    current_fps = 0.0


    frame_sequence = 0

    while vision_running:

        ret, frame = cap.read()


        if not ret:

            continue


        frame_read_timestamp = time.perf_counter()
        frame_sequence += 1

        (
            detected,
            x,
            y,
            angle,
            pts,
            source

        ) = track_id1(
            frame
        )


        frame_counter += 1


        now = time.perf_counter()


        elapsed = (
            now
            -
            fps_timer
        )


        if elapsed >= 1.0:

            current_fps = (
                frame_counter
                /
                elapsed
            )

            frame_counter = 0

            fps_timer = now


        with vision_lock:

            vision_state[
                "detected"
            ] = detected

            vision_state[
                "x"
            ] = x

            vision_state[
                "y"
            ] = y

            vision_state[
                "angle"
            ] = angle

            vision_state[
                "pts"
            ] = pts

            vision_state[
                "source"
            ] = source

            # Publish timing and result together for the same frame.
            vision_state["frame_read_timestamp"] = frame_read_timestamp
            vision_state["frame_sequence"] = frame_sequence
            vision_state["processing_timestamp"] = now

            if detected:
                vision_state["last_detection_timestamp"] = frame_read_timestamp

            vision_state[
                "fps"
            ] = current_fps


# ============================================================
# GET VISION
# ============================================================

def vision_is_fresh(state):

    return (
        state["detected"]
        and state["frame_sequence"] > 0
        and 0.0 <= time.perf_counter() - state["frame_read_timestamp"]
        <= VISION_HOLD_TIMEOUT
    )


def get_vision_state():

    with vision_lock:

        return {
            key: (
                value.copy()
                if isinstance(
                    value,
                    np.ndarray
                )
                else value
            )

            for key, value
            in vision_state.items()
        }


# ============================================================
# ToF
# ============================================================

def get_valid_tof():

    try:

        value = int(
            tello.get_distance_tof()
        )

        if (
            TOF_MIN_VALID
            <= value
            <= TOF_MAX_VALID
        ):

            return value

    except Exception:

        pass


    return None


def filtered_tof(value):

    if value is not None:

        tof_buffer.append(
            value
        )


    if len(tof_buffer) == 0:

        return None


    return float(
        np.median(
            list(tof_buffer)
        )
    )


# ============================================================
# Z CONTROL
# ============================================================

def calculate_z_control(
    current_tof,
    target_tof
):

    if current_tof is None:

        return (
            0,
            None,
            "INVALID"
        )


    error = (
        target_tof
        -
        current_tof
    )


    soft_ceiling = (
        target_tof
        +
        SOFT_CEILING_OFFSET
    )


    hard_ceiling = (
        target_tof
        +
        HARD_CEILING_OFFSET
    )


    if current_tof >= hard_ceiling:

        return (
            HARD_DESCENT_RC,
            error,
            "HARD_CEILING"
        )


    if abs(error) <= Z_DEADBAND_CM:

        rc_z = 0

        state = "HOLD"


    else:

        rc_z = int(
            round(
                KP_Z
                *
                error
            )
        )


        if (
            0
            <
            rc_z
            <
            MIN_ACTIVE_Z_RC
        ):

            rc_z = MIN_ACTIVE_Z_RC


        elif (
            -MIN_ACTIVE_Z_RC
            <
            rc_z
            <
            0
        ):

            rc_z = -MIN_ACTIVE_Z_RC


        rc_z = int(
            clamp(
                rc_z,
                -MAX_RC_Z,
                MAX_RC_Z
            )
        )


        if rc_z > 0:

            state = "UP"

        else:

            state = "DOWN"


    if current_tof >= soft_ceiling:

        if rc_z > 0:

            rc_z = 0


        if rc_z == 0:

            state = "SOFT_CEILING"


    return (
        rc_z,
        error,
        state
    )


# ============================================================
# ToF REFERENCE
# ============================================================

def collect_tof_reference():
    """Capture altitude only after a stable rolling ToF window is observed."""
    print("\nCollecting STABLE altitude reference...")
    values = []
    start = time.monotonic()
    last_print = None
    while time.monotonic()-start < 12.0:
        v = get_valid_tof()
        if v is not None:
            values.append(float(v))
            values = values[-15:]
            if v != last_print:
                print(f"ToF={v} cm  window={len(values)}/15")
                last_print = v
            if len(values) >= 10:
                med = float(np.median(values))
                spread = max(values)-min(values)
                # Stable hover reference: tight window, plausible flight height.
                if 60.0 <= med <= 120.0 and spread <= 6.0:
                    print(f"Stable ToF reference: median={med:.1f} cm spread={spread:.1f} cm")
                    return med
        time.sleep(0.10)
    return None


# ============================================================
# CAPTURE XY TARGET
# ============================================================

def capture_xy_target():

    print()
    print(
        "Capturing XY hold target..."
    )


    xs = []

    ys = []

    angles = []


    last_sequence = 0
    start = time.perf_counter()


    while (
        time.perf_counter()
        -
        start
        <
        TARGET_CAPTURE_TIME
    ):

        state = get_vision_state()


        if time.perf_counter() - state["last_detection_timestamp"] > VISION_LAND_TIMEOUT:
            tello.send_rc_control(0, 0, 0, 0)
            raise RuntimeError("Vision lost during position capture.")

        if (
            vision_is_fresh(state)
            and state["frame_read_timestamp"] >= start
            and state["frame_sequence"] != last_sequence
        ):
            last_sequence = state["frame_sequence"]

            xs.append(
                state["x"]
            )

            ys.append(
                state["y"]
            )

            angles.append(
                state["angle"]
            )


        time.sleep(
            0.05
        )


    if len(xs) < 10:

        return None


    return {

        "x":
            float(
                np.median(xs)
            ),

        "y":
            float(
                np.median(ys)
            ),

        "angle":
            float(
                np.median(angles)
            ),

        "samples":
            len(xs)
    }


# ============================================================
# XY CONTROLLER
# ============================================================

def calculate_xy_control(x, y, target_x, target_y, vx_meas=0.0, vy_meas=0.0):
    """Empirical single-axis direction map. Pulse scheduler gates command timing."""
    ex, ey = target_x-x, target_y-y
    d = math.hypot(ex, ey)
    axis_tol = XY_DEADBAND_M
    if abs(ex) <= axis_tol and abs(ey) <= axis_tol:
        return (0,0,ex,ey,d,0.0,0.0,"PULSE_DONE")
    # Correct dominant normalized error; X uses confirmed FB map, Y confirmed LR map.
    if abs(ex) >= abs(ey):
        return (0, -6 if ex>0 else 6, ex,ey,d,0.0,0.0,"PULSE_X")
    return (6 if ey>0 else -6, 0, ex,ey,d,0.0,0.0,"PULSE_Y")


# ============================================================
# ARENA SAFETY
# ============================================================

def arena_safe(x, y):

    return (
        ARENA_MARGIN_M
        <=
        x
        <=
        ARENA_WIDTH_M
        -
        ARENA_MARGIN_M

        and

        ARENA_MARGIN_M
        <=
        y
        <=
        ARENA_HEIGHT_M
        -
        ARENA_MARGIN_M
    )


# ============================================================
# SAVE CSV
# ============================================================

def save_csv():

    if len(flight_log) == 0:

        return


    keys = list(
        flight_log[0].keys()
    )


    with open(
        CSV_FILE,
        "w",
        newline=""
    ) as f:

        writer = csv.DictWriter(
            f,
            fieldnames=keys
        )

        writer.writeheader()

        writer.writerows(
            flight_log
        )


# ============================================================
# INTRO
# ============================================================

print()
print("=" * 76)
print(" P04-B1 V1 - XY POSITION HOLD + Z HOLD")
print("=" * 76)

print()
print(
    f"XY deadband       : "
    f"{XY_DEADBAND_M*100:.0f} cm"
)

print(
    f"XY Kp             : "
    f"{KP_XY:.2f}"
)

print(
    f"Max horizontal RC : "
    f"+/-{MAX_XY_RC}"
)

print(
    f"Hold test         : "
    f"{HOLD_TIME:.0f} s"
)

print()
print(f"Calibration source  : {CALIBRATION_SOURCE}")
print(f"Calibration RC      : +/-{CALIBRATION_RC:g}")

print("Response matrix:")
print(RESPONSE_MATRIX)

print()

print("Inverse:")
print(RESPONSE_MATRIX_INV)

print()


# ============================================================
# MAIN
# ============================================================

vision_thread = None


try:

    # ========================================================
    # START VISION THREAD
    # ========================================================

    vision_thread = threading.Thread(
        target=vision_worker,
        daemon=True
    )

    vision_thread.start()


    print(
        "Waiting for vision..."
    )

    time.sleep(2)


    state = get_vision_state()


    if not vision_is_fresh(state):

        raise RuntimeError(
            "ID1 not detected before takeoff."
        )

    actual_w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    actual_h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    actual_fps = float(cap.get(cv2.CAP_PROP_FPS))
    if actual_w != FRAME_W or actual_h != FRAME_H:
        raise RuntimeError(
            f"Camera mode {actual_w}x{actual_h} incompatible with "
            f"homography/calibration {FRAME_W}x{FRAME_H}."
        )
    print(
        f"Camera OK | {actual_w}x{actual_h} @ {actual_fps:.1f} FPS | "
        f"marker ID {MARKER_ID}"
    )


    print(
        f"Vision OK | "
        f"X={state['x']:.3f} "
        f"Y={state['y']:.3f}"
    )


    # ========================================================
    # CONNECT
    # ========================================================

    print()
    print("Connecting Tello...")

    tello.connect()


    battery = tello.get_battery()


    print(
        f"Battery = {battery}%"
    )


    if battery < MIN_BATTERY:

        raise RuntimeError(
            "Battery too low."
        )


    # ========================================================
    # TAKEOFF
    # ========================================================

    print()
    print("Taking off...")

    # Connection/battery checks may have outlasted the first observation.
    if not vision_is_fresh(get_vision_state()):
        raise RuntimeError("Fresh ID1 observation required before takeoff.")

    tello.takeoff()

    airborne = True


    tello.send_rc_control(
        0,
        0,
        0,
        0
    )


    print(
        f"Stabilizing "
        f"{STABILIZE_TIME:.1f}s..."
    )

    time.sleep(
        STABILIZE_TIME
    )


    # ========================================================
    # ALTITUDE TARGET
    # ========================================================

    target_tof = collect_tof_reference()


    if target_tof is None:

        raise RuntimeError(
            "Cannot establish altitude reference."
        )


    tof_buffer.clear()

    print()
    print(f"Z TARGET = {target_tof:.1f} cm")

    # Verify reference remains representative before locking XY origin.
    time.sleep(0.8)
    verify_tof = get_valid_tof()
    if verify_tof is None or abs(float(verify_tof)-target_tof) > 8.0:
        raise RuntimeError(f"Altitude reference moved before XY lock: target={target_tof:.1f}, now={verify_tof}")
    print(f"Z reference verified: {verify_tof} cm")

    # ========================================================
    # XY TARGET
    # ========================================================

    target = capture_xy_target()


    if target is None:

        raise RuntimeError(
            "Unable to establish XY target."
        )


    start_x = target["x"]
    start_y = target["y"]
    target_x = start_x + 0.10
    target_y = start_y

    reference_angle = target["angle"]


    print()
    print("=" * 60)

    print(
        f"XY TARGET:"
    )

    print(
        f"X = {target_x:.3f} m"
    )

    print(
        f"Y = {target_y:.3f} m"
    )

    print(
        f"Yaw reference = "
        f"{reference_angle:+.1f} deg"
    )

    print(
        f"Samples = "
        f"{target['samples']}"
    )

    print("=" * 60)


    if not arena_safe(
        target_x,
        target_y
    ):

        raise RuntimeError(
            "Captured target too close "
            "to arena boundary."
        )


    # ========================================================
    # POSITION HOLD
    # ========================================================

    print()
    print(
        "Starting XY + Z position hold..."
    )

    print(
        "Press Ctrl+C to stop."
    )


    hold_start = (
        time.perf_counter()
    )

    # Empirical pulse-navigation scheduler: command, then neutral/coast observation.
    pulse_on_s = 0.10
    observe_s = 0.18
    brake_on_s = 0.24
    brake_trigger_mps = 0.012
    approach_trigger_m = 0.09
    nav_phase = "DECIDE"
    nav_phase_start = hold_start
    pulse_lr = pulse_fb = 0
    pulse_start_error = None
    pulse_axis = None
    pulse_axis_error_start = None
    pulse_count = 0
    max_pulses = 6
    settle_required_s = 0.70
    settle_start = None


    last_control = 0.0

    last_z_update = -999.0

    last_print = -999.0


    rc_z = 0

    # Velocity estimator state (arena coordinates, low-pass filtered).
    prev_xy_t = None
    prev_x = None
    prev_y = None
    vx_filt = 0.0
    vy_filt = 0.0

    tof_raw = None
    tof_value = None

    z_error = None
    z_state = "INIT"


    while (
        time.perf_counter()
        -
        hold_start
        <
        HOLD_TIME
    ):

        now = time.perf_counter()


        # ====================================================
        # 10 Hz CONTROL
        # ====================================================

        if (
            now
            -
            last_control
            <
            CONTROL_DT
        ):

            time.sleep(
                0.005
            )

            continue


        last_control = now


        # ====================================================
        # VISION
        # ====================================================

        state = get_vision_state()


        vision_age = (
            now
            -
            state["frame_read_timestamp"]
        )


        vision_lost = not vision_is_fresh(state)

        if vision_lost and now - state["last_detection_timestamp"] > VISION_LAND_TIMEOUT:
            tello.send_rc_control(0, 0, 0, 0)
            flight_log.append({
                "time_s": now - hold_start,
                "x_m": state["x"], "y_m": state["y"],
                "target_x_m": target_x, "target_y_m": target_y,
                "error_x_m": None, "error_y_m": None, "error_distance_m": None,
                "vx_des_mps": 0.0, "vy_des_mps": 0.0,
                "rc_lr": 0, "rc_fb": 0, "rc_z": 0,
                "xy_state": "VISION_LAND", "aruco_angle_deg": state["angle"],
                "reference_angle_deg": reference_angle,
                "vision_fps": state["fps"], "vision_source": state["source"],
                "vision_age_s": vision_age, "tof_raw_cm": tof_raw,
                "tof_filtered_cm": tof_value, "target_tof_cm": target_tof,
                "z_error_cm": z_error, "z_state": z_state
            })
            print("[SAFETY] Vision lost. Landing.")
            break

        # ====================================================
        # Z CONTROL
        # ====================================================

        if (
            now
            -
            last_z_update
            >=
            Z_UPDATE_INTERVAL
        ):

            last_z_update = now


            tof_raw = get_valid_tof()


            tof_value = filtered_tof(
                tof_raw
            )


            (
                rc_z,
                z_error,
                z_state

            ) = calculate_z_control(
                tof_value,
                target_tof
            )


        if vision_lost:
            rc_lr = 0
            rc_fb = 0
            xy_state = "VISION_HOLD"
            # Stop XY this cycle; keep independently updated Z control active.
            # Send once per cycle so the SDK rate limiter does not drop Z updates.
            tello.send_rc_control(0, 0, rc_z, 0)
            flight_log.append({
                "time_s": now - hold_start,
                "x_m": state["x"], "y_m": state["y"],
                "target_x_m": target_x, "target_y_m": target_y,
                "error_x_m": None, "error_y_m": None, "error_distance_m": None,
                "vx_des_mps": 0.0, "vy_des_mps": 0.0,
                "rc_lr": 0, "rc_fb": 0, "rc_z": rc_z,
                "xy_state": xy_state, "aruco_angle_deg": state["angle"],
                "reference_angle_deg": reference_angle,
                "vision_fps": state["fps"], "vision_source": state["source"],
                "vision_age_s": vision_age, "tof_raw_cm": tof_raw,
                "tof_filtered_cm": tof_value, "target_tof_cm": target_tof,
                "z_error_cm": z_error, "z_state": z_state
            })
            continue


        x = state["x"]
        y = state["y"]

        angle = state["angle"]


        # ====================================================
        # ARENA BOUNDARY
        # ====================================================

        if not arena_safe(
            x,
            y
        ):

            print()
            print(
                "[SAFETY] Arena boundary "
                "margin exceeded."
            )
            flight_log.append({
                "time_s": now - hold_start, "x_m": x, "y_m": y,
                "target_x_m": target_x, "target_y_m": target_y,
                "error_x_m": target_x - x, "error_y_m": target_y - y,
                "error_distance_m": float(np.hypot(target_x - x, target_y - y)),
                "vx_des_mps": 0.0, "vy_des_mps": 0.0,
                "rc_lr": 0, "rc_fb": 0, "rc_z": 0,
                "xy_state": "ARENA_FAILSAFE", "aruco_angle_deg": angle,
                "reference_angle_deg": reference_angle,
                "vision_fps": state["fps"], "vision_source": state["source"],
                "vision_age_s": vision_age, "tof_raw_cm": tof_raw,
                "tof_filtered_cm": tof_value, "target_tof_cm": target_tof,
                "z_error_cm": z_error, "z_state": z_state
            })

            break


        # ====================================================
        # XY CONTROL
        # ====================================================

        # Estimate translational velocity from overhead marker motion.
        if prev_xy_t is not None and now > prev_xy_t:
            dt_xy = now - prev_xy_t
            vx_raw = (x - prev_x) / dt_xy
            vy_raw = (y - prev_y) / dt_xy
            vx_filt = (1.0 - VEL_FILTER_ALPHA) * vx_filt + VEL_FILTER_ALPHA * vx_raw
            vy_filt = (1.0 - VEL_FILTER_ALPHA) * vy_filt + VEL_FILTER_ALPHA * vy_raw
        prev_xy_t, prev_x, prev_y = now, x, y

        (
            rc_lr,
            rc_fb,

            ex,
            ey,

            distance_error,

            vx_des,
            vy_des,

            xy_state

        ) = calculate_xy_control(
            x,
            y,
            target_x,
            target_y,
            vx_filt,
            vy_filt
        )


        # ====================================================
        # VELOCITY-AWARE PULSE / BRAKE / RE-MEASURE SCHEDULER
        # ====================================================
        in_xy_box = (abs(ex) <= XY_DEADBAND_M and abs(ey) <= XY_DEADBAND_M)
        speed = math.hypot(vx_filt, vy_filt)

        if in_xy_box and speed > VELOCITY_DEADBAND_MPS:
            # Position is good but aircraft is still moving: brake from measured arena velocity.
            settle_start = None
            if abs(vx_filt) >= abs(vy_filt):
                # +Vx needs FB+6 to brake; -Vx needs FB-6.
                rc_lr, rc_fb = 0, (6 if vx_filt > 0 else -6)
                xy_state = "VEL_TARGET_BRAKE_X"
            else:
                # Closed-loop Y evidence: +Vy is opposed by LR-6, -Vy by LR+6.
                rc_lr, rc_fb = (-6 if vy_filt > 0 else 6), 0
                xy_state = "VEL_TARGET_BRAKE_Y"
            nav_phase = "TARGET_BRAKE"
            nav_phase_start = now
        elif in_xy_box and speed <= VELOCITY_DEADBAND_MPS:
            rc_lr = rc_fb = 0
            if nav_phase != "SETTLE":
                nav_phase = "SETTLE"; settle_start = now
            xy_state = "VEL_SETTLE"
            if settle_start is not None and now-settle_start >= settle_required_s:
                nav_phase = "COMPLETE"; xy_state = "VEL_SETTLED"
        else:
            if nav_phase in ("SETTLE", "COMPLETE", "TARGET_BRAKE"):
                nav_phase = "DECIDE"; settle_start = None
            if nav_phase == "DECIDE":
                pulse_lr, pulse_fb = rc_lr, rc_fb
                pulse_start_error = distance_error
                pulse_axis = "X" if rc_fb != 0 else "Y"
                pulse_axis_error_start = ex if pulse_axis == "X" else ey
                pulse_count += 1
                nav_phase = "PULSE"; nav_phase_start = now
            elif nav_phase == "PULSE":
                rc_lr, rc_fb = pulse_lr, pulse_fb
                axis_err = ex if pulse_axis == "X" else ey
                axis_vel = vx_filt if pulse_axis == "X" else vy_filt
                toward_fast = (axis_err*axis_vel > 0 and abs(axis_vel) >= brake_trigger_mps and abs(axis_err) <= approach_trigger_m)
                xy_state = "VEL_PULSE_ACTIVE"
                if toward_fast or now-nav_phase_start >= pulse_on_s:
                    # Active opposite pulse to arrest measured momentum.
                    rc_lr, rc_fb = -pulse_lr, -pulse_fb
                    nav_phase = "BRAKE"; nav_phase_start = now
                    xy_state = "VEL_BRAKE_START"
            elif nav_phase == "BRAKE":
                rc_lr, rc_fb = -pulse_lr, -pulse_fb
                xy_state = "VEL_BRAKE_ACTIVE"
                if now-nav_phase_start >= brake_on_s:
                    rc_lr = rc_fb = 0
                    nav_phase = "OBSERVE"; nav_phase_start = now
                    xy_state = "VEL_NEUTRAL"
            elif nav_phase == "OBSERVE":
                rc_lr = rc_fb = 0
                xy_state = "VEL_OBSERVE"
                if now-nav_phase_start >= observe_s:
                    axis_now = ex if pulse_axis == "X" else ey
                    axis_before = pulse_axis_error_start
                    if axis_before is not None and abs(axis_now) > abs(axis_before) + 0.02:
                        xy_state = "VEL_AXIS_DIVERGENCE"; distance_error = MAX_POSITION_ERROR_M + 0.01
                    elif pulse_start_error is not None and distance_error > pulse_start_error + 0.10:
                        xy_state = "VEL_TOTAL_DIVERGENCE"; distance_error = MAX_POSITION_ERROR_M + 0.01
                    elif pulse_count >= max_pulses:
                        xy_state = "VEL_PULSE_LIMIT"; distance_error = MAX_POSITION_ERROR_M + 0.01
                    else:
                        nav_phase = "DECIDE"

        # ====================================================
        # LARGE ERROR FAILSAFE
        # ====================================================

        if (
            distance_error
            >
            MAX_POSITION_ERROR_M
        ):

            print()
            print(
                "[SAFETY] Position error "
                f"{distance_error:.2f} m."
            )
            flight_log.append({
                "time_s": now - hold_start, "x_m": x, "y_m": y,
                "target_x_m": target_x, "target_y_m": target_y,
                "error_x_m": ex, "error_y_m": ey,
                "error_distance_m": distance_error,
                "vx_des_mps": vx_des, "vy_des_mps": vy_des,
                "rc_lr": 0, "rc_fb": 0, "rc_z": 0,
                "xy_state": "ERROR_FAILSAFE", "aruco_angle_deg": angle,
                "reference_angle_deg": reference_angle,
                "vision_fps": state["fps"], "vision_source": state["source"],
                "vision_age_s": vision_age, "tof_raw_cm": tof_raw,
                "tof_filtered_cm": tof_value, "target_tof_cm": target_tof,
                "z_error_cm": z_error, "z_state": z_state
            })

            break


        # ====================================================
        # SEND COMBINED RC
        # ====================================================

        tello.send_rc_control(
            rc_lr,
            rc_fb,
            rc_z,
            0
        )


        # ====================================================
        # LOG
        # ====================================================

        flight_log.append({

            "time_s":
                now - hold_start,

            "x_m":
                x,

            "y_m":
                y,

            "target_x_m":
                target_x,

            "target_y_m":
                target_y,

            "error_x_m":
                ex,

            "error_y_m":
                ey,

            "error_distance_m":
                distance_error,

            "vx_des_mps":
                vx_des,

            "vy_des_mps":
                vy_des,

            "rc_lr":
                rc_lr,

            "rc_fb":
                rc_fb,

            "rc_z":
                rc_z,

            "xy_state":
                xy_state,

            "aruco_angle_deg":
                angle,

            "reference_angle_deg":
                reference_angle,

            "vision_fps":
                state["fps"],

            "vision_source":
                state["source"],

            "vision_age_s":
                vision_age,

            "tof_raw_cm":
                tof_raw,

            "tof_filtered_cm":
                tof_value,

            "target_tof_cm":
                target_tof,

            "z_error_cm":
                z_error,

            "z_state":
                z_state
        })


        # ====================================================
        # TERMINAL
        # ====================================================

        if (
            now
            -
            last_print
            >=
            0.50
        ):

            last_print = now


            print(
                f"X={x:.3f} "
                f"Y={y:.3f}"
                f" | "
                f"EX={ex*100:+5.1f}cm "
                f"EY={ey*100:+5.1f}cm"
                f" | "
                f"E={distance_error*100:5.1f}cm"
                f" | "
                f"LR={rc_lr:+3d} "
                f"FB={rc_fb:+3d} "
                f"Z={rc_z:+3d}"
                f" | "
                f"{xy_state}"
                f" | "
                f"FPS={state['fps']:.1f}"
            )


    # ========================================================
    # STOP HORIZONTAL
    # ========================================================

    tello.send_rc_control(
        0,
        0,
        0,
        0
    )


    time.sleep(
        0.5
    )


    # ========================================================
    # LAND
    # ========================================================

    print()
    print("Landing...")

    tello.land()

    airborne = False


    # ========================================================
    # SAVE
    # ========================================================

    save_csv()


    # ========================================================
    # SUMMARY
    # ========================================================

    if len(flight_log) > 0:

        errors = np.array([
            row["error_distance_m"]
            for row in flight_log
            if row["error_distance_m"] is not None
        ], dtype=float)


        ex_values = np.array([
            row["error_x_m"]
            for row in flight_log
            if row["error_x_m"] is not None
        ], dtype=float)


        ey_values = np.array([
            row["error_y_m"]
            for row in flight_log
            if row["error_y_m"] is not None
        ], dtype=float)


        fps_values = np.array([
            row["vision_fps"]

            for row
            in flight_log

            if row["vision_fps"] > 0
        ])


        angles = np.array([
            row["aruco_angle_deg"]

            for row
            in flight_log
        ])


        print()
        print("=" * 76)
        print(" P04-B1 V1 RESULT")
        print("=" * 76)

        print()

        print(
            f"Target X,Y = "
            f"({target_x:.3f}, "
            f"{target_y:.3f}) m"
        )

        print()

        print(
            f"Mean position error : "
            f"{np.mean(errors)*100:.2f} cm"
        )

        print(
            f"Median error        : "
            f"{np.median(errors)*100:.2f} cm"
        )

        print(
            f"95th percentile     : "
            f"{np.percentile(errors,95)*100:.2f} cm"
        )

        print(
            f"Maximum error       : "
            f"{np.max(errors)*100:.2f} cm"
        )

        print()

        print(
            f"Mean |X error|      : "
            f"{np.mean(np.abs(ex_values))*100:.2f} cm"
        )

        print(
            f"Mean |Y error|      : "
            f"{np.mean(np.abs(ey_values))*100:.2f} cm"
        )

        print()

        if len(fps_values) > 0:

            print(
                f"Median vision FPS   : "
                f"{np.median(fps_values):.1f}"
            )


        print(
            f"Yaw median          : "
            f"{np.median(angles):+.2f} deg"
        )

        print(
            f"Yaw min/max         : "
            f"{np.min(angles):+.2f} / "
            f"{np.max(angles):+.2f} deg"
        )

        print()

        print("CSV:")
        print(CSV_FILE)


except KeyboardInterrupt:

    print()
    print(
        "[STOP] User requested stop."
    )


except Exception as e:

    print()
    print("[ERROR]")
    print(e)


finally:

    # Stop all RC motion before waiting for the vision worker.
    try:
        tello.send_rc_control(0, 0, 0, 0)
    except Exception as e:
        print("[WARN] Stop RC:", e)

    # ========================================================
    # STOP VISION THREAD
    # ========================================================

    vision_running = False


    if (
        vision_thread is not None
        and
        vision_thread.is_alive()
    ):

        vision_thread.join(
            timeout=1.0
        )


    # ========================================================
    # SAFETY LAND
    # ========================================================

    if airborne:

        print()
        print(
            "[SAFETY] Landing..."
        )

        try:

            tello.send_rc_control(
                0,
                0,
                0,
                0
            )

            time.sleep(
                0.5
            )

            tello.land()

        except Exception as e:

            print(
                "[WARN]",
                e
            )


    # ========================================================
    # SAVE PARTIAL LOG
    # ========================================================

    if len(flight_log) > 0:

        try:

            save_csv()

        except Exception as e:

            print(
                "[WARN] CSV:",
                e
            )


    cap.release()

    cv2.destroyAllWindows()


    try:

        tello.end()

    except Exception:

        pass


    print()
    print(
        "Program finished."
    )
